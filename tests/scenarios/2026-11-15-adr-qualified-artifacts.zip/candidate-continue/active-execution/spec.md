FICTIONAL approved fixture design. Choose remote source authority for architecture.json. Architectural approval is separate. Scope excludes publication.
