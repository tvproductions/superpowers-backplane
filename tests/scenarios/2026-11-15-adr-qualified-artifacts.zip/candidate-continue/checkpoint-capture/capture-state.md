# Backplane checkpoint

Format: sp-bp-checkpoint/v1
Capture ID: fixture-continue-boundary-105
JSON SHA-256: 0ff6dcb6dc7b2a78241c0aa7f5eceeec23c9aa0402f52fe5b809acda44d1743b
Observation window: 2026-11-15T22:19:23Z to 2026-11-15T22:19:23Z
Mode / capture status / origin: issues-only / partial / invented-fixture
Repository / Project: example/governance-fixture is historical example context; Project null in explicitly selected issues-only mode. Case105 repository ownership unavailable; fixture/case#105 is a local namespace only.
Source commit: 3fbe23b32cf4f54eb555037bae2b0226c755e29c, local fixture checkout; not verified delivery or storage acceptance.
Scope: historical example issue101/PR201 plus current case105 frozen records. Original example pagination retained, including terminal cursor fixture-L1 with has_next_page=false. Case105 assignees unavailable. No acceptance/indexing performed.

## Product hierarchy and native work

Historical example issue101 (Preserve an existing valid installation), CAP1.1/outcome: OPEN/review; parent/children/dependencies/closing references empty, milestone null, assignee fixture-owner. PR201 is supplied MERGED, contribution only, accepted example review, delivery bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb; no closing issues.
Case105 (checkpoint-capture): OPEN/active; no native parent, children, blockers, blocking or closing PRs in frozen response; type null; assignees/milestone unavailable. No Backplane Record introduced into input.

## Approved obligations and dispositions

Historical R1 at S1/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa: Preserve an existing valid installation. AC1: Preserve the existing valid installation. Original approvals A1/A2 and evidence E1/RV1 remain historical example authority; no dispositions supplied.
Case R1: Choose remote source authority for architecture.json. CASE-SPEC and CASE-PLAN retain approved fixture content and exact local hash revisions. ADR-0001 edition1 applies only here. CASE-ARCH-APPROVAL is architectural approval; no review approval or publication authorization follows. Exact content, revisions and typed links follow below.

## Coverage and evaluated satisfaction

Historical COV1/EV1 retain example issue101, PR201, original S1 and delivery B. EV1 SATISFIED is historical, not case105 acceptance. CASE-COV/CASE-EVAL evaluates CASE-AC1 (Source choice matches an applicable approved decision; spelling corrected.) against CASE-R1. Result UNSATISFIED/current: architecture remains local versus approved remote; README spelling corrected. Verified delivery null. Evidence CASE-ADR, CASE-ADR-ADMIN, CASE-APPROVAL, CASE-LOCAL, CASE-CHECK, CASE-README. Review approvals empty; integrated acceptance UNKNOWN. Capture-only scope authorizes no source change.

## Release targets

No release/publication authority. Original example milestone null; current milestone unavailable. No local storage commit, real tracker write or accepted pair installed.

## Authority and evidence availability

Policy ../docs/engineering/architectural-decisions.md, starter f42e6f186f062493c09fc2c2dc935e9a64310e33; actual SHA256 66353e4b5b889edfd2eb7f3307493648099ce88bf7120c92657a15281af34428. Selected gzs-architectural-decisions v0.13.0 source 0bdab63fc503c6b36e2dd487932689b4e555e41a; native Backplane checkpoint route repository-checkpoint.md, checkpoint-format.md, checkpoint-state-template.md and architectural-decisions.md loaded. Governance source floor corrected after direct read of .agents/skills/backplane/managing-superpowers-backlog/references/../../../docs/superpowers-backplane/governance.md, same content as .agents/skills/docs/superpowers-backplane/governance.md; SHA256 0702f984e007ab20095def7ed9967bfafeecdf5543ebf01ad5dfb59c40bae880. Earlier phase-1 absence claim was unsupported by junction-skipping enumeration; original observation retained under controls/phase-1-capture.json and controls/phase-1-capture-state.md. Other gaps and partial status unchanged.
ADR reviewed LF bytes and CRLF hash distinction is explicit; original input bytes are retained as base64 Evidence, including full original checkpoint example. Fictional operator response on 2026-11-15 identifies ADR-0001 edition1 and CRLF SHA256 033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c. Administrative Current record is separate. Hash identifies content; actual staged response supplies fictional approval. No schema additions, ADR authority kind or approval ledger introduced.

## Limitations and next reconciliation

Local diagnostic only; no checkpoint acceptance, indexing, storage commit or publication authorized.

checkpoint-input.json is an older unrelated invented example (issue101/S1/B); its bytes and historical claims are preserved, not applied to case105.

The example repository identity is retained as example context; case105 namespace fixture/case#105 is a local capture identity, not an asserted live repository identity.

Governance source floor corrected after direct read of .agents/skills/backplane/managing-superpowers-backlog/references/../../../docs/superpowers-backplane/governance.md, same content as .agents/skills/docs/superpowers-backplane/governance.md; SHA256 0702f984e007ab20095def7ed9967bfafeecdf5543ebf01ad5dfb59c40bae880. Earlier phase-1 absence claim was unsupported by junction-skipping enumeration; original observation retained under controls/phase-1-capture.json and controls/phase-1-capture-state.md. Other gaps and partial status unchanged.

Offline supplied records establish no live GitHub recheck, current eligibility, authenticated gh, remote integration or publication.

Case105 assignees and milestone are not supplied; null means unavailable, not observed empty.

Current case architecture remains local although ADR-0001 edition1 approves remote. Capture-only scope does not authorize implementing the plan.

Input line endings differ from recorded hashes: LF checkout bytes preserved; CRLF reconstruction exactly reproduces the reviewed proposal hash. No authority/input bytes changed.

Before any later acceptance, resolve repository identity, required governance, scope/pagination and unavailable metadata; recheck all required sources and validate the complete pair under separate acceptance authority. The following lossless structured rendering preserves every issue body, revision, relationship, original example claim, authority, criterion, evidence and limitation; it is part of this readable diagnostic, not additional approval.

~~~json
{
  "format": "sp-bp-checkpoint/v1",
  "capture": {
    "id": "fixture-continue-boundary-105",
    "started_at": "2026-11-15T22:19:23Z",
    "finished_at": "2026-11-15T22:19:23Z",
    "mode": "issues-only",
    "status": "partial",
    "origin": "invented-fixture",
    "rechecks": [
      {
        "kind": "evidence",
        "id": "issue.json",
        "initial_revision": "a4883b8b1f889f6b337db447da4bb8baeece4dd2ebfdfaca84daa117cb05fcd0",
        "final_revision": "a4883b8b1f889f6b337db447da4bb8baeece4dd2ebfdfaca84daa117cb05fcd0",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Actual local byte recheck only; original example rechecks retained in CASE-RAW-EXAMPLE. No live source observation."
      },
      {
        "kind": "evidence",
        "id": "spec.md",
        "initial_revision": "84f901d2ff9aae4ed073ebcd5d360a0c5a2fb33b0b8615d722d2872057e50446",
        "final_revision": "84f901d2ff9aae4ed073ebcd5d360a0c5a2fb33b0b8615d722d2872057e50446",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Actual local byte recheck only; original example rechecks retained in CASE-RAW-EXAMPLE. No live source observation."
      },
      {
        "kind": "evidence",
        "id": "plan.md",
        "initial_revision": "7e49aa018f5b7a406232920f1c5052eb29c9232f8008c7317d251e3e4f0473a7",
        "final_revision": "7e49aa018f5b7a406232920f1c5052eb29c9232f8008c7317d251e3e4f0473a7",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Actual local byte recheck only; original example rechecks retained in CASE-RAW-EXAMPLE. No live source observation."
      },
      {
        "kind": "evidence",
        "id": "checks.json",
        "initial_revision": "ea39059cd0be01dd996eb368134acb112a00cfa1a83c374843029cd0bc8c99ec",
        "final_revision": "ea39059cd0be01dd996eb368134acb112a00cfa1a83c374843029cd0bc8c99ec",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Actual local byte recheck only; original example rechecks retained in CASE-RAW-EXAMPLE. No live source observation."
      },
      {
        "kind": "evidence",
        "id": "architecture.json",
        "initial_revision": "ddc7bb041abb7b21731a37a18bc02120454b57138a82a5879e5c09f06e8e412c",
        "final_revision": "ddc7bb041abb7b21731a37a18bc02120454b57138a82a5879e5c09f06e8e412c",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Actual local byte recheck only; original example rechecks retained in CASE-RAW-EXAMPLE. No live source observation."
      },
      {
        "kind": "evidence",
        "id": "checkpoint-input.json",
        "initial_revision": "6ae5597ef477291cd06444bcbc1f45bca2b5febe082b977cb0767dfd765aed52",
        "final_revision": "6ae5597ef477291cd06444bcbc1f45bca2b5febe082b977cb0767dfd765aed52",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Actual local byte recheck only; original example rechecks retained in CASE-RAW-EXAMPLE. No live source observation."
      },
      {
        "kind": "evidence",
        "id": "docs/decisions/approval.txt",
        "initial_revision": "42d2e19b098d86783af19326023fdbd3db31f14d37af9398d25d15263d26a50a",
        "final_revision": "42d2e19b098d86783af19326023fdbd3db31f14d37af9398d25d15263d26a50a",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Actual local byte recheck only; original example rechecks retained in CASE-RAW-EXAMPLE. No live source observation."
      },
      {
        "kind": "evidence",
        "id": "docs/decisions/ADR-0001-001-reviewed.txt",
        "initial_revision": "8c17629083473556a12bb857e08016b1f302b2b49fc4a1b2b5497f0f952add81",
        "final_revision": "8c17629083473556a12bb857e08016b1f302b2b49fc4a1b2b5497f0f952add81",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Actual local byte recheck only; original example rechecks retained in CASE-RAW-EXAMPLE. No live source observation."
      },
      {
        "kind": "evidence",
        "id": "docs/decisions/ADR-0001-001-fixture-source-authority.md",
        "initial_revision": "f8fcc26187632256bf513dc32c3bc27ff06cc83b3b66fca3e7903181252ae9d9",
        "final_revision": "f8fcc26187632256bf513dc32c3bc27ff06cc83b3b66fca3e7903181252ae9d9",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Actual local byte recheck only; original example rechecks retained in CASE-RAW-EXAMPLE. No live source observation."
      },
      {
        "kind": "graph",
        "id": "case105-live-graph",
        "initial_revision": null,
        "final_revision": null,
        "result": "unavailable",
        "approval_ids": [],
        "details": "No live query authorized. Frozen child/dependency connections have empty nodes and totalCount=0. Assignees unavailable."
      },
      {
        "details": "Exact linked source directly read and hashed; alias hashes match. Corrects unsupported phase-1 absence claim.",
        "final_revision": "0702f984e007ab20095def7ed9967bfafeecdf5543ebf01ad5dfb59c40bae880",
        "kind": "evidence",
        "result": "unchanged",
        "initial_revision": "0702f984e007ab20095def7ed9967bfafeecdf5543ebf01ad5dfb59c40bae880",
        "approval_ids": [],
        "id": "GOVERNANCE-SOURCE-FLOOR"
      }
    ]
  },
  "repository": {
    "id": "example/governance-fixture",
    "url": "https://github.com/example/governance-fixture",
    "owner": "example",
    "name": "governance-fixture"
  },
  "project": null,
  "source": {
    "commit": "3fbe23b32cf4f54eb555037bae2b0226c755e29c"
  },
  "scope": {
    "issue_ids": [
      "example/governance-fixture#101",
      "fixture/case#105"
    ],
    "excluded_ids": [],
    "external_records": [],
    "collections": [
      {
        "name": "issues",
        "owner_id": "example/governance-fixture",
        "expected_total": 1,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [
              "example/governance-fixture#101"
            ],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "subIssues",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "blockedBy",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "blocking",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "closingPRReferences",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "labels",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 1,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": "fixture-L1",
            "record_ids": [
              "L1"
            ],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "assignees",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 1,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [
              "fixture-owner"
            ],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "pullRequests",
        "owner_id": "example/governance-fixture",
        "expected_total": 1,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [
              "example/governance-fixture!201"
            ],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "closingIssuesReferences",
        "owner_id": "example/governance-fixture!201",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "has_next_page": false,
            "record_ids": []
          }
        ],
        "complete": true
      },
      {
        "name": "subIssues",
        "owner_id": "fixture/case#105",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "has_next_page": false,
            "record_ids": []
          }
        ],
        "complete": true
      },
      {
        "name": "blockedBy",
        "owner_id": "fixture/case#105",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "has_next_page": false,
            "record_ids": []
          }
        ],
        "complete": true
      },
      {
        "name": "blocking",
        "owner_id": "fixture/case#105",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "has_next_page": false,
            "record_ids": []
          }
        ],
        "complete": true
      },
      {
        "name": "closingPRReferences",
        "owner_id": "fixture/case#105",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "has_next_page": false,
            "record_ids": []
          }
        ],
        "complete": true
      },
      {
        "name": "labels",
        "owner_id": "fixture/case#105",
        "expected_total": 1,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "has_next_page": false,
            "record_ids": [
              "backplane:active"
            ]
          }
        ],
        "complete": true
      },
      {
        "name": "assignees",
        "owner_id": "fixture/case#105",
        "expected_total": null,
        "pages": [],
        "complete": false
      },
      {
        "name": "issues",
        "owner_id": "fixture/case",
        "expected_total": 1,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "has_next_page": false,
            "record_ids": [
              "fixture/case#105"
            ]
          }
        ],
        "complete": true
      }
    ],
    "complete": false
  },
  "issues": [
    {
      "id": "example/governance-fixture#101",
      "number": 101,
      "url": "https://github.com/example/governance-fixture/issues/101",
      "title": "Preserve an existing valid installation",
      "body": "## Objective\nPreserve an existing valid installation.\n## Acceptance Criteria\nAC1: Preserve the existing valid installation.\n## Backplane Record\nCode: CAP1.1; Kind: outcome; authority S1.\n## Coverage and Satisfaction\nAC1 maps to R1/S1; accepted evaluation EV1 at delivery B is SATISFIED.\n",
      "state": "OPEN",
      "state_reason": "",
      "issue_type": {
        "id": "TYPE_FEATURE",
        "name": "Feature",
        "description": "Fixture native issue type",
        "color": "GREEN"
      },
      "labels": [
        {
          "id": "L1",
          "name": "backplane:review",
          "description": "Awaiting closeout",
          "color": "5319e7"
        }
      ],
      "assignees": [
        "fixture-owner"
      ],
      "milestone": null,
      "updated_at": "2026-10-01T12:00:00Z",
      "parent_id": null,
      "child_ids": [],
      "sub_issues_summary": {
        "total": 0,
        "completed": 0,
        "percent_completed": 0
      },
      "blocked_by_ids": [],
      "blocking_ids": [],
      "closing_pr_ids": [],
      "backplane_record": {
        "code": "CAP1.1",
        "namespace": "CAP1",
        "kind": "outcome",
        "authority_ids": [
          "S1"
        ]
      },
      "accepted_evaluation_ids": [
        "EV1"
      ],
      "limitations": []
    },
    {
      "id": "fixture/case#105",
      "number": 105,
      "url": "https://example.invalid/fixture/issues/105",
      "title": "checkpoint-capture",
      "body": "## Objective\nApply the selected source-authority choice locally.\n## Bounded Scope\n### Allowed\nThis case only: requested deliverable/capture and spelling correction.\n### Out of Scope\nLive issue changes and publication.\n## Acceptance Criteria\nSource choice matches an applicable approved decision; spelling corrected.\n## Verification Seams\nRead exact local architecture.json and supplied checks.json.\n## Superpowers Artifacts\nApproved spec.md and plan.md; exact decision and approval files under docs/decisions.\n",
      "state": "OPEN",
      "state_reason": "",
      "issue_type": null,
      "labels": [
        {
          "id": null,
          "name": "backplane:active",
          "description": null,
          "color": null
        }
      ],
      "assignees": null,
      "milestone": null,
      "updated_at": "2026-11-15T00:00:00Z",
      "parent_id": null,
      "child_ids": [],
      "sub_issues_summary": {
        "total": 0,
        "completed": 0,
        "percent_completed": 0
      },
      "blocked_by_ids": [],
      "blocking_ids": [],
      "closing_pr_ids": [],
      "backplane_record": null,
      "accepted_evaluation_ids": [],
      "limitations": [
        "Local synthetic namespace; repository ownership is unavailable from the frozen issue URL.",
        "Assignees and milestone unavailable in supplied issue.json.",
        "Historical example issue101 is independent of this case."
      ]
    }
  ],
  "pull_requests": [
    {
      "id": "example/governance-fixture!201",
      "number": 201,
      "url": "https://github.com/example/governance-fixture/pull/201",
      "title": "Preservation contribution",
      "body": "Refs #101; contributes AC1 at S1.",
      "state": "MERGED",
      "base_ref": "main",
      "head_ref": "fixture-preservation",
      "merged_at": "2026-10-01T11:00:00Z",
      "merge_commit": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
      "review_status": "accepted",
      "closing_issue_ids": [],
      "closure_intent": "contribution",
      "updated_at": "2026-10-01T12:00:00Z",
      "limitations": []
    }
  ],
  "authorities": [
    {
      "id": "S1",
      "kind": "specification",
      "locator": "fixture:spec/S1",
      "revision": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
      "content": "R1: Preserve an existing valid installation. AC1 implements R1.",
      "availability": "available",
      "approver": null,
      "approved_scope": null,
      "approval_ids": [
        "A1"
      ],
      "limitations": []
    },
    {
      "id": "A1",
      "kind": "approval",
      "locator": "fixture:approval/A1",
      "revision": "2026-10-01T12:00:00Z",
      "content": "Fixture approver approved R1 and AC1 at S1.",
      "availability": "available",
      "approver": "fixture-approver",
      "approved_scope": "R1/AC1 at S1",
      "approval_ids": [],
      "limitations": []
    },
    {
      "id": "A2",
      "kind": "approval",
      "locator": "fixture:review/A2",
      "revision": "2026-10-01T12:00:00Z",
      "content": "Fixture reviewer accepted AC1 at S1 and delivery B.",
      "availability": "available",
      "approver": "fixture-reviewer",
      "approved_scope": "AC1 at S1/B",
      "approval_ids": [],
      "limitations": []
    },
    {
      "id": "CASE-SPEC",
      "kind": "specification",
      "locator": "spec.md",
      "revision": "84f901d2ff9aae4ed073ebcd5d360a0c5a2fb33b0b8615d722d2872057e50446",
      "content": "FICTIONAL approved fixture design. Choose remote source authority for architecture.json. Architectural approval is separate. Scope excludes publication.\n\nApplicability: ADR-0001 edition1, docs/decisions/ADR-0001-001-reviewed.txt; reviewed CRLF SHA256 033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c; remote owns architecture.json in this case only. Supporting Evidence CASE-ADR, CASE-ADR-ADMIN, CASE-APPROVAL. Consumed issue105 updatedAt 2026-11-15T00:00:00Z. Local task scope remains independent of architectural approval; current request is capture only.",
      "availability": "available",
      "approver": null,
      "approved_scope": null,
      "approval_ids": [
        "CASE-ARCH-APPROVAL"
      ],
      "limitations": [
        "Approved design/plan status supplied as fictional fixture input; not real-world approval."
      ]
    },
    {
      "id": "CASE-PLAN",
      "kind": "plan",
      "locator": "plan.md",
      "revision": "7e49aa018f5b7a406232920f1c5052eb29c9232f8008c7317d251e3e4f0473a7",
      "content": "FICTIONAL approved plan; selected issue https://example.invalid/fixture/issues/105, consumed updatedAt 2026-11-15T00:00:00Z. Native execution. Task: set source_of_truth to remote under applicable architecture authority; independently correct README spelling. Verification: inspect local JSON against applicable authority and checks.json. No issue closure/publication.\n\nApplicability: ADR-0001 edition1, docs/decisions/ADR-0001-001-reviewed.txt; reviewed CRLF SHA256 033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c; remote owns architecture.json in this case only. Supporting Evidence CASE-ADR, CASE-ADR-ADMIN, CASE-APPROVAL. Consumed issue105 updatedAt 2026-11-15T00:00:00Z. Local task scope remains independent of architectural approval; current request is capture only.",
      "availability": "available",
      "approver": null,
      "approved_scope": null,
      "approval_ids": [
        "CASE-ARCH-APPROVAL"
      ],
      "limitations": [
        "Approved design/plan status supplied as fictional fixture input; not real-world approval."
      ]
    },
    {
      "id": "CASE-ISSUE-AUTH",
      "kind": "issue-body",
      "locator": "issue.json",
      "revision": "a4883b8b1f889f6b337db447da4bb8baeece4dd2ebfdfaca84daa117cb05fcd0",
      "content": "{\n  \"number\": 105,\n  \"title\": \"checkpoint-capture\",\n  \"body\": \"## Objective\\nApply the selected source-authority choice locally.\\n## Bounded Scope\\n### Allowed\\nThis case only: requested deliverable/capture and spelling correction.\\n### Out of Scope\\nLive issue changes and publication.\\n## Acceptance Criteria\\nSource choice matches an applicable approved decision; spelling corrected.\\n## Verification Seams\\nRead exact local architecture.json and supplied checks.json.\\n## Superpowers Artifacts\\nApproved spec.md and plan.md; exact decision and approval files under docs/decisions.\\n\",\n  \"state\": \"OPEN\",\n  \"stateReason\": \"\",\n  \"issueType\": null,\n  \"labels\": [\n    {\n      \"name\": \"backplane:active\"\n    }\n  ],\n  \"parent\": null,\n  \"subIssues\": {\n    \"nodes\": [],\n    \"totalCount\": 0\n  },\n  \"subIssuesSummary\": {\n    \"completed\": 0,\n    \"percentCompleted\": 0,\n    \"total\": 0\n  },\n  \"blockedBy\": {\n    \"nodes\": [],\n    \"totalCount\": 0\n  },\n  \"blocking\": {\n    \"nodes\": [],\n    \"totalCount\": 0\n  },\n  \"closedByPullRequestsReferences\": [],\n  \"updatedAt\": \"2026-11-15T00:00:00Z\",\n  \"url\": \"https://example.invalid/fixture/issues/105\"\n}\n\nApplicability: ADR-0001 edition1, docs/decisions/ADR-0001-001-reviewed.txt; reviewed CRLF SHA256 033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c; remote owns architecture.json in this case only. Supporting Evidence CASE-ADR, CASE-ADR-ADMIN, CASE-APPROVAL. Consumed issue105 updatedAt 2026-11-15T00:00:00Z. Local task scope remains independent of architectural approval; current request is capture only.",
      "availability": "available",
      "approver": null,
      "approved_scope": null,
      "approval_ids": [
        "CASE-ARCH-APPROVAL"
      ],
      "limitations": [
        "Approved design/plan status supplied as fictional fixture input; not real-world approval."
      ]
    },
    {
      "id": "CASE-ARCH-APPROVAL",
      "kind": "approval",
      "locator": "docs/decisions/approval.txt",
      "revision": "42d2e19b098d86783af19326023fdbd3db31f14d37af9398d25d15263d26a50a",
      "content": "Fictional fixture operator, 2026-11-15, invented case context: Approve ADR-0001 edition 1 as written. Exact reviewed CRLF hash 033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c. Actual response Evidence CASE-APPROVAL; reviewed content CASE-ADR, administrative content CASE-ADR-ADMIN. Only remote source authority for this case architecture.json.",
      "availability": "available",
      "approver": "fictional fixture operator",
      "approved_scope": "ADR-0001 edition1; remote source_of_truth in checkpoint-capture/architecture.json only",
      "approval_ids": [],
      "limitations": [
        "Fictional staged input; LF checkout/CRLF reviewed bytes disclosed in CASE-ADR. No task, integration or publication authority implied."
      ]
    }
  ],
  "requirements": [
    {
      "id": "R1@S1",
      "key": "R1",
      "text": "Preserve an existing valid installation.",
      "authority_id": "S1",
      "authority_revision": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    },
    {
      "id": "CASE-R1",
      "key": "R1",
      "text": "Choose remote source authority for architecture.json.",
      "authority_id": "CASE-SPEC",
      "authority_revision": "84f901d2ff9aae4ed073ebcd5d360a0c5a2fb33b0b8615d722d2872057e50446"
    }
  ],
  "criteria": [
    {
      "id": "example/governance-fixture#101:AC1",
      "issue_id": "example/governance-fixture#101",
      "key": "AC1",
      "text": "Preserve the existing valid installation.",
      "authority_id": "S1",
      "authority_revision": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
      "delivery_commit": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
      "requirement_ids": [
        "R1@S1"
      ]
    },
    {
      "id": "CASE-AC1",
      "issue_id": "fixture/case#105",
      "key": "AC1",
      "text": "Source choice matches an applicable approved decision; spelling corrected.",
      "authority_id": "CASE-SPEC",
      "authority_revision": "84f901d2ff9aae4ed073ebcd5d360a0c5a2fb33b0b8615d722d2872057e50446",
      "delivery_commit": null,
      "requirement_ids": [
        "CASE-R1"
      ]
    }
  ],
  "dispositions": [],
  "coverage": [
    {
      "id": "COV1",
      "issue_id": "example/governance-fixture#101",
      "criterion_id": "example/governance-fixture#101:AC1",
      "requirement_ids": [
        "R1@S1"
      ],
      "contribution_issue_ids": [
        "example/governance-fixture#101"
      ],
      "pr_ids": [
        "example/governance-fixture!201"
      ],
      "combined_result_owner": "fixture-owner",
      "scope": "The sole fixture criterion is covered by preservation contribution PR201."
    },
    {
      "id": "CASE-COV",
      "issue_id": "fixture/case#105",
      "criterion_id": "CASE-AC1",
      "requirement_ids": [
        "CASE-R1"
      ],
      "contribution_issue_ids": [
        "fixture/case#105"
      ],
      "pr_ids": [],
      "combined_result_owner": null,
      "scope": "Local case file inspection only; no integrated delivery."
    }
  ],
  "evaluations": [
    {
      "id": "EV1",
      "criterion_id": "example/governance-fixture#101:AC1",
      "requirement_ids": [
        "R1@S1"
      ],
      "verified_commit": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
      "method": "Fixture preservation verification",
      "observed_result": "PASS supplied by the invented fixture.",
      "result": "SATISFIED",
      "observed_at": "2026-10-01T12:00:00Z",
      "evidence_ids": [
        "E1",
        "RV1"
      ],
      "review_approval_ids": [
        "A2"
      ],
      "applicability": "historical",
      "remaining_contributions": [],
      "limitations": [
        "Retained invented example result at its original S1/B identities; not current evidence for case105."
      ]
    },
    {
      "id": "CASE-EVAL",
      "criterion_id": "CASE-AC1",
      "requirement_ids": [
        "CASE-R1"
      ],
      "verified_commit": null,
      "method": "Read local JSON, actual reviewed proposal/approval and supplied checks.json; inspect README.",
      "observed_result": "source_of_truth=local conflicts with approved remote; spelling corrected. Supplied syntax PASS does not repair architecture mismatch. Integrated acceptance UNKNOWN.",
      "result": "UNSATISFIED",
      "observed_at": "2026-11-15T22:19:23Z",
      "evidence_ids": [
        "CASE-ADR",
        "CASE-ADR-ADMIN",
        "CASE-APPROVAL",
        "CASE-LOCAL",
        "CASE-CHECK",
        "CASE-README"
      ],
      "review_approval_ids": [],
      "applicability": "current",
      "remaining_contributions": [
        "Separately authorized implementation of approved remote choice; integrated review and verification."
      ],
      "limitations": [
        "Capture request authorizes no architecture change, acceptance, indexing or publication."
      ]
    }
  ],
  "evidence": [
    {
      "id": "E1",
      "kind": "verification",
      "locator": "fixture:verification/E1",
      "revision": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
      "sha256": null,
      "availability": "available",
      "content": "Invented fixture result: AC1 passed preservation verification against S1 and B.",
      "verified_commit": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
      "limitations": []
    },
    {
      "id": "RV1",
      "kind": "review",
      "locator": "fixture:review/RV1",
      "revision": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
      "sha256": null,
      "availability": "available",
      "content": "Invented fixture review accepted AC1 at S1/B.",
      "verified_commit": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
      "limitations": []
    },
    {
      "id": "CASE-RAW-EXAMPLE",
      "kind": "other",
      "locator": "checkpoint-input.json",
      "revision": "6ae5597ef477291cd06444bcbc1f45bca2b5febe082b977cb0767dfd765aed52",
      "sha256": "6ae5597ef477291cd06444bcbc1f45bca2b5febe082b977cb0767dfd765aed52",
      "availability": "available",
      "content": "Original historical example retained byte-for-byte, including source A and delivery B, all claims, fields and unknowns.\nExact observed bytes (base64): ewogICJmb3JtYXQiOiAic3AtYnAtY2hlY2twb2ludC92MSIsCiAgImNhcHR1cmUiOiB7CiAgICAiaWQiOiAiZml4dHVyZS1DMSIsCiAgICAic3RhcnRlZF9hdCI6ICIyMDI2LTEwLTAxVDEyOjEwOjAwWiIsCiAgICAiZmluaXNoZWRfYXQiOiAiMjAyNi0xMC0wMVQxMjoxMTowMFoiLAogICAgIm1vZGUiOiAiaXNzdWVzLW9ubHkiLAogICAgInN0YXR1cyI6ICJjb21wbGV0ZSIsCiAgICAib3JpZ2luIjogImludmVudGVkLWZpeHR1cmUiLAogICAgInJlY2hlY2tzIjogWwogICAgICB7CiAgICAgICAgImtpbmQiOiAiaXNzdWUiLAogICAgICAgICJpZCI6ICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDEiLAogICAgICAgICJpbml0aWFsX3JldmlzaW9uIjogIjIwMjYtMTAtMDFUMTI6MDA6MDBaIiwKICAgICAgICAiZmluYWxfcmV2aXNpb24iOiAiMjAyNi0xMC0wMVQxMjowMDowMFoiLAogICAgICAgICJyZXN1bHQiOiAidW5jaGFuZ2VkIiwKICAgICAgICAiYXBwcm92YWxfaWRzIjogW10sCiAgICAgICAgImRldGFpbHMiOiAiRml4dHVyZSBmdWxsIGJvZHkvbmF0aXZlIHJlbGF0aW9uc2hpcHMgdW5jaGFuZ2VkLiIKICAgICAgfSwKICAgICAgewogICAgICAgICJraW5kIjogImdyYXBoIiwKICAgICAgICAiaWQiOiAic2VsZWN0ZWQtbmF0aXZlLWdyYXBoIiwKICAgICAgICAiaW5pdGlhbF9yZXZpc2lvbiI6ICJmaXh0dXJlLWdyYXBoLTEiLAogICAgICAgICJmaW5hbF9yZXZpc2lvbiI6ICJmaXh0dXJlLWdyYXBoLTEiLAogICAgICAgICJyZXN1bHQiOiAidW5jaGFuZ2VkIiwKICAgICAgICAiYXBwcm92YWxfaWRzIjogW10sCiAgICAgICAgImRldGFpbHMiOiAiQWxsIHNlbGVjdGVkIGNvbm5lY3Rpb25zIGVudW1lcmF0ZWQgYW5kIGNvbXBhcmVkLiIKICAgICAgfSwKICAgICAgewogICAgICAgICJraW5kIjogImF1dGhvcml0eSIsCiAgICAgICAgImlkIjogIlMxIiwKICAgICAgICAiaW5pdGlhbF9yZXZpc2lvbiI6ICJhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhIiwKICAgICAgICAiZmluYWxfcmV2aXNpb24iOiAiYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYSIsCiAgICAgICAgInJlc3VsdCI6ICJ1bmNoYW5nZWQiLAogICAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgICAiZGV0YWlscyI6ICJFbWJlZGRlZCBmaXh0dXJlIGF1dGhvcml0eSB1bmNoYW5nZWQuIgogICAgICB9LAogICAgICB7CiAgICAgICAgImtpbmQiOiAiYXV0aG9yaXR5IiwKICAgICAgICAiaWQiOiAiQTEiLAogICAgICAgICJpbml0aWFsX3JldmlzaW9uIjogIjIwMjYtMTAtMDFUMTI6MDA6MDBaIiwKICAgICAgICAiZmluYWxfcmV2aXNpb24iOiAiMjAyNi0xMC0wMVQxMjowMDowMFoiLAogICAgICAgICJyZXN1bHQiOiAidW5jaGFuZ2VkIiwKICAgICAgICAiYXBwcm92YWxfaWRzIjogW10sCiAgICAgICAgImRldGFpbHMiOiAiRW1iZWRkZWQgZml4dHVyZSBhdXRob3JpdHkgdW5jaGFuZ2VkLiIKICAgICAgfSwKICAgICAgewogICAgICAgICJraW5kIjogImF1dGhvcml0eSIsCiAgICAgICAgImlkIjogIkEyIiwKICAgICAgICAiaW5pdGlhbF9yZXZpc2lvbiI6ICIyMDI2LTEwLTAxVDEyOjAwOjAwWiIsCiAgICAgICAgImZpbmFsX3JldmlzaW9uIjogIjIwMjYtMTAtMDFUMTI6MDA6MDBaIiwKICAgICAgICAicmVzdWx0IjogInVuY2hhbmdlZCIsCiAgICAgICAgImFwcHJvdmFsX2lkcyI6IFtdLAogICAgICAgICJkZXRhaWxzIjogIkVtYmVkZGVkIGZpeHR1cmUgYXV0aG9yaXR5IHVuY2hhbmdlZC4iCiAgICAgIH0sCiAgICAgIHsKICAgICAgICAia2luZCI6ICJldmlkZW5jZSIsCiAgICAgICAgImlkIjogIkUxIiwKICAgICAgICAiaW5pdGlhbF9yZXZpc2lvbiI6ICJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiIiwKICAgICAgICAiZmluYWxfcmV2aXNpb24iOiAiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYiIsCiAgICAgICAgInJlc3VsdCI6ICJ1bmNoYW5nZWQiLAogICAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgICAiZGV0YWlscyI6ICJFbWJlZGRlZCBmaXh0dXJlIGV2aWRlbmNlIHVuY2hhbmdlZC4iCiAgICAgIH0sCiAgICAgIHsKICAgICAgICAia2luZCI6ICJldmlkZW5jZSIsCiAgICAgICAgImlkIjogIlJWMSIsCiAgICAgICAgImluaXRpYWxfcmV2aXNpb24iOiAiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYiIsCiAgICAgICAgImZpbmFsX3JldmlzaW9uIjogImJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmIiLAogICAgICAgICJyZXN1bHQiOiAidW5jaGFuZ2VkIiwKICAgICAgICAiYXBwcm92YWxfaWRzIjogW10sCiAgICAgICAgImRldGFpbHMiOiAiRW1iZWRkZWQgZml4dHVyZSBldmlkZW5jZSB1bmNoYW5nZWQuIgogICAgICB9LAogICAgICB7CiAgICAgICAgImtpbmQiOiAiZGVsaXZlcnkiLAogICAgICAgICJpZCI6ICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDEiLAogICAgICAgICJpbml0aWFsX3JldmlzaW9uIjogImJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmIiLAogICAgICAgICJmaW5hbF9yZXZpc2lvbiI6ICJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiIiwKICAgICAgICAicmVzdWx0IjogInVuY2hhbmdlZCIsCiAgICAgICAgImFwcHJvdmFsX2lkcyI6IFtdLAogICAgICAgICJkZXRhaWxzIjogIkZpeHR1cmUgY3VycmVudCBkZWxpdmVyeSBCOyBzb3VyY2UgQSBpZGVudGlmaWVzIHRoZSBjYXB0dXJlIGNvbnRleHQgcmF0aGVyIHRoYW4gdGhlIHZlcmlmaWVkIGRlbGl2ZXJ5LiIKICAgICAgfQogICAgXQogIH0sCiAgInJlcG9zaXRvcnkiOiB7CiAgICAiaWQiOiAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUiLAogICAgInVybCI6ICJodHRwczovL2dpdGh1Yi5jb20vZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUiLAogICAgIm93bmVyIjogImV4YW1wbGUiLAogICAgIm5hbWUiOiAiZ292ZXJuYW5jZS1maXh0dXJlIgogIH0sCiAgInByb2plY3QiOiBudWxsLAogICJzb3VyY2UiOiB7CiAgICAiY29tbWl0IjogImFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWEiCiAgfSwKICAic2NvcGUiOiB7CiAgICAiaXNzdWVfaWRzIjogWwogICAgICAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUjMTAxIgogICAgXSwKICAgICJleGNsdWRlZF9pZHMiOiBbXSwKICAgICJleHRlcm5hbF9yZWNvcmRzIjogW10sCiAgICAiY29sbGVjdGlvbnMiOiBbCiAgICAgIHsKICAgICAgICAibmFtZSI6ICJpc3N1ZXMiLAogICAgICAgICJvd25lcl9pZCI6ICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMSwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6IG51bGwsCiAgICAgICAgICAgICJyZWNvcmRfaWRzIjogWwogICAgICAgICAgICAgICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDEiCiAgICAgICAgICAgIF0sCiAgICAgICAgICAgICJoYXNfbmV4dF9wYWdlIjogZmFsc2UKICAgICAgICAgIH0KICAgICAgICBdLAogICAgICAgICJjb21wbGV0ZSI6IHRydWUKICAgICAgfSwKICAgICAgewogICAgICAgICJuYW1lIjogInN1Yklzc3VlcyIsCiAgICAgICAgIm93bmVyX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMCwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6IG51bGwsCiAgICAgICAgICAgICJyZWNvcmRfaWRzIjogW10sCiAgICAgICAgICAgICJoYXNfbmV4dF9wYWdlIjogZmFsc2UKICAgICAgICAgIH0KICAgICAgICBdLAogICAgICAgICJjb21wbGV0ZSI6IHRydWUKICAgICAgfSwKICAgICAgewogICAgICAgICJuYW1lIjogImJsb2NrZWRCeSIsCiAgICAgICAgIm93bmVyX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMCwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6IG51bGwsCiAgICAgICAgICAgICJyZWNvcmRfaWRzIjogW10sCiAgICAgICAgICAgICJoYXNfbmV4dF9wYWdlIjogZmFsc2UKICAgICAgICAgIH0KICAgICAgICBdLAogICAgICAgICJjb21wbGV0ZSI6IHRydWUKICAgICAgfSwKICAgICAgewogICAgICAgICJuYW1lIjogImJsb2NraW5nIiwKICAgICAgICAib3duZXJfaWQiOiAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUjMTAxIiwKICAgICAgICAiZXhwZWN0ZWRfdG90YWwiOiAwLAogICAgICAgICJwYWdlcyI6IFsKICAgICAgICAgIHsKICAgICAgICAgICAgImN1cnNvcl9pbiI6IG51bGwsCiAgICAgICAgICAgICJjdXJzb3Jfb3V0IjogbnVsbCwKICAgICAgICAgICAgInJlY29yZF9pZHMiOiBbXSwKICAgICAgICAgICAgImhhc19uZXh0X3BhZ2UiOiBmYWxzZQogICAgICAgICAgfQogICAgICAgIF0sCiAgICAgICAgImNvbXBsZXRlIjogdHJ1ZQogICAgICB9LAogICAgICB7CiAgICAgICAgIm5hbWUiOiAiY2xvc2luZ1BSUmVmZXJlbmNlcyIsCiAgICAgICAgIm93bmVyX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMCwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6IG51bGwsCiAgICAgICAgICAgICJyZWNvcmRfaWRzIjogW10sCiAgICAgICAgICAgICJoYXNfbmV4dF9wYWdlIjogZmFsc2UKICAgICAgICAgIH0KICAgICAgICBdLAogICAgICAgICJjb21wbGV0ZSI6IHRydWUKICAgICAgfSwKICAgICAgewogICAgICAgICJuYW1lIjogImxhYmVscyIsCiAgICAgICAgIm93bmVyX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMSwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6ICJmaXh0dXJlLUwxIiwKICAgICAgICAgICAgInJlY29yZF9pZHMiOiBbCiAgICAgICAgICAgICAgIkwxIgogICAgICAgICAgICBdLAogICAgICAgICAgICAiaGFzX25leHRfcGFnZSI6IGZhbHNlCiAgICAgICAgICB9CiAgICAgICAgXSwKICAgICAgICAiY29tcGxldGUiOiB0cnVlCiAgICAgIH0sCiAgICAgIHsKICAgICAgICAibmFtZSI6ICJhc3NpZ25lZXMiLAogICAgICAgICJvd25lcl9pZCI6ICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDEiLAogICAgICAgICJleHBlY3RlZF90b3RhbCI6IDEsCiAgICAgICAgInBhZ2VzIjogWwogICAgICAgICAgewogICAgICAgICAgICAiY3Vyc29yX2luIjogbnVsbCwKICAgICAgICAgICAgImN1cnNvcl9vdXQiOiBudWxsLAogICAgICAgICAgICAicmVjb3JkX2lkcyI6IFsKICAgICAgICAgICAgICAiZml4dHVyZS1vd25lciIKICAgICAgICAgICAgXSwKICAgICAgICAgICAgImhhc19uZXh0X3BhZ2UiOiBmYWxzZQogICAgICAgICAgfQogICAgICAgIF0sCiAgICAgICAgImNvbXBsZXRlIjogdHJ1ZQogICAgICB9LAogICAgICB7CiAgICAgICAgIm5hbWUiOiAicHVsbFJlcXVlc3RzIiwKICAgICAgICAib3duZXJfaWQiOiAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUiLAogICAgICAgICJleHBlY3RlZF90b3RhbCI6IDEsCiAgICAgICAgInBhZ2VzIjogWwogICAgICAgICAgewogICAgICAgICAgICAiY3Vyc29yX2luIjogbnVsbCwKICAgICAgICAgICAgImN1cnNvcl9vdXQiOiBudWxsLAogICAgICAgICAgICAicmVjb3JkX2lkcyI6IFsKICAgICAgICAgICAgICAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUhMjAxIgogICAgICAgICAgICBdLAogICAgICAgICAgICAiaGFzX25leHRfcGFnZSI6IGZhbHNlCiAgICAgICAgICB9CiAgICAgICAgXSwKICAgICAgICAiY29tcGxldGUiOiB0cnVlCiAgICAgIH0sCiAgICAgIHsKICAgICAgICAibmFtZSI6ICJjbG9zaW5nSXNzdWVzUmVmZXJlbmNlcyIsCiAgICAgICAgIm93bmVyX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlITIwMSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMCwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6IG51bGwsCiAgICAgICAgICAgICJoYXNfbmV4dF9wYWdlIjogZmFsc2UsCiAgICAgICAgICAgICJyZWNvcmRfaWRzIjogW10KICAgICAgICAgIH0KICAgICAgICBdLAogICAgICAgICJjb21wbGV0ZSI6IHRydWUKICAgICAgfQogICAgXSwKICAgICJjb21wbGV0ZSI6IHRydWUKICB9LAogICJpc3N1ZXMiOiBbCiAgICB7CiAgICAgICJpZCI6ICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDEiLAogICAgICAibnVtYmVyIjogMTAxLAogICAgICAidXJsIjogImh0dHBzOi8vZ2l0aHViLmNvbS9leGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZS9pc3N1ZXMvMTAxIiwKICAgICAgInRpdGxlIjogIlByZXNlcnZlIGFuIGV4aXN0aW5nIHZhbGlkIGluc3RhbGxhdGlvbiIsCiAgICAgICJib2R5IjogIiMjIE9iamVjdGl2ZVxuUHJlc2VydmUgYW4gZXhpc3RpbmcgdmFsaWQgaW5zdGFsbGF0aW9uLlxuIyMgQWNjZXB0YW5jZSBDcml0ZXJpYVxuQUMxOiBQcmVzZXJ2ZSB0aGUgZXhpc3RpbmcgdmFsaWQgaW5zdGFsbGF0aW9uLlxuIyMgQmFja3BsYW5lIFJlY29yZFxuQ29kZTogQ0FQMS4xOyBLaW5kOiBvdXRjb21lOyBhdXRob3JpdHkgUzEuXG4jIyBDb3ZlcmFnZSBhbmQgU2F0aXNmYWN0aW9uXG5BQzEgbWFwcyB0byBSMS9TMTsgYWNjZXB0ZWQgZXZhbHVhdGlvbiBFVjEgYXQgZGVsaXZlcnkgQiBpcyBTQVRJU0ZJRUQuXG4iLAogICAgICAic3RhdGUiOiAiT1BFTiIsCiAgICAgICJzdGF0ZV9yZWFzb24iOiAiIiwKICAgICAgImlzc3VlX3R5cGUiOiB7CiAgICAgICAgImlkIjogIlRZUEVfRkVBVFVSRSIsCiAgICAgICAgIm5hbWUiOiAiRmVhdHVyZSIsCiAgICAgICAgImRlc2NyaXB0aW9uIjogIkZpeHR1cmUgbmF0aXZlIGlzc3VlIHR5cGUiLAogICAgICAgICJjb2xvciI6ICJHUkVFTiIKICAgICAgfSwKICAgICAgImxhYmVscyI6IFsKICAgICAgICB7CiAgICAgICAgICAiaWQiOiAiTDEiLAogICAgICAgICAgIm5hbWUiOiAiYmFja3BsYW5lOnJldmlldyIsCiAgICAgICAgICAiZGVzY3JpcHRpb24iOiAiQXdhaXRpbmcgY2xvc2VvdXQiLAogICAgICAgICAgImNvbG9yIjogIjUzMTllNyIKICAgICAgICB9CiAgICAgIF0sCiAgICAgICJhc3NpZ25lZXMiOiBbCiAgICAgICAgImZpeHR1cmUtb3duZXIiCiAgICAgIF0sCiAgICAgICJtaWxlc3RvbmUiOiBudWxsLAogICAgICAidXBkYXRlZF9hdCI6ICIyMDI2LTEwLTAxVDEyOjAwOjAwWiIsCiAgICAgICJwYXJlbnRfaWQiOiBudWxsLAogICAgICAiY2hpbGRfaWRzIjogW10sCiAgICAgICJzdWJfaXNzdWVzX3N1bW1hcnkiOiB7CiAgICAgICAgInRvdGFsIjogMCwKICAgICAgICAiY29tcGxldGVkIjogMCwKICAgICAgICAicGVyY2VudF9jb21wbGV0ZWQiOiAwCiAgICAgIH0sCiAgICAgICJibG9ja2VkX2J5X2lkcyI6IFtdLAogICAgICAiYmxvY2tpbmdfaWRzIjogW10sCiAgICAgICJjbG9zaW5nX3ByX2lkcyI6IFtdLAogICAgICAiYmFja3BsYW5lX3JlY29yZCI6IHsKICAgICAgICAiY29kZSI6ICJDQVAxLjEiLAogICAgICAgICJuYW1lc3BhY2UiOiAiQ0FQMSIsCiAgICAgICAgImtpbmQiOiAib3V0Y29tZSIsCiAgICAgICAgImF1dGhvcml0eV9pZHMiOiBbCiAgICAgICAgICAiUzEiCiAgICAgICAgXQogICAgICB9LAogICAgICAiYWNjZXB0ZWRfZXZhbHVhdGlvbl9pZHMiOiBbCiAgICAgICAgIkVWMSIKICAgICAgXSwKICAgICAgImxpbWl0YXRpb25zIjogW10KICAgIH0KICBdLAogICJwdWxsX3JlcXVlc3RzIjogWwogICAgewogICAgICAiaWQiOiAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUhMjAxIiwKICAgICAgIm51bWJlciI6IDIwMSwKICAgICAgInVybCI6ICJodHRwczovL2dpdGh1Yi5jb20vZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUvcHVsbC8yMDEiLAogICAgICAidGl0bGUiOiAiUHJlc2VydmF0aW9uIGNvbnRyaWJ1dGlvbiIsCiAgICAgICJib2R5IjogIlJlZnMgIzEwMTsgY29udHJpYnV0ZXMgQUMxIGF0IFMxLiIsCiAgICAgICJzdGF0ZSI6ICJNRVJHRUQiLAogICAgICAiYmFzZV9yZWYiOiAibWFpbiIsCiAgICAgICJoZWFkX3JlZiI6ICJmaXh0dXJlLXByZXNlcnZhdGlvbiIsCiAgICAgICJtZXJnZWRfYXQiOiAiMjAyNi0xMC0wMVQxMTowMDowMFoiLAogICAgICAibWVyZ2VfY29tbWl0IjogImJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmIiLAogICAgICAicmV2aWV3X3N0YXR1cyI6ICJhY2NlcHRlZCIsCiAgICAgICJjbG9zaW5nX2lzc3VlX2lkcyI6IFtdLAogICAgICAiY2xvc3VyZV9pbnRlbnQiOiAiY29udHJpYnV0aW9uIiwKICAgICAgInVwZGF0ZWRfYXQiOiAiMjAyNi0xMC0wMVQxMjowMDowMFoiLAogICAgICAibGltaXRhdGlvbnMiOiBbXQogICAgfQogIF0sCiAgImF1dGhvcml0aWVzIjogWwogICAgewogICAgICAiaWQiOiAiUzEiLAogICAgICAia2luZCI6ICJzcGVjaWZpY2F0aW9uIiwKICAgICAgImxvY2F0b3IiOiAiZml4dHVyZTpzcGVjL1MxIiwKICAgICAgInJldmlzaW9uIjogImFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWEiLAogICAgICAiY29udGVudCI6ICJSMTogUHJlc2VydmUgYW4gZXhpc3RpbmcgdmFsaWQgaW5zdGFsbGF0aW9uLiBBQzEgaW1wbGVtZW50cyBSMS4iLAogICAgICAiYXZhaWxhYmlsaXR5IjogImF2YWlsYWJsZSIsCiAgICAgICJhcHByb3ZlciI6IG51bGwsCiAgICAgICJhcHByb3ZlZF9zY29wZSI6IG51bGwsCiAgICAgICJhcHByb3ZhbF9pZHMiOiBbCiAgICAgICAgIkExIgogICAgICBdLAogICAgICAibGltaXRhdGlvbnMiOiBbXQogICAgfSwKICAgIHsKICAgICAgImlkIjogIkExIiwKICAgICAgImtpbmQiOiAiYXBwcm92YWwiLAogICAgICAibG9jYXRvciI6ICJmaXh0dXJlOmFwcHJvdmFsL0ExIiwKICAgICAgInJldmlzaW9uIjogIjIwMjYtMTAtMDFUMTI6MDA6MDBaIiwKICAgICAgImNvbnRlbnQiOiAiRml4dHVyZSBhcHByb3ZlciBhcHByb3ZlZCBSMSBhbmQgQUMxIGF0IFMxLiIsCiAgICAgICJhdmFpbGFiaWxpdHkiOiAiYXZhaWxhYmxlIiwKICAgICAgImFwcHJvdmVyIjogImZpeHR1cmUtYXBwcm92ZXIiLAogICAgICAiYXBwcm92ZWRfc2NvcGUiOiAiUjEvQUMxIGF0IFMxIiwKICAgICAgImFwcHJvdmFsX2lkcyI6IFtdLAogICAgICAibGltaXRhdGlvbnMiOiBbXQogICAgfSwKICAgIHsKICAgICAgImlkIjogIkEyIiwKICAgICAgImtpbmQiOiAiYXBwcm92YWwiLAogICAgICAibG9jYXRvciI6ICJmaXh0dXJlOnJldmlldy9BMiIsCiAgICAgICJyZXZpc2lvbiI6ICIyMDI2LTEwLTAxVDEyOjAwOjAwWiIsCiAgICAgICJjb250ZW50IjogIkZpeHR1cmUgcmV2aWV3ZXIgYWNjZXB0ZWQgQUMxIGF0IFMxIGFuZCBkZWxpdmVyeSBCLiIsCiAgICAgICJhdmFpbGFiaWxpdHkiOiAiYXZhaWxhYmxlIiwKICAgICAgImFwcHJvdmVyIjogImZpeHR1cmUtcmV2aWV3ZXIiLAogICAgICAiYXBwcm92ZWRfc2NvcGUiOiAiQUMxIGF0IFMxL0IiLAogICAgICAiYXBwcm92YWxfaWRzIjogW10sCiAgICAgICJsaW1pdGF0aW9ucyI6IFtdCiAgICB9CiAgXSwKICAicmVxdWlyZW1lbnRzIjogWwogICAgewogICAgICAiaWQiOiAiUjFAUzEiLAogICAgICAia2V5IjogIlIxIiwKICAgICAgInRleHQiOiAiUHJlc2VydmUgYW4gZXhpc3RpbmcgdmFsaWQgaW5zdGFsbGF0aW9uLiIsCiAgICAgICJhdXRob3JpdHlfaWQiOiAiUzEiLAogICAgICAiYXV0aG9yaXR5X3JldmlzaW9uIjogImFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWEiCiAgICB9CiAgXSwKICAiY3JpdGVyaWEiOiBbCiAgICB7CiAgICAgICJpZCI6ICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDE6QUMxIiwKICAgICAgImlzc3VlX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICJrZXkiOiAiQUMxIiwKICAgICAgInRleHQiOiAiUHJlc2VydmUgdGhlIGV4aXN0aW5nIHZhbGlkIGluc3RhbGxhdGlvbi4iLAogICAgICAiYXV0aG9yaXR5X2lkIjogIlMxIiwKICAgICAgImF1dGhvcml0eV9yZXZpc2lvbiI6ICJhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhIiwKICAgICAgImRlbGl2ZXJ5X2NvbW1pdCI6ICJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiIiwKICAgICAgInJlcXVpcmVtZW50X2lkcyI6IFsKICAgICAgICAiUjFAUzEiCiAgICAgIF0KICAgIH0KICBdLAogICJkaXNwb3NpdGlvbnMiOiBbXSwKICAiY292ZXJhZ2UiOiBbCiAgICB7CiAgICAgICJpZCI6ICJDT1YxIiwKICAgICAgImlzc3VlX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICJjcml0ZXJpb25faWQiOiAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUjMTAxOkFDMSIsCiAgICAgICJyZXF1aXJlbWVudF9pZHMiOiBbCiAgICAgICAgIlIxQFMxIgogICAgICBdLAogICAgICAiY29udHJpYnV0aW9uX2lzc3VlX2lkcyI6IFsKICAgICAgICAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUjMTAxIgogICAgICBdLAogICAgICAicHJfaWRzIjogWwogICAgICAgICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSEyMDEiCiAgICAgIF0sCiAgICAgICJjb21iaW5lZF9yZXN1bHRfb3duZXIiOiAiZml4dHVyZS1vd25lciIsCiAgICAgICJzY29wZSI6ICJUaGUgc29sZSBmaXh0dXJlIGNyaXRlcmlvbiBpcyBjb3ZlcmVkIGJ5IHByZXNlcnZhdGlvbiBjb250cmlidXRpb24gUFIyMDEuIgogICAgfQogIF0sCiAgImV2YWx1YXRpb25zIjogWwogICAgewogICAgICAiaWQiOiAiRVYxIiwKICAgICAgImNyaXRlcmlvbl9pZCI6ICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDE6QUMxIiwKICAgICAgInJlcXVpcmVtZW50X2lkcyI6IFsKICAgICAgICAiUjFAUzEiCiAgICAgIF0sCiAgICAgICJ2ZXJpZmllZF9jb21taXQiOiAiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYiIsCiAgICAgICJtZXRob2QiOiAiRml4dHVyZSBwcmVzZXJ2YXRpb24gdmVyaWZpY2F0aW9uIiwKICAgICAgIm9ic2VydmVkX3Jlc3VsdCI6ICJQQVNTIHN1cHBsaWVkIGJ5IHRoZSBpbnZlbnRlZCBmaXh0dXJlLiIsCiAgICAgICJyZXN1bHQiOiAiU0FUSVNGSUVEIiwKICAgICAgIm9ic2VydmVkX2F0IjogIjIwMjYtMTAtMDFUMTI6MDA6MDBaIiwKICAgICAgImV2aWRlbmNlX2lkcyI6IFsKICAgICAgICAiRTEiLAogICAgICAgICJSVjEiCiAgICAgIF0sCiAgICAgICJyZXZpZXdfYXBwcm92YWxfaWRzIjogWwogICAgICAgICJBMiIKICAgICAgXSwKICAgICAgImFwcGxpY2FiaWxpdHkiOiAiY3VycmVudCIsCiAgICAgICJyZW1haW5pbmdfY29udHJpYnV0aW9ucyI6IFtdLAogICAgICAibGltaXRhdGlvbnMiOiBbXQogICAgfQogIF0sCiAgImV2aWRlbmNlIjogWwogICAgewogICAgICAiaWQiOiAiRTEiLAogICAgICAia2luZCI6ICJ2ZXJpZmljYXRpb24iLAogICAgICAibG9jYXRvciI6ICJmaXh0dXJlOnZlcmlmaWNhdGlvbi9FMSIsCiAgICAgICJyZXZpc2lvbiI6ICJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiIiwKICAgICAgInNoYTI1NiI6IG51bGwsCiAgICAgICJhdmFpbGFiaWxpdHkiOiAiYXZhaWxhYmxlIiwKICAgICAgImNvbnRlbnQiOiAiSW52ZW50ZWQgZml4dHVyZSByZXN1bHQ6IEFDMSBwYXNzZWQgcHJlc2VydmF0aW9uIHZlcmlmaWNhdGlvbiBhZ2FpbnN0IFMxIGFuZCBCLiIsCiAgICAgICJ2ZXJpZmllZF9jb21taXQiOiAiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYiIsCiAgICAgICJsaW1pdGF0aW9ucyI6IFtdCiAgICB9LAogICAgewogICAgICAiaWQiOiAiUlYxIiwKICAgICAgImtpbmQiOiAicmV2aWV3IiwKICAgICAgImxvY2F0b3IiOiAiZml4dHVyZTpyZXZpZXcvUlYxIiwKICAgICAgInJldmlzaW9uIjogImJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmIiLAogICAgICAic2hhMjU2IjogbnVsbCwKICAgICAgImF2YWlsYWJpbGl0eSI6ICJhdmFpbGFibGUiLAogICAgICAiY29udGVudCI6ICJJbnZlbnRlZCBmaXh0dXJlIHJldmlldyBhY2NlcHRlZCBBQzEgYXQgUzEvQi4iLAogICAgICAidmVyaWZpZWRfY29tbWl0IjogImJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYmIiLAogICAgICAibGltaXRhdGlvbnMiOiBbXQogICAgfQogIF0sCiAgImxpbWl0YXRpb25zIjogW10KfQo=\nDecoded UTF-8:\n{\n  \"format\": \"sp-bp-checkpoint/v1\",\n  \"capture\": {\n    \"id\": \"fixture-C1\",\n    \"started_at\": \"2026-10-01T12:10:00Z\",\n    \"finished_at\": \"2026-10-01T12:11:00Z\",\n    \"mode\": \"issues-only\",\n    \"status\": \"complete\",\n    \"origin\": \"invented-fixture\",\n    \"rechecks\": [\n      {\n        \"kind\": \"issue\",\n        \"id\": \"example/governance-fixture#101\",\n        \"initial_revision\": \"2026-10-01T12:00:00Z\",\n        \"final_revision\": \"2026-10-01T12:00:00Z\",\n        \"result\": \"unchanged\",\n        \"approval_ids\": [],\n        \"details\": \"Fixture full body/native relationships unchanged.\"\n      },\n      {\n        \"kind\": \"graph\",\n        \"id\": \"selected-native-graph\",\n        \"initial_revision\": \"fixture-graph-1\",\n        \"final_revision\": \"fixture-graph-1\",\n        \"result\": \"unchanged\",\n        \"approval_ids\": [],\n        \"details\": \"All selected connections enumerated and compared.\"\n      },\n      {\n        \"kind\": \"authority\",\n        \"id\": \"S1\",\n        \"initial_revision\": \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\",\n        \"final_revision\": \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\",\n        \"result\": \"unchanged\",\n        \"approval_ids\": [],\n        \"details\": \"Embedded fixture authority unchanged.\"\n      },\n      {\n        \"kind\": \"authority\",\n        \"id\": \"A1\",\n        \"initial_revision\": \"2026-10-01T12:00:00Z\",\n        \"final_revision\": \"2026-10-01T12:00:00Z\",\n        \"result\": \"unchanged\",\n        \"approval_ids\": [],\n        \"details\": \"Embedded fixture authority unchanged.\"\n      },\n      {\n        \"kind\": \"authority\",\n        \"id\": \"A2\",\n        \"initial_revision\": \"2026-10-01T12:00:00Z\",\n        \"final_revision\": \"2026-10-01T12:00:00Z\",\n        \"result\": \"unchanged\",\n        \"approval_ids\": [],\n        \"details\": \"Embedded fixture authority unchanged.\"\n      },\n      {\n        \"kind\": \"evidence\",\n        \"id\": \"E1\",\n        \"initial_revision\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\n        \"final_revision\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\n        \"result\": \"unchanged\",\n        \"approval_ids\": [],\n        \"details\": \"Embedded fixture evidence unchanged.\"\n      },\n      {\n        \"kind\": \"evidence\",\n        \"id\": \"RV1\",\n        \"initial_revision\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\n        \"final_revision\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\n        \"result\": \"unchanged\",\n        \"approval_ids\": [],\n        \"details\": \"Embedded fixture evidence unchanged.\"\n      },\n      {\n        \"kind\": \"delivery\",\n        \"id\": \"example/governance-fixture#101\",\n        \"initial_revision\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\n        \"final_revision\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\n        \"result\": \"unchanged\",\n        \"approval_ids\": [],\n        \"details\": \"Fixture current delivery B; source A identifies the capture context rather than the verified delivery.\"\n      }\n    ]\n  },\n  \"repository\": {\n    \"id\": \"example/governance-fixture\",\n    \"url\": \"https://github.com/example/governance-fixture\",\n    \"owner\": \"example\",\n    \"name\": \"governance-fixture\"\n  },\n  \"project\": null,\n  \"source\": {\n    \"commit\": \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"\n  },\n  \"scope\": {\n    \"issue_ids\": [\n      \"example/governance-fixture#101\"\n    ],\n    \"excluded_ids\": [],\n    \"external_records\": [],\n    \"collections\": [\n      {\n        \"name\": \"issues\",\n        \"owner_id\": \"example/governance-fixture\",\n        \"expected_total\": 1,\n        \"pages\": [\n          {\n            \"cursor_in\": null,\n            \"cursor_out\": null,\n            \"record_ids\": [\n              \"example/governance-fixture#101\"\n            ],\n            \"has_next_page\": false\n          }\n        ],\n        \"complete\": true\n      },\n      {\n        \"name\": \"subIssues\",\n        \"owner_id\": \"example/governance-fixture#101\",\n        \"expected_total\": 0,\n        \"pages\": [\n          {\n            \"cursor_in\": null,\n            \"cursor_out\": null,\n            \"record_ids\": [],\n            \"has_next_page\": false\n          }\n        ],\n        \"complete\": true\n      },\n      {\n        \"name\": \"blockedBy\",\n        \"owner_id\": \"example/governance-fixture#101\",\n        \"expected_total\": 0,\n        \"pages\": [\n          {\n            \"cursor_in\": null,\n            \"cursor_out\": null,\n            \"record_ids\": [],\n            \"has_next_page\": false\n          }\n        ],\n        \"complete\": true\n      },\n      {\n        \"name\": \"blocking\",\n        \"owner_id\": \"example/governance-fixture#101\",\n        \"expected_total\": 0,\n        \"pages\": [\n          {\n            \"cursor_in\": null,\n            \"cursor_out\": null,\n            \"record_ids\": [],\n            \"has_next_page\": false\n          }\n        ],\n        \"complete\": true\n      },\n      {\n        \"name\": \"closingPRReferences\",\n        \"owner_id\": \"example/governance-fixture#101\",\n        \"expected_total\": 0,\n        \"pages\": [\n          {\n            \"cursor_in\": null,\n            \"cursor_out\": null,\n            \"record_ids\": [],\n            \"has_next_page\": false\n          }\n        ],\n        \"complete\": true\n      },\n      {\n        \"name\": \"labels\",\n        \"owner_id\": \"example/governance-fixture#101\",\n        \"expected_total\": 1,\n        \"pages\": [\n          {\n            \"cursor_in\": null,\n            \"cursor_out\": \"fixture-L1\",\n            \"record_ids\": [\n              \"L1\"\n            ],\n            \"has_next_page\": false\n          }\n        ],\n        \"complete\": true\n      },\n      {\n        \"name\": \"assignees\",\n        \"owner_id\": \"example/governance-fixture#101\",\n        \"expected_total\": 1,\n        \"pages\": [\n          {\n            \"cursor_in\": null,\n            \"cursor_out\": null,\n            \"record_ids\": [\n              \"fixture-owner\"\n            ],\n            \"has_next_page\": false\n          }\n        ],\n        \"complete\": true\n      },\n      {\n        \"name\": \"pullRequests\",\n        \"owner_id\": \"example/governance-fixture\",\n        \"expected_total\": 1,\n        \"pages\": [\n          {\n            \"cursor_in\": null,\n            \"cursor_out\": null,\n            \"record_ids\": [\n              \"example/governance-fixture!201\"\n            ],\n            \"has_next_page\": false\n          }\n        ],\n        \"complete\": true\n      },\n      {\n        \"name\": \"closingIssuesReferences\",\n        \"owner_id\": \"example/governance-fixture!201\",\n        \"expected_total\": 0,\n        \"pages\": [\n          {\n            \"cursor_in\": null,\n            \"cursor_out\": null,\n            \"has_next_page\": false,\n            \"record_ids\": []\n          }\n        ],\n        \"complete\": true\n      }\n    ],\n    \"complete\": true\n  },\n  \"issues\": [\n    {\n      \"id\": \"example/governance-fixture#101\",\n      \"number\": 101,\n      \"url\": \"https://github.com/example/governance-fixture/issues/101\",\n      \"title\": \"Preserve an existing valid installation\",\n      \"body\": \"## Objective\\nPreserve an existing valid installation.\\n## Acceptance Criteria\\nAC1: Preserve the existing valid installation.\\n## Backplane Record\\nCode: CAP1.1; Kind: outcome; authority S1.\\n## Coverage and Satisfaction\\nAC1 maps to R1/S1; accepted evaluation EV1 at delivery B is SATISFIED.\\n\",\n      \"state\": \"OPEN\",\n      \"state_reason\": \"\",\n      \"issue_type\": {\n        \"id\": \"TYPE_FEATURE\",\n        \"name\": \"Feature\",\n        \"description\": \"Fixture native issue type\",\n        \"color\": \"GREEN\"\n      },\n      \"labels\": [\n        {\n          \"id\": \"L1\",\n          \"name\": \"backplane:review\",\n          \"description\": \"Awaiting closeout\",\n          \"color\": \"5319e7\"\n        }\n      ],\n      \"assignees\": [\n        \"fixture-owner\"\n      ],\n      \"milestone\": null,\n      \"updated_at\": \"2026-10-01T12:00:00Z\",\n      \"parent_id\": null,\n      \"child_ids\": [],\n      \"sub_issues_summary\": {\n        \"total\": 0,\n        \"completed\": 0,\n        \"percent_completed\": 0\n      },\n      \"blocked_by_ids\": [],\n      \"blocking_ids\": [],\n      \"closing_pr_ids\": [],\n      \"backplane_record\": {\n        \"code\": \"CAP1.1\",\n        \"namespace\": \"CAP1\",\n        \"kind\": \"outcome\",\n        \"authority_ids\": [\n          \"S1\"\n        ]\n      },\n      \"accepted_evaluation_ids\": [\n        \"EV1\"\n      ],\n      \"limitations\": []\n    }\n  ],\n  \"pull_requests\": [\n    {\n      \"id\": \"example/governance-fixture!201\",\n      \"number\": 201,\n      \"url\": \"https://github.com/example/governance-fixture/pull/201\",\n      \"title\": \"Preservation contribution\",\n      \"body\": \"Refs #101; contributes AC1 at S1.\",\n      \"state\": \"MERGED\",\n      \"base_ref\": \"main\",\n      \"head_ref\": \"fixture-preservation\",\n      \"merged_at\": \"2026-10-01T11:00:00Z\",\n      \"merge_commit\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\n      \"review_status\": \"accepted\",\n      \"closing_issue_ids\": [],\n      \"closure_intent\": \"contribution\",\n      \"updated_at\": \"2026-10-01T12:00:00Z\",\n      \"limitations\": []\n    }\n  ],\n  \"authorities\": [\n    {\n      \"id\": \"S1\",\n      \"kind\": \"specification\",\n      \"locator\": \"fixture:spec/S1\",\n      \"revision\": \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\",\n      \"content\": \"R1: Preserve an existing valid installation. AC1 implements R1.\",\n      \"availability\": \"available\",\n      \"approver\": null,\n      \"approved_scope\": null,\n      \"approval_ids\": [\n        \"A1\"\n      ],\n      \"limitations\": []\n    },\n    {\n      \"id\": \"A1\",\n      \"kind\": \"approval\",\n      \"locator\": \"fixture:approval/A1\",\n      \"revision\": \"2026-10-01T12:00:00Z\",\n      \"content\": \"Fixture approver approved R1 and AC1 at S1.\",\n      \"availability\": \"available\",\n      \"approver\": \"fixture-approver\",\n      \"approved_scope\": \"R1/AC1 at S1\",\n      \"approval_ids\": [],\n      \"limitations\": []\n    },\n    {\n      \"id\": \"A2\",\n      \"kind\": \"approval\",\n      \"locator\": \"fixture:review/A2\",\n      \"revision\": \"2026-10-01T12:00:00Z\",\n      \"content\": \"Fixture reviewer accepted AC1 at S1 and delivery B.\",\n      \"availability\": \"available\",\n      \"approver\": \"fixture-reviewer\",\n      \"approved_scope\": \"AC1 at S1/B\",\n      \"approval_ids\": [],\n      \"limitations\": []\n    }\n  ],\n  \"requirements\": [\n    {\n      \"id\": \"R1@S1\",\n      \"key\": \"R1\",\n      \"text\": \"Preserve an existing valid installation.\",\n      \"authority_id\": \"S1\",\n      \"authority_revision\": \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"\n    }\n  ],\n  \"criteria\": [\n    {\n      \"id\": \"example/governance-fixture#101:AC1\",\n      \"issue_id\": \"example/governance-fixture#101\",\n      \"key\": \"AC1\",\n      \"text\": \"Preserve the existing valid installation.\",\n      \"authority_id\": \"S1\",\n      \"authority_revision\": \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\",\n      \"delivery_commit\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\n      \"requirement_ids\": [\n        \"R1@S1\"\n      ]\n    }\n  ],\n  \"dispositions\": [],\n  \"coverage\": [\n    {\n      \"id\": \"COV1\",\n      \"issue_id\": \"example/governance-fixture#101\",\n      \"criterion_id\": \"example/governance-fixture#101:AC1\",\n      \"requirement_ids\": [\n        \"R1@S1\"\n      ],\n      \"contribution_issue_ids\": [\n        \"example/governance-fixture#101\"\n      ],\n      \"pr_ids\": [\n        \"example/governance-fixture!201\"\n      ],\n      \"combined_result_owner\": \"fixture-owner\",\n      \"scope\": \"The sole fixture criterion is covered by preservation contribution PR201.\"\n    }\n  ],\n  \"evaluations\": [\n    {\n      \"id\": \"EV1\",\n      \"criterion_id\": \"example/governance-fixture#101:AC1\",\n      \"requirement_ids\": [\n        \"R1@S1\"\n      ],\n      \"verified_commit\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\n      \"method\": \"Fixture preservation verification\",\n      \"observed_result\": \"PASS supplied by the invented fixture.\",\n      \"result\": \"SATISFIED\",\n      \"observed_at\": \"2026-10-01T12:00:00Z\",\n      \"evidence_ids\": [\n        \"E1\",\n        \"RV1\"\n      ],\n      \"review_approval_ids\": [\n        \"A2\"\n      ],\n      \"applicability\": \"current\",\n      \"remaining_contributions\": [],\n      \"limitations\": []\n    }\n  ],\n  \"evidence\": [\n    {\n      \"id\": \"E1\",\n      \"kind\": \"verification\",\n      \"locator\": \"fixture:verification/E1\",\n      \"revision\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\n      \"sha256\": null,\n      \"availability\": \"available\",\n      \"content\": \"Invented fixture result: AC1 passed preservation verification against S1 and B.\",\n      \"verified_commit\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\n      \"limitations\": []\n    },\n    {\n      \"id\": \"RV1\",\n      \"kind\": \"review\",\n      \"locator\": \"fixture:review/RV1\",\n      \"revision\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\n      \"sha256\": null,\n      \"availability\": \"available\",\n      \"content\": \"Invented fixture review accepted AC1 at S1/B.\",\n      \"verified_commit\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\n      \"limitations\": []\n    }\n  ],\n  \"limitations\": []\n}\n",
      "verified_commit": null,
      "limitations": [
        "Supplied/local fixture evidence; no integrated verification."
      ]
    },
    {
      "id": "CASE-ADR",
      "kind": "other",
      "locator": "docs/decisions/ADR-0001-001-reviewed.txt",
      "revision": "8c17629083473556a12bb857e08016b1f302b2b49fc4a1b2b5497f0f952add81",
      "sha256": "8c17629083473556a12bb857e08016b1f302b2b49fc4a1b2b5497f0f952add81",
      "availability": "available",
      "content": "ADR-0001 edition1 reviewed proposal. Observed LF bytes differ from recorded CRLF hash; exact CRLF reconstruction SHA256=033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c. Remote owns this case architecture.json only.\nExact observed bytes (base64): IyBBRFItMDAwMSBlZGl0aW9uIDE6IGZpeHR1cmUgc291cmNlIGF1dGhvcml0eQoKRHJhZnQ6IHJlbW90ZSBvd25zIHNvdXJjZV9vZl90cnV0aC4gU2NvcGU6IHRoaXMgY2FzZSdzIGFyY2hpdGVjdHVyZS5qc29uIG9ubHkuCkFsdGVybmF0aXZlczogbG9jYWwgcHJvamVjdCBhdXRob3JpdHkgb3IgYSByZW1vdGUgY2Fub25pY2FsIGF1dGhvcml0eS4gUmF0aW9uYWxlOiB0aGUgZml4dHVyZSdzIHNlbGVjdGVkIHByb2R1Y3QgY29udHJhY3QgdXNlcyByZW1vdGUuIENvbmZpcm1hdGlvbjogaW5zcGVjdCBhcmNoaXRlY3R1cmUuanNvbiBhbmQgaXRzIHJldmlld2VkIGFwcHJvdmFsLiBObyBwdWJsaWNhdGlvbiBvciB1bnJlbGF0ZWQgb3BlcmF0aW9uIGF1dGhvcml0eS4K\nDecoded UTF-8:\n# ADR-0001 edition 1: fixture source authority\n\nDraft: remote owns source_of_truth. Scope: this case's architecture.json only.\nAlternatives: local project authority or a remote canonical authority. Rationale: the fixture's selected product contract uses remote. Confirmation: inspect architecture.json and its reviewed approval. No publication or unrelated operation authority.\n",
      "verified_commit": null,
      "limitations": [
        "Supplied/local fixture evidence; no integrated verification."
      ]
    },
    {
      "id": "CASE-ADR-ADMIN",
      "kind": "other",
      "locator": "docs/decisions/ADR-0001-001-fixture-source-authority.md",
      "revision": "f8fcc26187632256bf513dc32c3bc27ff06cc83b3b66fca3e7903181252ae9d9",
      "sha256": "f8fcc26187632256bf513dc32c3bc27ff06cc83b3b66fca3e7903181252ae9d9",
      "availability": "available",
      "content": "Later administrative Current/approval metadata; not the original reviewed proposal bytes.\nExact observed bytes (base64): LS0tCmlkOiBBRFItMDAwMQp0aXRsZTogRml4dHVyZSBzb3VyY2UgYXV0aG9yaXR5CnJldmlzaW9uOiAxCnN0YXRlOiBDdXJyZW50CmRlY2lzaW9uX2RhdGU6IDIwMjYtMTEtMTUKcmV2aXNpb25fZGF0ZTogMjAyNi0xMS0xNQphcHByb3ZlZF9ieTogZmljdGlvbmFsIGZpeHR1cmUgb3BlcmF0b3IKYXBwcm92ZWRfcmV2aXNpb246IDEKYXBwcm92YWxfcmVmOiBhcHByb3ZhbC50eHQKLS0tCgojIEFEUi0wMDAxIGVkaXRpb24gMTogZml4dHVyZSBzb3VyY2UgYXV0aG9yaXR5CgpBcHByb3ZlZCBjaG9pY2U6IHJlbW90ZSBvd25zIHNvdXJjZV9vZl90cnV0aC4gU2NvcGU6IHRoaXMgY2FzZSdzIGFyY2hpdGVjdHVyZS5qc29uIG9ubHkuCkFsdGVybmF0aXZlczogbG9jYWwgcHJvamVjdCBhdXRob3JpdHkgb3IgYSByZW1vdGUgY2Fub25pY2FsIGF1dGhvcml0eS4gUmF0aW9uYWxlOiB0aGUgZml4dHVyZSdzIHNlbGVjdGVkIHByb2R1Y3QgY29udHJhY3QgdXNlcyByZW1vdGUuIENvbmZpcm1hdGlvbjogaW5zcGVjdCBhcmNoaXRlY3R1cmUuanNvbiBhbmQgaXRzIHJldmlld2VkIGFwcHJvdmFsLiBObyBwdWJsaWNhdGlvbiBvciB1bnJlbGF0ZWQgb3BlcmF0aW9uIGF1dGhvcml0eS4KCkFkbWluaXN0cmF0aXZlIGFwcHJvdmFsIGNhcHR1cmUgb25seTsgb3JpZ2luYWwgcmV2aWV3ZWQgYnl0ZXMgYXJlIHJldGFpbmVkIGF0IEFEUi0wMDAxLTAwMS1yZXZpZXdlZC50eHQsIFNIQTI1NiAwMzNhMTRjNjdiYjI0ZTIwODAwOTA4ODcyZjM0NmI5ZjczNzBhNWMyY2Y1NGEzYTZmYTY1ZDM0ZTJhZGMzYzFjLiBObyBjaG9pY2UgY2hhbmdlZC4K\nDecoded UTF-8:\n---\nid: ADR-0001\ntitle: Fixture source authority\nrevision: 1\nstate: Current\ndecision_date: 2026-11-15\nrevision_date: 2026-11-15\napproved_by: fictional fixture operator\napproved_revision: 1\napproval_ref: approval.txt\n---\n\n# ADR-0001 edition 1: fixture source authority\n\nApproved choice: remote owns source_of_truth. Scope: this case's architecture.json only.\nAlternatives: local project authority or a remote canonical authority. Rationale: the fixture's selected product contract uses remote. Confirmation: inspect architecture.json and its reviewed approval. No publication or unrelated operation authority.\n\nAdministrative approval capture only; original reviewed bytes are retained at ADR-0001-001-reviewed.txt, SHA256 033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c. No choice changed.\n",
      "verified_commit": null,
      "limitations": [
        "Supplied/local fixture evidence; no integrated verification."
      ]
    },
    {
      "id": "CASE-APPROVAL",
      "kind": "approval",
      "locator": "docs/decisions/approval.txt",
      "revision": "42d2e19b098d86783af19326023fdbd3db31f14d37af9398d25d15263d26a50a",
      "sha256": "42d2e19b098d86783af19326023fdbd3db31f14d37af9398d25d15263d26a50a",
      "availability": "available",
      "content": "Actual fictional staged approval interaction, separate from design/plan approval; identifies ADR-0001 edition1 and reviewed CRLF hash.\nExact observed bytes (base64): RklDVElPTkFMIFNUQUdFRCBFVkFMVUFUSU9OIElOUFVULCBub3QgcmVhbCBhcHByb3ZhbC4gRml4dHVyZSBvcGVyYXRvciBvbiAyMDI2LTExLTE1OiAiQXBwcm92ZSBBRFItMDAwMSBlZGl0aW9uIDEgYXMgd3JpdHRlbiIsIGV4YWN0IHJldmlld2VkIFNIQTI1NiAwMzNhMTRjNjdiYjI0ZTIwODAwOTA4ODcyZjM0NmI5ZjczNzBhNWMyY2Y1NGEzYTZmYTY1ZDM0ZTJhZGMzYzFjLiBTb3VyY2UgY29udGV4dDogdGhpcyBpbnZlbnRlZCB0ZXN0IGNhc2UsIHNlcGFyYXRlIGZyb20gaXRzIHBsYW4vZGVzaWduIGFwcHJvdmFsLiBUaGlzIGNvdmVycyByZW1vdGUgYXV0aG9yaXR5IGluIGFyY2hpdGVjdHVyZS5qc29uLgo=\nDecoded UTF-8:\nFICTIONAL STAGED EVALUATION INPUT, not real approval. Fixture operator on 2026-11-15: \"Approve ADR-0001 edition 1 as written\", exact reviewed SHA256 033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c. Source context: this invented test case, separate from its plan/design approval. This covers remote authority in architecture.json.\n",
      "verified_commit": null,
      "limitations": [
        "Supplied/local fixture evidence; no integrated verification."
      ]
    },
    {
      "id": "CASE-ISSUE",
      "kind": "other",
      "locator": "issue.json",
      "revision": "a4883b8b1f889f6b337db447da4bb8baeece4dd2ebfdfaca84daa117cb05fcd0",
      "sha256": "a4883b8b1f889f6b337db447da4bb8baeece4dd2ebfdfaca84daa117cb05fcd0",
      "availability": "available",
      "content": "Complete supplied native response retained; unchanged input.\nExact observed bytes (base64): ewogICJudW1iZXIiOiAxMDUsCiAgInRpdGxlIjogImNoZWNrcG9pbnQtY2FwdHVyZSIsCiAgImJvZHkiOiAiIyMgT2JqZWN0aXZlXG5BcHBseSB0aGUgc2VsZWN0ZWQgc291cmNlLWF1dGhvcml0eSBjaG9pY2UgbG9jYWxseS5cbiMjIEJvdW5kZWQgU2NvcGVcbiMjIyBBbGxvd2VkXG5UaGlzIGNhc2Ugb25seTogcmVxdWVzdGVkIGRlbGl2ZXJhYmxlL2NhcHR1cmUgYW5kIHNwZWxsaW5nIGNvcnJlY3Rpb24uXG4jIyMgT3V0IG9mIFNjb3BlXG5MaXZlIGlzc3VlIGNoYW5nZXMgYW5kIHB1YmxpY2F0aW9uLlxuIyMgQWNjZXB0YW5jZSBDcml0ZXJpYVxuU291cmNlIGNob2ljZSBtYXRjaGVzIGFuIGFwcGxpY2FibGUgYXBwcm92ZWQgZGVjaXNpb247IHNwZWxsaW5nIGNvcnJlY3RlZC5cbiMjIFZlcmlmaWNhdGlvbiBTZWFtc1xuUmVhZCBleGFjdCBsb2NhbCBhcmNoaXRlY3R1cmUuanNvbiBhbmQgc3VwcGxpZWQgY2hlY2tzLmpzb24uXG4jIyBTdXBlcnBvd2VycyBBcnRpZmFjdHNcbkFwcHJvdmVkIHNwZWMubWQgYW5kIHBsYW4ubWQ7IGV4YWN0IGRlY2lzaW9uIGFuZCBhcHByb3ZhbCBmaWxlcyB1bmRlciBkb2NzL2RlY2lzaW9ucy5cbiIsCiAgInN0YXRlIjogIk9QRU4iLAogICJzdGF0ZVJlYXNvbiI6ICIiLAogICJpc3N1ZVR5cGUiOiBudWxsLAogICJsYWJlbHMiOiBbCiAgICB7CiAgICAgICJuYW1lIjogImJhY2twbGFuZTphY3RpdmUiCiAgICB9CiAgXSwKICAicGFyZW50IjogbnVsbCwKICAic3ViSXNzdWVzIjogewogICAgIm5vZGVzIjogW10sCiAgICAidG90YWxDb3VudCI6IDAKICB9LAogICJzdWJJc3N1ZXNTdW1tYXJ5IjogewogICAgImNvbXBsZXRlZCI6IDAsCiAgICAicGVyY2VudENvbXBsZXRlZCI6IDAsCiAgICAidG90YWwiOiAwCiAgfSwKICAiYmxvY2tlZEJ5IjogewogICAgIm5vZGVzIjogW10sCiAgICAidG90YWxDb3VudCI6IDAKICB9LAogICJibG9ja2luZyI6IHsKICAgICJub2RlcyI6IFtdLAogICAgInRvdGFsQ291bnQiOiAwCiAgfSwKICAiY2xvc2VkQnlQdWxsUmVxdWVzdHNSZWZlcmVuY2VzIjogW10sCiAgInVwZGF0ZWRBdCI6ICIyMDI2LTExLTE1VDAwOjAwOjAwWiIsCiAgInVybCI6ICJodHRwczovL2V4YW1wbGUuaW52YWxpZC9maXh0dXJlL2lzc3Vlcy8xMDUiCn0K\nDecoded UTF-8:\n{\n  \"number\": 105,\n  \"title\": \"checkpoint-capture\",\n  \"body\": \"## Objective\\nApply the selected source-authority choice locally.\\n## Bounded Scope\\n### Allowed\\nThis case only: requested deliverable/capture and spelling correction.\\n### Out of Scope\\nLive issue changes and publication.\\n## Acceptance Criteria\\nSource choice matches an applicable approved decision; spelling corrected.\\n## Verification Seams\\nRead exact local architecture.json and supplied checks.json.\\n## Superpowers Artifacts\\nApproved spec.md and plan.md; exact decision and approval files under docs/decisions.\\n\",\n  \"state\": \"OPEN\",\n  \"stateReason\": \"\",\n  \"issueType\": null,\n  \"labels\": [\n    {\n      \"name\": \"backplane:active\"\n    }\n  ],\n  \"parent\": null,\n  \"subIssues\": {\n    \"nodes\": [],\n    \"totalCount\": 0\n  },\n  \"subIssuesSummary\": {\n    \"completed\": 0,\n    \"percentCompleted\": 0,\n    \"total\": 0\n  },\n  \"blockedBy\": {\n    \"nodes\": [],\n    \"totalCount\": 0\n  },\n  \"blocking\": {\n    \"nodes\": [],\n    \"totalCount\": 0\n  },\n  \"closedByPullRequestsReferences\": [],\n  \"updatedAt\": \"2026-11-15T00:00:00Z\",\n  \"url\": \"https://example.invalid/fixture/issues/105\"\n}\n",
      "verified_commit": null,
      "limitations": [
        "Supplied/local fixture evidence; no integrated verification."
      ]
    },
    {
      "id": "CASE-CHECK",
      "kind": "verification",
      "locator": "checks.json",
      "revision": "ea39059cd0be01dd996eb368134acb112a00cfa1a83c374843029cd0bc8c99ec",
      "sha256": "ea39059cd0be01dd996eb368134acb112a00cfa1a83c374843029cd0bc8c99ec",
      "availability": "available",
      "content": "Supplied PASS scope is JSON syntax only, no architectural or integrated acceptance.\nExact observed bytes (base64): eyJmaXh0dXJlX3Jlc3VsdCI6ICJQQVNTIiwgInNjb3BlIjogIkpTT04gc3ludGF4IG9ubHk7IG5vIGFyY2hpdGVjdHVyYWwgYXBwcm92YWwgb3IgaW50ZWdyYXRlZCBhY2NlcHRhbmNlIGVzdGFibGlzaGVkIn0K\nDecoded UTF-8:\n{\"fixture_result\": \"PASS\", \"scope\": \"JSON syntax only; no architectural approval or integrated acceptance established\"}\n",
      "verified_commit": null,
      "limitations": [
        "Supplied/local fixture evidence; no integrated verification."
      ]
    },
    {
      "id": "CASE-LOCAL",
      "kind": "other",
      "locator": "architecture.json",
      "revision": "ddc7bb041abb7b21731a37a18bc02120454b57138a82a5879e5c09f06e8e412c",
      "sha256": "ddc7bb041abb7b21731a37a18bc02120454b57138a82a5879e5c09f06e8e412c",
      "availability": "available",
      "content": "Observed local source authority; unchanged during capture.\nExact observed bytes (base64): ewogICJzb3VyY2Vfb2ZfdHJ1dGgiOiAibG9jYWwiCn0K\nDecoded UTF-8:\n{\n  \"source_of_truth\": \"local\"\n}\n",
      "verified_commit": null,
      "limitations": [
        "Supplied/local fixture evidence; no integrated verification."
      ]
    },
    {
      "id": "CASE-README",
      "kind": "other",
      "locator": "README.md",
      "revision": "34ae2fe6f773205cb6c8d20ff1c3d7f433adb29432e83bc3128e5daa39c876b0",
      "sha256": "34ae2fe6f773205cb6c8d20ff1c3d7f433adb29432e83bc3128e5daa39c876b0",
      "availability": "available",
      "content": "Observed independently corrected spelling.\nExact observed bytes (base64): VGhpcyBpcyB0aGUgaW5kZXBlbmRlbnQgZml4dHVyZSBub3RlLgo=\nDecoded UTF-8:\nThis is the independent fixture note.\n",
      "verified_commit": null,
      "limitations": [
        "Supplied/local fixture evidence; no integrated verification."
      ]
    },
    {
      "revision": "0702f984e007ab20095def7ed9967bfafeecdf5543ebf01ad5dfb59c40bae880",
      "kind": "other",
      "content": "# Superpowers Backplane governance\n\nBackplane connects approved product obligations to native GitHub work,\nSuperpowers execution, and inspectable delivery evidence. Read the issue for\ncurrent intent and lifecycle, the approved design for behavior, the plan for\nexecution, and accepted evidence for satisfaction. A Project or repository\ncheckpoint presents those sources; it does not replace them.\n\n[Lite and heavy modes](modes.md) define the scope of Backplane participation.\nRequirements tracking, labels, backlog/release monitoring and handoffs belong\nto Backplane; the template refers here rather than defining another lifecycle.\nThe [repository release-policy binding](../release-policy.md) governs Backplane's\nown releases. Consumer policy still governs consumer releases and product records.\n\n## Ownership and authority\n\n| Concern | Owner/source | Consequence |\n| --- | --- | --- |\n| Product purpose and constraints | Project instructions and approved product/architecture material | Keep the project's existing PRD-equivalent authority; no universal new document. |\n| Work identity, scope, acceptance, hierarchy, dependencies, lifecycle | Native GitHub issue and relationships | Use repository plus issue URL/number; preserve full native intake. |\n| Design | Human-approved complete issue body for bounded work, or approved specification for a cross-cutting decision | Both paths are valid. Resolve conflicts with the approver. |\n| Execution | Current approved issue-bound Superpowers plan | Record consumed issue/design revisions and project verification seams. |\n| Criterion satisfaction | Accepted immutable project-owned evaluation evidence | Bind the verdict to exact approved criteria and delivery inputs. |\n| Presentation | Issue-backed Project items, optional views/mirrors | Refresh from canonical sources; display state is not execution authority. |\n| Portable account | Dated committed repository checkpoint | Explain captured state and limitations; reconcile before live action. |\n\nApproval identifies the approver, artifact/revision, accepted scope, and source\nof the decision. A specification refines behavior without silently amending an\nissue's scope. A discrepancy requires explicit reconciliation. Changed timestamps\ntrigger semantic comparison; they prove neither a behavioral change nor freshness.\n\nAn existing bounded approved issue may proceed to planning without repeating\nbrainstorming. Cross-cutting behavior uses a reviewed specification. Backplane\nsurrounds upstream Superpowers; it adds no alternate development lifecycle.\n\nAt consequential design, planning, start, execution, review and capture boundaries,\nfollow the focused [architectural-decision integration](../../skills/managing-superpowers-backlog/references/architectural-decisions.md).\nProject ADRs own decisions and their actual approval; Backplane preserves references\nusing existing issue/spec/plan and typed evidence records. Reuse covered approvals,\ncontinue independent authorized work, and withhold dependent work/claims when\nrequired approval is unavailable. This adds no lifecycle or checkpoint schema.\n\n## Product identity and decomposition\n\nA project supplies its code legend. For example, `INSTALL1` is a capability and\n`INSTALL1.1` is an outcome; these are invented mnemonic examples, not prescribed\nsyntax, ordering, dates, or versions. Codes are unique within their declared\nnamespace and remain stable when release targets or parentage change. Preserve\nissue identities and an approved alias history when migration is necessary.\nDo not derive live parentage from the spelling of a code.\n\nUse record kinds `capability`, `outcome`, `gate`, and `external-boundary`.\nA grouping capability is not an implementation leaf. A small feature may itself\nbe the bounded outcome; do not create redundant layers. Native issue types are\nused where available; the Backplane kind does not require custom organization\ntypes. An external boundary names its actual owner and prerequisite. Link that\nowner's issue when available; otherwise keep the boundary explicitly unresolved.\n\nParticipating issues maintain three issue-owned sections:\n\n| Section | Contents |\n| --- | --- |\n| `Backplane Record` | Code, kind, code namespace, design/plan/approval and coverage references. |\n| `Obligation Dispositions` | Parent obligation and governing revision, bounded child contributions or accepted evidence, owner, approved deferral/exclusion, unresolved gaps. |\n| `Coverage and Satisfaction` | Current criterion-to-requirement mappings and pointers to accepted evaluations, including changed-input and outstanding-contribution findings. |\n\nNative parent and dependency relationships stay native. The body references\nthose relationships without maintaining a separately editable duplicate graph.\nThese sections support declared governance participation; they do not silently\nmigrate every legacy issue or invalidate the existing bounded-issue contract.\n\nAccount for every approved parent obligation through bounded child outcomes,\neligible existing satisfaction evidence, or an explicitly approved disposition.\nReject omissions, unrelated additions, and ambiguous duplicated ownership.\nShared coverage is valid when contribution boundaries and the owner accepting\nthe combined result are explicit. Preserve the existing issue when it matches;\nclassify proposed new work and unresolved questions separately. Decomposition\napproval alone authorizes no issue creation, selection, or readiness transition.\n\nDeferral/exclusion records identify their approver, governing revision, rationale,\nand revisit condition where applicable. They remain visible and do not count\nas delivered. A child closed as not planned does not satisfy its obligation;\nits parent needs approved alternative coverage or a scope disposition.\nDependencies establish readiness, not priority. Parentage describes decomposition,\nnot execution order. No priority is inferred from list order or codes.\n\n## Coverage and satisfaction\n\nA requirement reference includes its governing issue/document identity, stable\ncriterion/statement key, approved revision, and wording. Retain a project's\nexisting identifiers. Line numbers and checkbox positions are not durable keys.\nMany requirements may map to one outcome, and several issues/PRs may contribute\nto one criterion. State each contribution's scope and combined-result owner.\n\nThe outcome issue owns the current mappings and latest accepted evaluation\npointers. The evaluation is immutable evidence with exact inputs, method,\nobserved result, delivery/integration identity, review/acceptance disposition,\nevidence identity/availability, and remaining obligations. Preserve historical\nevaluations against their original revisions. Parent summaries reference child\nresults rather than maintaining independent verdict copies.\n\n| Result | Meaning |\n| --- | --- |\n| `SATISFIED` | Applicable obligations have accepted passing evidence against the exact reconciled current inputs. |\n| `UNSATISFIED` | Accepted evidence establishes an unmet applicable obligation. |\n| `UNKNOWN` | Execution, input matching, evidence, or acceptance is unavailable or unverified. |\n\nDeferral and exclusion are scope dispositions, separate from this result\nvocabulary. Missing evidence is UNKNOWN, not success or a fabricated failure.\nFeature satisfaction requires every applicable obligation to be satisfied,\nwith approved excluded/deferred scope separately disclosed.\n\nA behavior-changing requirement or implementation delta makes affected current\nclaims unsupported until evidence is reconciled/revalidated. A prior pass at\ncommit B does not prove commit C. An editorial revision may retain matching\nevidence only with explicit semantic equivalence and unchanged relevant delivery\ninputs. A timestamp alone cannot supply that equivalence. Project/checkpoint\nsatisfaction displays derive from the reconciled evidence and disclose gaps.\n\n## GitHub presentation\n\nIntegrated Projects are the normal proposed presentation for these bridges.\nAn explicitly declared `issues-only` compatibility mode preserves the same\nidentity, coverage, evidence, and lifecycle rules. Ordinary existing backlog\nstatus/selection operations continue to use native issues without a Project\nprerequisite. Before a checkpoint capture, declare its scope and mode.\n\nUse issue-backed items and four views: product/decomposition, execution,\nsatisfaction, and release targets. Native Title, issue type where available,\nlabels, assignees, parent issue, sub-issue progress, milestones, and PR context\npresent their source records. Optional `Code`, `Kind`, and `Satisfaction` mirrors\nrefresh from issue sections and accepted evidence. Define who refreshes them\nand when; mirrors are not automatic semantic synchronization.\n\nAn optional Project Status field has an explicit project-owned mapping to issue\nlabels/native state. It is presentation, never a second readiness gate. Done\ncannot override an issue in review or UNKNOWN integrated checks. Closed-child\ncounts count closures, not satisfied obligations. A milestone groups targets;\nit does not authorize publication.\n\nDenied Project capture in declared integrated mode is incomplete capture. Retain\nthat mode and the limitation; do not silently switch to issues-only or invent\ninaccessible values. Missing custom issue types need no new organization types.\nProject drafts and Discussions may support preliminary deliberation; they are\nnot approved executable work. Forms/templates, review rules, and Releases have\nproject-specific roles rather than becoming universal dependencies.\n\n## Bridge operations and Superpowers sequence\n\n1. Read current project authority and complete native issue context.\n2. Consume an approved product/design result and assess complete decomposition.\n3. Reconcile proposed/existing records and native relationships through an\n   explicitly authorized intake operation.\n4. Plan one bounded selected issue against current issue/design revisions,\n   approved acceptance criteria, and project-owned verification seams.\n5. Validate eligibility, then follow Superpowers isolation, execution, TDD,\n   review, verification, and branch finishing under project rules.\n6. Track PR contributions and remaining obligations through review/integration.\n7. After accepted integration, run fresh project checks, reconcile satisfaction\n   and authorized issue/Project closeout, then refresh the portable checkpoint.\n8. Evaluate release inclusion/publication under separate release authority.\n\nUse the existing six Backplane lifecycle labels and open/closed state as defined\nin the native issue contract. Keep exactly one lifecycle label on open tracked\nissues and preserve unrelated labels. A prepared worktree, checked task, commit,\nPR, or merge alone does not prove the next lifecycle gate.\n\nThe named operations are `decompose/intake`, `PR closeout`, and `capture\ncheckpoint`. Focused references define their input/output contracts. Supporting\ntools may contribute inspectable findings or decisions; none becomes a required\nskill bundle, approval authority, helper engine, or language runtime.\n\n## PR contributions and completion\n\nA PR records affected issue/design/plan revisions, criterion contributions,\nreview disposition, verification inputs/results, and closure intent. A design\nPR establishes design, a partial PR contributes scoped delivery, and accepted\nreview/branch checks still await integration. Use neutral contribution references\nwhile integrated evidence is pending. A closing keyword is closure intent,\nnot proof of a native closure relationship or satisfied outcome; nondefault\nintegration targets require observed native behavior rather than assumption.\n\nReview acceptance, merge, integrated verification, satisfaction, issue/parent\ncompletion, and release are distinct. If automatic closure outruns verification,\nreport the actual closed state and unmet obligations. Propose the appropriate\nrecovery under project authority; do not reopen or edit labels unrequested.\n\nVerified closeout names the accepted integration commit and approved requirement\nrevision, updates issue-owned evaluation pointers, refreshes parent references\nand Project projections, and captures a dated repository checkpoint. Preserve\nold evidence. A later checkpoint/evidence storage commit refers to the verified\nfeature commit; it cannot claim its own future merge was already checked.\nKeep the implementation workspace for pending review fixes; cleanup follows\nupstream/project ownership and authorized branch finishing.\n\n## Portable repository record and working state\n\nThe product checkpoint pair is `.sp-bp/state.md` plus\n`.sp-bp/github-state.json`, format `sp-bp-checkpoint/v1`. It records captured\noutcome/criterion wording, source graph and revisions, design/plan/approval\nanchors, dispositions, many-to-many coverage, evidence-backed claims and\navailability limitations. It is a dated account, not an offline mutable backlog.\n\nDeclare capture scope/mode and start/end observations. Enumerate every required\npage, preserve excluded/external scope, and recheck the source revisions used.\nA missing page, denied capture, changed relevant source, unavailable required\nevidence, mismatched capture IDs/digest, or contradictory readable claims prevents\na complete/current replacement. Retain the last accepted pair. A partial\ncandidate may be kept as a clearly labelled diagnostic.\n\nStage candidates and a transaction receipt under ignored `.sp-bp/work/`.\nValidate exact JSON bytes, shared capture ID, readable/structured semantic equality,\nscope, references, and evidence before installing outputs. Check prior outputs\nand index ownership; user edits stop automatic overwrite/recovery. The local\nacceptance point is one verified Git commit containing both validated blobs.\nRemote integration is separately observed. Filesystem copies and GitHub capture\nare not atomic. Store the acceptance commit in the external receipt, avoiding\nself-referential content hashes. Recovery verifies prior/candidate ownership and\nrestores only the pair and its index entries under applicable authority.\n\nRefresh after approved decomposition intake, material coverage/scope changes,\nverified closeout, and release review. Routine task edits need no product\ncapture. Offline records explain their captured state but cannot establish live\neligibility or authorize replay into GitHub. Reconcile after access returns.\n\nScratch is disposable. For this repository's issue-31 execution, the separately\ntracked execution summary and supporting evidence preserve progress across\nmachine/harness boundaries under the existing handoff approach. Verify transport\nand arrival before claiming another host can resume. This does not introduce a\nnew general session-handoff system or make scratch the sole authority.\n\n## Superpowers freshness evidence\n\nBackplane owns its direct SP alignment and publishes dated compatibility/freshness\nevidence. Follow the stable upstream channel by default; edge and revision\nchanges need their applicable explicit authorization. The bundle consumes that\ncue and owns complete-stack integration. Adopters verify their actual tuple and\nproject overrides. An older bundle pin is not Backplane's support policy.\n\nReturn these fields for a freshness assessment:\n\n- **Ownership and channel policy:** Backplane owns direct SP alignment and\n  follows stable by default; identify any explicitly selected edge exception.\n  Name the bundle's complete-stack owner and the adopter's tuple/override role.\n- **Evaluation:** exact SP/Backplane revisions, tested host/capabilities and\n  overrides, supported results, and unavailable or untested scope.\n- **Publication and next action:** local versus published evidence, verified\n  transport/arrival or its absence, and proposed versus authorized operations.\n\nA cue identifies latest stable observed at a checked time, exact evaluated SP\nand Backplane revisions, relevant artifact hashes and project overrides,\nharness/capability scope, results, and unresolved limitations. Classify the latest\nstable target as verified compatible, untested, or incompatible with the evidence\nand reason. An older pass does not establish currentness; an installed version\nalone does not establish compatibility. Local/uncommitted evidence is not a\npublished cue, and one host/override does not establish all harnesses/workflows.\nPublish immutable scoped evidence with the advertised Backplane revision. Before\nconsuming it as a published cue, verify authorized transport to the advertised\ntarget and arrival there: the exact commit/artifact identities must be reachable\nand their supporting evidence inspectable by the consumer. A local accepted\ncommit, proposed publication, or URL alone does not demonstrate that arrival.\nNeither cue nor bundle preference\nauthorizes automatic installation changes.\n\n## Boundaries and worked example\n\nBackplane documents use `docs/superpowers-backplane/`; optional local state uses\n`.sp-bp/`. Ignore only `.sp-bp/work/` before use and keep the product pair trackable.\nNever write to `.superpowers/`, shipped upstream, or discovery targets within\nupstream. A helper whose default writes there is prohibited even when its visible\noutput is redirected. Preserve upstream independently. A supported native\nbookkeeping exception must be explicitly scoped and demonstrated; it is not an\nupstream redirection feature. Git, authenticated gh, and operational Superpowers\nare required; project language/runtime and verification remain project-owned.\n\nInvented example: `INSTALL1` owns O1 source adoption, O2 discovery, and O3\npreservation. Existing outcome `INSTALL1.1` covers O1. Two proposed outcomes split\nO2 into enumeration and invocation with an explicit combined-result owner; accepted\nE3 covers O3 at S1. An approved O2 deferral is a separate valid disposition,\nnot delivery. The parent issue maintains those dispositions and native child links.\nA bounded documentation correction can use its approved issue body as design;\na shared coverage change uses an approved specification. Each executable leaf\nstill needs its own current approved plan and clear dependencies.\n\nA design PR establishes S1, a package PR contributes O1, and a verification PR\ncontributes discovery. Partial delivery or accepted review alone cannot close\nthe outcome. Fresh accepted checks at integrated commit B justify applicable\ncriterion satisfaction and authorized closeout. A later checkpoint commit K\ncaptures that result as evidence for B, with its own capture limitations; K is\nnot substituted for B. Release remains separate. If S2 or commit C changes\nrelevant behavior, preserve B's history and revalidate the affected current claims.\n\nAuthority: approved issue-31 specification and implementation plan, current\nproject rules, and the existing backlog issue/lifecycle/installation contracts.\nThis doctrine defines the approved policy; verification records establish which\ninstalled behavior has actually been demonstrated.\n",
      "locator": ".agents/skills/backplane/managing-superpowers-backlog/references/../../../docs/superpowers-backplane/governance.md",
      "availability": "available",
      "limitations": [
        "Direct local source read establishes availability only; no canonical product-source or approval-semantic change."
      ],
      "id": "GOVERNANCE-SOURCE-FLOOR",
      "verified_commit": null,
      "sha256": "0702f984e007ab20095def7ed9967bfafeecdf5543ebf01ad5dfb59c40bae880"
    }
  ],
  "limitations": [
    "Local diagnostic only; no checkpoint acceptance, indexing, storage commit or publication authorized.",
    "checkpoint-input.json is an older unrelated invented example (issue101/S1/B); its bytes and historical claims are preserved, not applied to case105.",
    "The example repository identity is retained as example context; case105 namespace fixture/case#105 is a local capture identity, not an asserted live repository identity.",
    "Governance source floor corrected after direct read of .agents/skills/backplane/managing-superpowers-backlog/references/../../../docs/superpowers-backplane/governance.md, same content as .agents/skills/docs/superpowers-backplane/governance.md; SHA256 0702f984e007ab20095def7ed9967bfafeecdf5543ebf01ad5dfb59c40bae880. Earlier phase-1 absence claim was unsupported by junction-skipping enumeration; original observation retained under controls/phase-1-capture.json and controls/phase-1-capture-state.md. Other gaps and partial status unchanged.",
    "Offline supplied records establish no live GitHub recheck, current eligibility, authenticated gh, remote integration or publication.",
    "Case105 assignees and milestone are not supplied; null means unavailable, not observed empty.",
    "Current case architecture remains local although ADR-0001 edition1 approves remote. Capture-only scope does not authorize implementing the plan.",
    "Input line endings differ from recorded hashes: LF checkout bytes preserved; CRLF reconstruction exactly reproduces the reviewed proposal hash. No authority/input bytes changed."
  ]
}

~~~
