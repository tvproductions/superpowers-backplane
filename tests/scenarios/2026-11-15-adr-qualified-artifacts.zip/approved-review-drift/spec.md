FICTIONAL approved fixture design. Choose local source authority for architecture.json. Architectural approval is separate. Scope excludes publication.
