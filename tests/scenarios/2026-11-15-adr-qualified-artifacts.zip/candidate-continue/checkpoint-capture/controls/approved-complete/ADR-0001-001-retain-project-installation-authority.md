---
id: ADR-0001
title: Retain project installation authority
revision: 1
state: Current
decision_date: 2026-11-15
revision_date: 2026-11-15
approved_by: fictional fixture operator
approved_revision: 1
approval_ref: approval.txt
---

# Proposed ADR-0001 edition 1: retain project installation authority

The project owns its installation manifest and preserves unrelated existing valid entries. This constrains fixture requirement R1 and criterion AC1. Alternatives: project ownership or a remote service owning writes. Project ownership preserves the existing product contract. No remote operation, runtime, approval store or publication is introduced.

Administrative approval capture only; decision unchanged. Original reviewed proposal is ADR-0001-001-reviewed.txt at SHA256 4d6375c792aefeb7aa8c61f22460d5cbc6b2dedf6f8759ed355202b9a30085dc. Fictional input, not actual publisher approval.
