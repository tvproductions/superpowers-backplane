---
id: ADR-0001
title: Fixture source authority
revision: 1
state: Current
decision_date: 2026-11-15
revision_date: 2026-11-15
approved_by: fictional fixture operator
approved_revision: 1
approval_ref: approval.txt
---

# ADR-0001 edition 1: fixture source authority

Approved choice: remote owns source_of_truth. Scope: this case's architecture.json only.
Alternatives: local project authority or a remote canonical authority. Rationale: the fixture's selected product contract uses remote. Confirmation: inspect architecture.json and its reviewed approval. No publication or unrelated operation authority.

Administrative approval capture only; original reviewed bytes are retained at ADR-0001-001-reviewed.txt, SHA256 033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c. No choice changed.
