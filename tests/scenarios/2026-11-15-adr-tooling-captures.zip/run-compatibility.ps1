param([Parameter(Mandatory)][string[]]$Cases)
$work=Join-Path $PWD '.sp-bp/work/adr-integration'
$fixture=Join-Path $work 'compatibility-fixture'
foreach($case in $Cases){
 $prefix=Join-Path $work "compat-$case"
 Get-Content -Raw "$prefix-prompt.txt" | codex exec --ignore-user-config -c 'windows.sandbox="unelevated"' --sandbox read-only --json --ephemeral --cd $fixture --output-last-message "$prefix-answer.txt" - 1> "$prefix-events.jsonl" 2> "$prefix-stderr.txt"
 Write-Output "$case CLI exit $LASTEXITCODE; score every rubric expectation before acceptance"
}
