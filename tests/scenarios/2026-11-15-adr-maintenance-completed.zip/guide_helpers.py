"""Unmodified guide functions extracted into an owned behavior fixture."""

import json

import os

import re

import shutil

import subprocess

import tempfile

from pathlib import Path

def native(*arguments):
    """Run a native command with child-scoped configuration and explicit failure reporting."""
    executable = shutil.which(arguments[0])
    if executable is None:
        raise RuntimeError(f"Required command unavailable: {arguments[0]}")
    environment = dict(os.environ)
    if arguments[0] == "claude":
        environment["CLAUDE_CONFIG_DIR"] = str(profile)
        print(f"CLAUDE_CONFIG_DIR={profile}")
        index = int(environment.get("GIT_CONFIG_COUNT", "0") or "0")
        environment.update(
            {
                "GIT_CONFIG_COUNT": str(index + 1),
                f"GIT_CONFIG_KEY_{index}": f"url.https://github.com/{repo}.insteadOf",
                f"GIT_CONFIG_VALUE_{index}": f"git@github.com:{repo}",
            }
        )
    result = subprocess.run(
        [executable, *arguments[1:]],
        env=environment,
        shell=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    if result.returncode:
        raise RuntimeError(
            f"Command failed; inspect state before repair: {result.stdout}{result.stderr}"
        )
    print(result.stdout, end="" if result.stdout.endswith("\n") else "\n")
    return result.stdout

def pin(revision):
    """Atomically pin a verified source after checking dedicated catalog ownership."""
    if re.fullmatch(r"[0-9a-f]{40}", revision) is None:
        raise ValueError("Use a full lowercase 40-character commit SHA")
    manifest = catalog / ".claude-plugin" / "marketplace.json"
    if catalog.exists():
        existing = json.loads(manifest.read_text(encoding="utf-8-sig"))
        entries = existing.get("plugins", [])
        if (
            existing.get("name") != "superpowers-backplane"
            or len(entries) != 1
            or entries[0].get("name") != "superpowers-backplane"
            or entries[0].get("source", {}).get("source") != "github"
            or entries[0].get("source", {}).get("repo") != repo
        ):
            raise ValueError("Occupied catalog is not the verified dedicated Backplane source")
    available = native("gh", "api", f"repos/{repo}/commits/{revision}", "--jq", ".sha").strip()
    if available != revision:
        raise ValueError("Source unavailable; retain prior catalog and installation")
    value = {
        "name": "superpowers-backplane",
        "description": "Pinned Backplane hosted-source catalog",
        "owner": {"name": "tvproductions"},
        "plugins": [
            {
                "name": "superpowers-backplane",
                "description": "Pinned Backplane package",
                "source": {"source": "github", "repo": repo, "sha": revision},
            }
        ],
    }
    manifest.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        newline="\n",
        dir=manifest.parent,
        delete=False,
    ) as handle:
        temporary = Path(handle.name)
        handle.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    try:
        temporary.replace(manifest)
    finally:
        temporary.unlink(missing_ok=True)
