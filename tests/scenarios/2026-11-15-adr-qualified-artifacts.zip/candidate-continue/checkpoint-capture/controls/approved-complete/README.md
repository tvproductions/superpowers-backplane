Invented installation fixture, baseline.
Local preservation verification fixture delivered.
