# ADR-0001 edition 1: fixture source authority

Draft: remote owns source_of_truth. Scope: this case's architecture.json only.
Alternatives: local project authority or a remote canonical authority. Rationale: the fixture's selected product contract uses remote. Confirmation: inspect architecture.json and its reviewed approval. No publication or unrelated operation authority.
