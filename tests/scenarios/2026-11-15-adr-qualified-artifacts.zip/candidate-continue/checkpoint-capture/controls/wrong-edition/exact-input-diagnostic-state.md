# Exact-input approval diagnostic

Format: sp-bp-checkpoint/v1
Capture ID: invented-adr-capture-20261115-wrong-edition-exact-input-diagnostic
JSON SHA-256: 980abeba575657679b36bf361c07bf9dabbe1c01d264317589652f6d2965118a
Mode/status/origin: issues-only / partial / invented-fixture

Actual EADR-APPROVAL response names Approve ADR-0002 edition 2 as written, while reviewed proposal is ADR-0002 edition1. Metadata claims edition1 but cannot change actual response. Matching reviewed hash in the response does not repair its wrong named edition.

All declared content hashes match. Current satisfaction UNKNOWN/unreconciled; original pair preserved. Source f242185f2332885382a421b57d516e0db1900205; prior verified delivery b3b0c71f897bd265185baf2cfcc22269fc44d8f1. No accepted replacement/storage identity. Full lossless rendering retains graph, wording, coverage, authorities, evidence, unknowns, limitations and original input bytes.

~~~json
{
  "format": "sp-bp-checkpoint/v1",
  "capture": {
    "id": "invented-adr-capture-20261115-wrong-edition-exact-input-diagnostic",
    "started_at": "2026-11-15T22:00:00Z",
    "finished_at": "2026-11-15T22:18:23.593214Z",
    "mode": "issues-only",
    "status": "partial",
    "origin": "invented-fixture",
    "rechecks": [
      {
        "kind": "issue",
        "id": "example/governance-fixture#101",
        "initial_revision": "2026-10-01T12:00:00Z",
        "final_revision": "2026-10-01T12:00:00Z",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Fixture full body/native relationships unchanged."
      },
      {
        "kind": "graph",
        "id": "selected-native-graph",
        "initial_revision": "fixture-graph-1",
        "final_revision": "fixture-graph-1",
        "result": "unchanged",
        "approval_ids": [],
        "details": "All selected connections enumerated and compared."
      },
      {
        "kind": "authority",
        "id": "S1",
        "initial_revision": "f242185f2332885382a421b57d516e0db1900205",
        "final_revision": "f242185f2332885382a421b57d516e0db1900205",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Embedded fixture authority unchanged."
      },
      {
        "kind": "authority",
        "id": "A1",
        "initial_revision": "2026-10-01T12:00:00Z",
        "final_revision": "2026-10-01T12:00:00Z",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Embedded fixture authority unchanged."
      },
      {
        "kind": "authority",
        "id": "A2",
        "initial_revision": "2026-10-01T12:00:00Z",
        "final_revision": "2026-10-01T12:00:00Z",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Embedded fixture authority unchanged."
      },
      {
        "kind": "evidence",
        "id": "E1",
        "initial_revision": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
        "final_revision": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Embedded fixture evidence unchanged."
      },
      {
        "kind": "evidence",
        "id": "RV1",
        "initial_revision": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
        "final_revision": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Embedded fixture evidence unchanged."
      },
      {
        "kind": "delivery",
        "id": "example/governance-fixture#101",
        "initial_revision": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
        "final_revision": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Fixture current delivery B; source A identifies the capture context rather than the verified delivery."
      },
      {
        "kind": "evidence",
        "id": "EADR-REVIEWED",
        "initial_revision": "f242185f2332885382a421b57d516e0db1900205",
        "final_revision": "f242185f2332885382a421b57d516e0db1900205",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Invented available source bytes rechecked exactly; no real approval claim."
      },
      {
        "kind": "evidence",
        "id": "EADR-CURRENT",
        "initial_revision": "f242185f2332885382a421b57d516e0db1900205",
        "final_revision": "f242185f2332885382a421b57d516e0db1900205",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Invented available source bytes rechecked exactly; no real approval claim."
      },
      {
        "kind": "evidence",
        "id": "EADR-APPROVAL",
        "initial_revision": "f242185f2332885382a421b57d516e0db1900205",
        "final_revision": "f242185f2332885382a421b57d516e0db1900205",
        "result": "changed",
        "approval_ids": [],
        "details": "Actual EADR-APPROVAL response names Approve ADR-0002 edition 2 as written, while reviewed proposal is ADR-0002 edition1. Metadata claims edition1 but cannot change actual response. Matching reviewed hash in the response does not repair its wrong named edition. Original recheck is retained in exact raw input Evidence."
      },
      {
        "kind": "authority",
        "id": "AADR",
        "initial_revision": "f242185f2332885382a421b57d516e0db1900205",
        "final_revision": "f242185f2332885382a421b57d516e0db1900205",
        "result": "changed",
        "approval_ids": [],
        "details": "Actual EADR-APPROVAL response names Approve ADR-0002 edition 2 as written, while reviewed proposal is ADR-0002 edition1. Metadata claims edition1 but cannot change actual response. Matching reviewed hash in the response does not repair its wrong named edition. Original recheck is retained in exact raw input Evidence."
      }
    ]
  },
  "repository": {
    "id": "example/governance-fixture",
    "url": "https://github.com/example/governance-fixture",
    "owner": "example",
    "name": "governance-fixture"
  },
  "project": null,
  "source": {
    "commit": "f242185f2332885382a421b57d516e0db1900205"
  },
  "scope": {
    "issue_ids": [
      "example/governance-fixture#101"
    ],
    "excluded_ids": [],
    "external_records": [],
    "collections": [
      {
        "name": "issues",
        "owner_id": "example/governance-fixture",
        "expected_total": 1,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [
              "example/governance-fixture#101"
            ],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "subIssues",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "blockedBy",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "blocking",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "closingPRReferences",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "labels",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 1,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": "fixture-L1",
            "record_ids": [
              "L1"
            ],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "assignees",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 1,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [
              "fixture-owner"
            ],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "pullRequests",
        "owner_id": "example/governance-fixture",
        "expected_total": 1,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [
              "example/governance-fixture!201"
            ],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "closingIssuesReferences",
        "owner_id": "example/governance-fixture!201",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "has_next_page": false,
            "record_ids": []
          }
        ],
        "complete": true
      }
    ],
    "complete": true
  },
  "issues": [
    {
      "id": "example/governance-fixture#101",
      "number": 101,
      "url": "https://github.com/example/governance-fixture/issues/101",
      "title": "Preserve an existing valid installation",
      "body": "## Objective\nPreserve an existing valid installation.\n## Acceptance Criteria\nAC1: Preserve the existing valid installation.\n## Backplane Record\nCode: CAP1.1; Kind: outcome; authority S1.\n## Coverage and Satisfaction\nAC1 maps to R1/S1; accepted evaluation EV1 at delivery B is SATISFIED.\n",
      "state": "OPEN",
      "state_reason": "",
      "issue_type": {
        "id": "TYPE_FEATURE",
        "name": "Feature",
        "description": "Fixture native issue type",
        "color": "GREEN"
      },
      "labels": [
        {
          "id": "L1",
          "name": "backplane:review",
          "description": "Awaiting closeout",
          "color": "5319e7"
        }
      ],
      "assignees": [
        "fixture-owner"
      ],
      "milestone": null,
      "updated_at": "2026-10-01T12:00:00Z",
      "parent_id": null,
      "child_ids": [],
      "sub_issues_summary": {
        "total": 0,
        "completed": 0,
        "percent_completed": 0
      },
      "blocked_by_ids": [],
      "blocking_ids": [],
      "closing_pr_ids": [],
      "backplane_record": {
        "code": "CAP1.1",
        "namespace": "CAP1",
        "kind": "outcome",
        "authority_ids": [
          "S1"
        ]
      },
      "accepted_evaluation_ids": [
        "EV1"
      ],
      "limitations": []
    }
  ],
  "pull_requests": [
    {
      "id": "example/governance-fixture!201",
      "number": 201,
      "url": "https://github.com/example/governance-fixture/pull/201",
      "title": "Preservation contribution",
      "body": "Refs #101; contributes AC1 at S1.",
      "state": "MERGED",
      "base_ref": "main",
      "head_ref": "fixture-preservation",
      "merged_at": "2026-10-01T11:00:00Z",
      "merge_commit": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
      "review_status": "accepted",
      "closing_issue_ids": [],
      "closure_intent": "contribution",
      "updated_at": "2026-10-01T12:00:00Z",
      "limitations": []
    }
  ],
  "authorities": [
    {
      "id": "S1",
      "kind": "specification",
      "locator": "fixture:spec/S1",
      "revision": "f242185f2332885382a421b57d516e0db1900205",
      "content": "R1: Preserve an existing valid installation. AC1 implements R1. ADR-0002 edition 1 retains remote installation-manifest authority and preservation of unrelated valid entries under R1/AC1. Immutable source f242185f2332885382a421b57d516e0db1900205:ADR-0002-001-retain-project-installation-authority.md; reviewed bytes EADR-REVIEWED SHA256 4d6375c792aefeb7aa8c61f22460d5cbc6b2dedf6f8759ed355202b9a30085dc, administrative Current record EADR-CURRENT, actual staged response EADR-APPROVAL and approval authority AADR.",
      "availability": "available",
      "approver": null,
      "approved_scope": null,
      "approval_ids": [
        "A1",
        "AADR"
      ],
      "limitations": []
    },
    {
      "id": "A1",
      "kind": "approval",
      "locator": "fixture:approval/A1",
      "revision": "2026-10-01T12:00:00Z",
      "content": "Fixture approver approved R1 and AC1 at S1.",
      "availability": "available",
      "approver": "fixture-approver",
      "approved_scope": "R1/AC1 at S1",
      "approval_ids": [],
      "limitations": []
    },
    {
      "id": "A2",
      "kind": "approval",
      "locator": "fixture:review/A2",
      "revision": "2026-10-01T12:00:00Z",
      "content": "Fixture reviewer accepted AC1 at S1 and delivery B.",
      "availability": "available",
      "approver": "fixture-reviewer",
      "approved_scope": "AC1 at S1/B",
      "approval_ids": [],
      "limitations": []
    },
    {
      "id": "AADR",
      "kind": "approval",
      "locator": "fixture:approval/approval.txt",
      "revision": "f242185f2332885382a421b57d516e0db1900205",
      "content": "Metadata claims approval of ADR-0002 edition 1; inspect actual EADR-APPROVAL interaction, its named edition and exact reviewed hash. FICTIONAL response from fixture operator, 2026-11-15: Approve ADR-0002 edition 2 as written. The only available reviewed proposal is edition 1, SHA256 fba4e3a8a5f71c8bf5599bdd92c17ee1990fc831dd9ca89d9f85eb16fcc99363; no edition-1 response exists.",
      "availability": "available",
      "approver": "fictional fixture operator",
      "approved_scope": "ADR-0002 edition 1 assigns installation-manifest authority to a remote service; this replaces the prior project-owned choice.",
      "approval_ids": [],
      "limitations": []
    }
  ],
  "requirements": [
    {
      "id": "R1@S1",
      "key": "R1",
      "text": "Preserve an existing valid installation.",
      "authority_id": "S1",
      "authority_revision": "f242185f2332885382a421b57d516e0db1900205"
    }
  ],
  "criteria": [
    {
      "id": "example/governance-fixture#101:AC1",
      "issue_id": "example/governance-fixture#101",
      "key": "AC1",
      "text": "Preserve the existing valid installation.",
      "authority_id": "S1",
      "authority_revision": "f242185f2332885382a421b57d516e0db1900205",
      "delivery_commit": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
      "requirement_ids": [
        "R1@S1"
      ]
    }
  ],
  "dispositions": [],
  "coverage": [
    {
      "id": "COV1",
      "issue_id": "example/governance-fixture#101",
      "criterion_id": "example/governance-fixture#101:AC1",
      "requirement_ids": [
        "R1@S1"
      ],
      "contribution_issue_ids": [
        "example/governance-fixture#101"
      ],
      "pr_ids": [
        "example/governance-fixture!201"
      ],
      "combined_result_owner": "fixture-owner",
      "scope": "The sole fixture criterion is covered by preservation contribution PR201."
    }
  ],
  "evaluations": [
    {
      "id": "EV1",
      "criterion_id": "example/governance-fixture#101:AC1",
      "requirement_ids": [
        "R1@S1"
      ],
      "verified_commit": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
      "method": "Fixture preservation verification; ADR edition/content/approval and local manifest ownership alignment checked in invented fixture",
      "observed_result": "Original SATISFIED/PASS claim unsupported after exact interaction qualification; original candidate bytes preserved.",
      "result": "UNKNOWN",
      "observed_at": "2026-10-01T12:00:00Z",
      "evidence_ids": [
        "E1",
        "RV1",
        "EADR-REVIEWED",
        "EADR-CURRENT",
        "EADR-APPROVAL"
      ],
      "review_approval_ids": [
        "A2"
      ],
      "applicability": "unreconciled",
      "remaining_contributions": [
        "Supply actual approval of ADR-0002 edition1 and revalidate affected source/delivery before replacement."
      ],
      "limitations": [
        "Actual EADR-APPROVAL response names Approve ADR-0002 edition 2 as written, while reviewed proposal is ADR-0002 edition1. Metadata claims edition1 but cannot change actual response. Matching reviewed hash in the response does not repair its wrong named edition."
      ]
    }
  ],
  "evidence": [
    {
      "id": "E1",
      "kind": "verification",
      "locator": "fixture:verification/E1",
      "revision": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
      "sha256": null,
      "availability": "available",
      "content": "Invented fixture result: AC1 passed preservation verification against S1 and B.",
      "verified_commit": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
      "limitations": []
    },
    {
      "id": "RV1",
      "kind": "review",
      "locator": "fixture:review/RV1",
      "revision": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
      "sha256": null,
      "availability": "available",
      "content": "Invented fixture review accepted AC1 at S1/B.",
      "verified_commit": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
      "limitations": []
    },
    {
      "id": "EADR-REVIEWED",
      "kind": "other",
      "locator": "fixture:adr/ADR-0002-001-reviewed.txt",
      "revision": "f242185f2332885382a421b57d516e0db1900205",
      "sha256": "fba4e3a8a5f71c8bf5599bdd92c17ee1990fc831dd9ca89d9f85eb16fcc99363",
      "availability": "available",
      "content": "# Proposed ADR-0002 edition 1: retain project installation authority\n\nThe remote service owns its installation manifest and preserves unrelated existing valid entries. This constrains fixture requirement R1 and criterion AC1. Alternatives: project ownership or a remote service owning writes. Remote ownership changes the existing product contract. No remote operation, runtime, approval store or publication is introduced.\n",
      "verified_commit": null,
      "limitations": []
    },
    {
      "id": "EADR-CURRENT",
      "kind": "other",
      "locator": "fixture:adr/ADR-0002-001-retain-project-installation-authority.md",
      "revision": "f242185f2332885382a421b57d516e0db1900205",
      "sha256": "d56583a64452bda7444c717d91cf481fc7941df3c4d29c2cbb4a38231d2523b5",
      "availability": "available",
      "content": "---\nid: ADR-0002\ntitle: Retain project installation authority\nrevision: 1\nstate: Current\ndecision_date: 2026-11-15\nrevision_date: 2026-11-15\napproved_by: fictional fixture operator\napproved_revision: 1\napproval_ref: approval.txt\n---\n\n# Proposed ADR-0002 edition 1: retain project installation authority\n\nThe remote service owns its installation manifest and preserves unrelated existing valid entries. This constrains fixture requirement R1 and criterion AC1. Alternatives: project ownership or a remote service owning writes. Remote ownership changes the existing product contract. No remote operation, runtime, approval store or publication is introduced.\n\nAdministrative approval capture only; decision unchanged. Original reviewed proposal is ADR-0002-001-reviewed.txt at SHA256 fba4e3a8a5f71c8bf5599bdd92c17ee1990fc831dd9ca89d9f85eb16fcc99363. Fictional input, not actual publisher approval.\n",
      "verified_commit": null,
      "limitations": []
    },
    {
      "id": "EADR-APPROVAL",
      "kind": "approval",
      "locator": "fixture:adr/approval.txt",
      "revision": "f242185f2332885382a421b57d516e0db1900205",
      "sha256": "dd143a19a5ea0668564c6d125c4fcafb8f382f82d1df3dd5c9a37193ef7f3c1e",
      "availability": "available",
      "content": "FICTIONAL response from fixture operator, 2026-11-15: Approve ADR-0002 edition 2 as written. The only available reviewed proposal is edition 1, SHA256 fba4e3a8a5f71c8bf5599bdd92c17ee1990fc831dd9ca89d9f85eb16fcc99363; no edition-1 response exists.",
      "verified_commit": null,
      "limitations": []
    },
    {
      "sha256": "917e6fc1679ff3c4e9cf5dc5241db8ad700f732b1514734d167c0730316a88f2",
      "availability": "available",
      "verified_commit": null,
      "locator": "candidate-input.json",
      "id": "EXACT-INPUT-ORIGINAL",
      "content": "Exact original bytes base64: ewogICJmb3JtYXQiOiAic3AtYnAtY2hlY2twb2ludC92MSIsCiAgImNhcHR1cmUiOiB7CiAgICAiaWQiOiAiaW52ZW50ZWQtYWRyLWNhcHR1cmUtMjAyNjExMTUiLAogICAgInN0YXJ0ZWRfYXQiOiAiMjAyNi0xMS0xNVQyMjowMDowMFoiLAogICAgImZpbmlzaGVkX2F0IjogIjIwMjYtMTEtMTVUMjI6MTg6MjMuNTkzMjE0WiIsCiAgICAibW9kZSI6ICJpc3N1ZXMtb25seSIsCiAgICAic3RhdHVzIjogImNvbXBsZXRlIiwKICAgICJvcmlnaW4iOiAiaW52ZW50ZWQtZml4dHVyZSIsCiAgICAicmVjaGVja3MiOiBbCiAgICAgIHsKICAgICAgICAia2luZCI6ICJpc3N1ZSIsCiAgICAgICAgImlkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICAgImluaXRpYWxfcmV2aXNpb24iOiAiMjAyNi0xMC0wMVQxMjowMDowMFoiLAogICAgICAgICJmaW5hbF9yZXZpc2lvbiI6ICIyMDI2LTEwLTAxVDEyOjAwOjAwWiIsCiAgICAgICAgInJlc3VsdCI6ICJ1bmNoYW5nZWQiLAogICAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgICAiZGV0YWlscyI6ICJGaXh0dXJlIGZ1bGwgYm9keS9uYXRpdmUgcmVsYXRpb25zaGlwcyB1bmNoYW5nZWQuIgogICAgICB9LAogICAgICB7CiAgICAgICAgImtpbmQiOiAiZ3JhcGgiLAogICAgICAgICJpZCI6ICJzZWxlY3RlZC1uYXRpdmUtZ3JhcGgiLAogICAgICAgICJpbml0aWFsX3JldmlzaW9uIjogImZpeHR1cmUtZ3JhcGgtMSIsCiAgICAgICAgImZpbmFsX3JldmlzaW9uIjogImZpeHR1cmUtZ3JhcGgtMSIsCiAgICAgICAgInJlc3VsdCI6ICJ1bmNoYW5nZWQiLAogICAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgICAiZGV0YWlscyI6ICJBbGwgc2VsZWN0ZWQgY29ubmVjdGlvbnMgZW51bWVyYXRlZCBhbmQgY29tcGFyZWQuIgogICAgICB9LAogICAgICB7CiAgICAgICAgImtpbmQiOiAiYXV0aG9yaXR5IiwKICAgICAgICAiaWQiOiAiUzEiLAogICAgICAgICJpbml0aWFsX3JldmlzaW9uIjogImYyNDIxODVmMjMzMjg4NTM4MmE0MjFiNTdkNTE2ZTBkYjE5MDAyMDUiLAogICAgICAgICJmaW5hbF9yZXZpc2lvbiI6ICJmMjQyMTg1ZjIzMzI4ODUzODJhNDIxYjU3ZDUxNmUwZGIxOTAwMjA1IiwKICAgICAgICAicmVzdWx0IjogInVuY2hhbmdlZCIsCiAgICAgICAgImFwcHJvdmFsX2lkcyI6IFtdLAogICAgICAgICJkZXRhaWxzIjogIkVtYmVkZGVkIGZpeHR1cmUgYXV0aG9yaXR5IHVuY2hhbmdlZC4iCiAgICAgIH0sCiAgICAgIHsKICAgICAgICAia2luZCI6ICJhdXRob3JpdHkiLAogICAgICAgICJpZCI6ICJBMSIsCiAgICAgICAgImluaXRpYWxfcmV2aXNpb24iOiAiMjAyNi0xMC0wMVQxMjowMDowMFoiLAogICAgICAgICJmaW5hbF9yZXZpc2lvbiI6ICIyMDI2LTEwLTAxVDEyOjAwOjAwWiIsCiAgICAgICAgInJlc3VsdCI6ICJ1bmNoYW5nZWQiLAogICAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgICAiZGV0YWlscyI6ICJFbWJlZGRlZCBmaXh0dXJlIGF1dGhvcml0eSB1bmNoYW5nZWQuIgogICAgICB9LAogICAgICB7CiAgICAgICAgImtpbmQiOiAiYXV0aG9yaXR5IiwKICAgICAgICAiaWQiOiAiQTIiLAogICAgICAgICJpbml0aWFsX3JldmlzaW9uIjogIjIwMjYtMTAtMDFUMTI6MDA6MDBaIiwKICAgICAgICAiZmluYWxfcmV2aXNpb24iOiAiMjAyNi0xMC0wMVQxMjowMDowMFoiLAogICAgICAgICJyZXN1bHQiOiAidW5jaGFuZ2VkIiwKICAgICAgICAiYXBwcm92YWxfaWRzIjogW10sCiAgICAgICAgImRldGFpbHMiOiAiRW1iZWRkZWQgZml4dHVyZSBhdXRob3JpdHkgdW5jaGFuZ2VkLiIKICAgICAgfSwKICAgICAgewogICAgICAgICJraW5kIjogImV2aWRlbmNlIiwKICAgICAgICAiaWQiOiAiRTEiLAogICAgICAgICJpbml0aWFsX3JldmlzaW9uIjogImIzYjBjNzFmODk3YmQyNjUxODViYWYyY2ZjYzIyMjY5ZmM0NGQ4ZjEiLAogICAgICAgICJmaW5hbF9yZXZpc2lvbiI6ICJiM2IwYzcxZjg5N2JkMjY1MTg1YmFmMmNmY2MyMjI2OWZjNDRkOGYxIiwKICAgICAgICAicmVzdWx0IjogInVuY2hhbmdlZCIsCiAgICAgICAgImFwcHJvdmFsX2lkcyI6IFtdLAogICAgICAgICJkZXRhaWxzIjogIkVtYmVkZGVkIGZpeHR1cmUgZXZpZGVuY2UgdW5jaGFuZ2VkLiIKICAgICAgfSwKICAgICAgewogICAgICAgICJraW5kIjogImV2aWRlbmNlIiwKICAgICAgICAiaWQiOiAiUlYxIiwKICAgICAgICAiaW5pdGlhbF9yZXZpc2lvbiI6ICJiM2IwYzcxZjg5N2JkMjY1MTg1YmFmMmNmY2MyMjI2OWZjNDRkOGYxIiwKICAgICAgICAiZmluYWxfcmV2aXNpb24iOiAiYjNiMGM3MWY4OTdiZDI2NTE4NWJhZjJjZmNjMjIyNjlmYzQ0ZDhmMSIsCiAgICAgICAgInJlc3VsdCI6ICJ1bmNoYW5nZWQiLAogICAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgICAiZGV0YWlscyI6ICJFbWJlZGRlZCBmaXh0dXJlIGV2aWRlbmNlIHVuY2hhbmdlZC4iCiAgICAgIH0sCiAgICAgIHsKICAgICAgICAia2luZCI6ICJkZWxpdmVyeSIsCiAgICAgICAgImlkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICAgImluaXRpYWxfcmV2aXNpb24iOiAiYjNiMGM3MWY4OTdiZDI2NTE4NWJhZjJjZmNjMjIyNjlmYzQ0ZDhmMSIsCiAgICAgICAgImZpbmFsX3JldmlzaW9uIjogImIzYjBjNzFmODk3YmQyNjUxODViYWYyY2ZjYzIyMjY5ZmM0NGQ4ZjEiLAogICAgICAgICJyZXN1bHQiOiAidW5jaGFuZ2VkIiwKICAgICAgICAiYXBwcm92YWxfaWRzIjogW10sCiAgICAgICAgImRldGFpbHMiOiAiRml4dHVyZSBjdXJyZW50IGRlbGl2ZXJ5IEI7IHNvdXJjZSBBIGlkZW50aWZpZXMgdGhlIGNhcHR1cmUgY29udGV4dCByYXRoZXIgdGhhbiB0aGUgdmVyaWZpZWQgZGVsaXZlcnkuIgogICAgICB9LAogICAgICB7CiAgICAgICAgImtpbmQiOiAiZXZpZGVuY2UiLAogICAgICAgICJpZCI6ICJFQURSLVJFVklFV0VEIiwKICAgICAgICAiaW5pdGlhbF9yZXZpc2lvbiI6ICJmMjQyMTg1ZjIzMzI4ODUzODJhNDIxYjU3ZDUxNmUwZGIxOTAwMjA1IiwKICAgICAgICAiZmluYWxfcmV2aXNpb24iOiAiZjI0MjE4NWYyMzMyODg1MzgyYTQyMWI1N2Q1MTZlMGRiMTkwMDIwNSIsCiAgICAgICAgInJlc3VsdCI6ICJ1bmNoYW5nZWQiLAogICAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgICAiZGV0YWlscyI6ICJJbnZlbnRlZCBhdmFpbGFibGUgc291cmNlIGJ5dGVzIHJlY2hlY2tlZCBleGFjdGx5OyBubyByZWFsIGFwcHJvdmFsIGNsYWltLiIKICAgICAgfSwKICAgICAgewogICAgICAgICJraW5kIjogImV2aWRlbmNlIiwKICAgICAgICAiaWQiOiAiRUFEUi1DVVJSRU5UIiwKICAgICAgICAiaW5pdGlhbF9yZXZpc2lvbiI6ICJmMjQyMTg1ZjIzMzI4ODUzODJhNDIxYjU3ZDUxNmUwZGIxOTAwMjA1IiwKICAgICAgICAiZmluYWxfcmV2aXNpb24iOiAiZjI0MjE4NWYyMzMyODg1MzgyYTQyMWI1N2Q1MTZlMGRiMTkwMDIwNSIsCiAgICAgICAgInJlc3VsdCI6ICJ1bmNoYW5nZWQiLAogICAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgICAiZGV0YWlscyI6ICJJbnZlbnRlZCBhdmFpbGFibGUgc291cmNlIGJ5dGVzIHJlY2hlY2tlZCBleGFjdGx5OyBubyByZWFsIGFwcHJvdmFsIGNsYWltLiIKICAgICAgfSwKICAgICAgewogICAgICAgICJraW5kIjogImV2aWRlbmNlIiwKICAgICAgICAiaWQiOiAiRUFEUi1BUFBST1ZBTCIsCiAgICAgICAgImluaXRpYWxfcmV2aXNpb24iOiAiZjI0MjE4NWYyMzMyODg1MzgyYTQyMWI1N2Q1MTZlMGRiMTkwMDIwNSIsCiAgICAgICAgImZpbmFsX3JldmlzaW9uIjogImYyNDIxODVmMjMzMjg4NTM4MmE0MjFiNTdkNTE2ZTBkYjE5MDAyMDUiLAogICAgICAgICJyZXN1bHQiOiAidW5jaGFuZ2VkIiwKICAgICAgICAiYXBwcm92YWxfaWRzIjogW10sCiAgICAgICAgImRldGFpbHMiOiAiSW52ZW50ZWQgYXZhaWxhYmxlIHNvdXJjZSBieXRlcyByZWNoZWNrZWQgZXhhY3RseTsgbm8gcmVhbCBhcHByb3ZhbCBjbGFpbS4iCiAgICAgIH0sCiAgICAgIHsKICAgICAgICAia2luZCI6ICJhdXRob3JpdHkiLAogICAgICAgICJpZCI6ICJBQURSIiwKICAgICAgICAiaW5pdGlhbF9yZXZpc2lvbiI6ICJmMjQyMTg1ZjIzMzI4ODUzODJhNDIxYjU3ZDUxNmUwZGIxOTAwMjA1IiwKICAgICAgICAiZmluYWxfcmV2aXNpb24iOiAiZjI0MjE4NWYyMzMyODg1MzgyYTQyMWI1N2Q1MTZlMGRiMTkwMDIwNSIsCiAgICAgICAgInJlc3VsdCI6ICJ1bmNoYW5nZWQiLAogICAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgICAiZGV0YWlscyI6ICJFeGFjdCBpbnZlbnRlZCBlZGl0aW9uLTEgaW50ZXJhY3Rpb24vY29udGVudCByZWNoZWNrZWQ7IGRpc3RpbmN0IGZyb20gcmV2aWV3IGFwcHJvdmFsIEEyLiIKICAgICAgfQogICAgXQogIH0sCiAgInJlcG9zaXRvcnkiOiB7CiAgICAiaWQiOiAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUiLAogICAgInVybCI6ICJodHRwczovL2dpdGh1Yi5jb20vZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUiLAogICAgIm93bmVyIjogImV4YW1wbGUiLAogICAgIm5hbWUiOiAiZ292ZXJuYW5jZS1maXh0dXJlIgogIH0sCiAgInByb2plY3QiOiBudWxsLAogICJzb3VyY2UiOiB7CiAgICAiY29tbWl0IjogImYyNDIxODVmMjMzMjg4NTM4MmE0MjFiNTdkNTE2ZTBkYjE5MDAyMDUiCiAgfSwKICAic2NvcGUiOiB7CiAgICAiaXNzdWVfaWRzIjogWwogICAgICAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUjMTAxIgogICAgXSwKICAgICJleGNsdWRlZF9pZHMiOiBbXSwKICAgICJleHRlcm5hbF9yZWNvcmRzIjogW10sCiAgICAiY29sbGVjdGlvbnMiOiBbCiAgICAgIHsKICAgICAgICAibmFtZSI6ICJpc3N1ZXMiLAogICAgICAgICJvd25lcl9pZCI6ICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMSwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6IG51bGwsCiAgICAgICAgICAgICJyZWNvcmRfaWRzIjogWwogICAgICAgICAgICAgICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDEiCiAgICAgICAgICAgIF0sCiAgICAgICAgICAgICJoYXNfbmV4dF9wYWdlIjogZmFsc2UKICAgICAgICAgIH0KICAgICAgICBdLAogICAgICAgICJjb21wbGV0ZSI6IHRydWUKICAgICAgfSwKICAgICAgewogICAgICAgICJuYW1lIjogInN1Yklzc3VlcyIsCiAgICAgICAgIm93bmVyX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMCwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6IG51bGwsCiAgICAgICAgICAgICJyZWNvcmRfaWRzIjogW10sCiAgICAgICAgICAgICJoYXNfbmV4dF9wYWdlIjogZmFsc2UKICAgICAgICAgIH0KICAgICAgICBdLAogICAgICAgICJjb21wbGV0ZSI6IHRydWUKICAgICAgfSwKICAgICAgewogICAgICAgICJuYW1lIjogImJsb2NrZWRCeSIsCiAgICAgICAgIm93bmVyX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMCwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6IG51bGwsCiAgICAgICAgICAgICJyZWNvcmRfaWRzIjogW10sCiAgICAgICAgICAgICJoYXNfbmV4dF9wYWdlIjogZmFsc2UKICAgICAgICAgIH0KICAgICAgICBdLAogICAgICAgICJjb21wbGV0ZSI6IHRydWUKICAgICAgfSwKICAgICAgewogICAgICAgICJuYW1lIjogImJsb2NraW5nIiwKICAgICAgICAib3duZXJfaWQiOiAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUjMTAxIiwKICAgICAgICAiZXhwZWN0ZWRfdG90YWwiOiAwLAogICAgICAgICJwYWdlcyI6IFsKICAgICAgICAgIHsKICAgICAgICAgICAgImN1cnNvcl9pbiI6IG51bGwsCiAgICAgICAgICAgICJjdXJzb3Jfb3V0IjogbnVsbCwKICAgICAgICAgICAgInJlY29yZF9pZHMiOiBbXSwKICAgICAgICAgICAgImhhc19uZXh0X3BhZ2UiOiBmYWxzZQogICAgICAgICAgfQogICAgICAgIF0sCiAgICAgICAgImNvbXBsZXRlIjogdHJ1ZQogICAgICB9LAogICAgICB7CiAgICAgICAgIm5hbWUiOiAiY2xvc2luZ1BSUmVmZXJlbmNlcyIsCiAgICAgICAgIm93bmVyX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMCwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6IG51bGwsCiAgICAgICAgICAgICJyZWNvcmRfaWRzIjogW10sCiAgICAgICAgICAgICJoYXNfbmV4dF9wYWdlIjogZmFsc2UKICAgICAgICAgIH0KICAgICAgICBdLAogICAgICAgICJjb21wbGV0ZSI6IHRydWUKICAgICAgfSwKICAgICAgewogICAgICAgICJuYW1lIjogImxhYmVscyIsCiAgICAgICAgIm93bmVyX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMSwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6ICJmaXh0dXJlLUwxIiwKICAgICAgICAgICAgInJlY29yZF9pZHMiOiBbCiAgICAgICAgICAgICAgIkwxIgogICAgICAgICAgICBdLAogICAgICAgICAgICAiaGFzX25leHRfcGFnZSI6IGZhbHNlCiAgICAgICAgICB9CiAgICAgICAgXSwKICAgICAgICAiY29tcGxldGUiOiB0cnVlCiAgICAgIH0sCiAgICAgIHsKICAgICAgICAibmFtZSI6ICJhc3NpZ25lZXMiLAogICAgICAgICJvd25lcl9pZCI6ICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDEiLAogICAgICAgICJleHBlY3RlZF90b3RhbCI6IDEsCiAgICAgICAgInBhZ2VzIjogWwogICAgICAgICAgewogICAgICAgICAgICAiY3Vyc29yX2luIjogbnVsbCwKICAgICAgICAgICAgImN1cnNvcl9vdXQiOiBudWxsLAogICAgICAgICAgICAicmVjb3JkX2lkcyI6IFsKICAgICAgICAgICAgICAiZml4dHVyZS1vd25lciIKICAgICAgICAgICAgXSwKICAgICAgICAgICAgImhhc19uZXh0X3BhZ2UiOiBmYWxzZQogICAgICAgICAgfQogICAgICAgIF0sCiAgICAgICAgImNvbXBsZXRlIjogdHJ1ZQogICAgICB9LAogICAgICB7CiAgICAgICAgIm5hbWUiOiAicHVsbFJlcXVlc3RzIiwKICAgICAgICAib3duZXJfaWQiOiAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUiLAogICAgICAgICJleHBlY3RlZF90b3RhbCI6IDEsCiAgICAgICAgInBhZ2VzIjogWwogICAgICAgICAgewogICAgICAgICAgICAiY3Vyc29yX2luIjogbnVsbCwKICAgICAgICAgICAgImN1cnNvcl9vdXQiOiBudWxsLAogICAgICAgICAgICAicmVjb3JkX2lkcyI6IFsKICAgICAgICAgICAgICAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUhMjAxIgogICAgICAgICAgICBdLAogICAgICAgICAgICAiaGFzX25leHRfcGFnZSI6IGZhbHNlCiAgICAgICAgICB9CiAgICAgICAgXSwKICAgICAgICAiY29tcGxldGUiOiB0cnVlCiAgICAgIH0sCiAgICAgIHsKICAgICAgICAibmFtZSI6ICJjbG9zaW5nSXNzdWVzUmVmZXJlbmNlcyIsCiAgICAgICAgIm93bmVyX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlITIwMSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMCwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6IG51bGwsCiAgICAgICAgICAgICJoYXNfbmV4dF9wYWdlIjogZmFsc2UsCiAgICAgICAgICAgICJyZWNvcmRfaWRzIjogW10KICAgICAgICAgIH0KICAgICAgICBdLAogICAgICAgICJjb21wbGV0ZSI6IHRydWUKICAgICAgfQogICAgXSwKICAgICJjb21wbGV0ZSI6IHRydWUKICB9LAogICJpc3N1ZXMiOiBbCiAgICB7CiAgICAgICJpZCI6ICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDEiLAogICAgICAibnVtYmVyIjogMTAxLAogICAgICAidXJsIjogImh0dHBzOi8vZ2l0aHViLmNvbS9leGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZS9pc3N1ZXMvMTAxIiwKICAgICAgInRpdGxlIjogIlByZXNlcnZlIGFuIGV4aXN0aW5nIHZhbGlkIGluc3RhbGxhdGlvbiIsCiAgICAgICJib2R5IjogIiMjIE9iamVjdGl2ZVxuUHJlc2VydmUgYW4gZXhpc3RpbmcgdmFsaWQgaW5zdGFsbGF0aW9uLlxuIyMgQWNjZXB0YW5jZSBDcml0ZXJpYVxuQUMxOiBQcmVzZXJ2ZSB0aGUgZXhpc3RpbmcgdmFsaWQgaW5zdGFsbGF0aW9uLlxuIyMgQmFja3BsYW5lIFJlY29yZFxuQ29kZTogQ0FQMS4xOyBLaW5kOiBvdXRjb21lOyBhdXRob3JpdHkgUzEuXG4jIyBDb3ZlcmFnZSBhbmQgU2F0aXNmYWN0aW9uXG5BQzEgbWFwcyB0byBSMS9TMTsgYWNjZXB0ZWQgZXZhbHVhdGlvbiBFVjEgYXQgZGVsaXZlcnkgQiBpcyBTQVRJU0ZJRUQuXG4iLAogICAgICAic3RhdGUiOiAiT1BFTiIsCiAgICAgICJzdGF0ZV9yZWFzb24iOiAiIiwKICAgICAgImlzc3VlX3R5cGUiOiB7CiAgICAgICAgImlkIjogIlRZUEVfRkVBVFVSRSIsCiAgICAgICAgIm5hbWUiOiAiRmVhdHVyZSIsCiAgICAgICAgImRlc2NyaXB0aW9uIjogIkZpeHR1cmUgbmF0aXZlIGlzc3VlIHR5cGUiLAogICAgICAgICJjb2xvciI6ICJHUkVFTiIKICAgICAgfSwKICAgICAgImxhYmVscyI6IFsKICAgICAgICB7CiAgICAgICAgICAiaWQiOiAiTDEiLAogICAgICAgICAgIm5hbWUiOiAiYmFja3BsYW5lOnJldmlldyIsCiAgICAgICAgICAiZGVzY3JpcHRpb24iOiAiQXdhaXRpbmcgY2xvc2VvdXQiLAogICAgICAgICAgImNvbG9yIjogIjUzMTllNyIKICAgICAgICB9CiAgICAgIF0sCiAgICAgICJhc3NpZ25lZXMiOiBbCiAgICAgICAgImZpeHR1cmUtb3duZXIiCiAgICAgIF0sCiAgICAgICJtaWxlc3RvbmUiOiBudWxsLAogICAgICAidXBkYXRlZF9hdCI6ICIyMDI2LTEwLTAxVDEyOjAwOjAwWiIsCiAgICAgICJwYXJlbnRfaWQiOiBudWxsLAogICAgICAiY2hpbGRfaWRzIjogW10sCiAgICAgICJzdWJfaXNzdWVzX3N1bW1hcnkiOiB7CiAgICAgICAgInRvdGFsIjogMCwKICAgICAgICAiY29tcGxldGVkIjogMCwKICAgICAgICAicGVyY2VudF9jb21wbGV0ZWQiOiAwCiAgICAgIH0sCiAgICAgICJibG9ja2VkX2J5X2lkcyI6IFtdLAogICAgICAiYmxvY2tpbmdfaWRzIjogW10sCiAgICAgICJjbG9zaW5nX3ByX2lkcyI6IFtdLAogICAgICAiYmFja3BsYW5lX3JlY29yZCI6IHsKICAgICAgICAiY29kZSI6ICJDQVAxLjEiLAogICAgICAgICJuYW1lc3BhY2UiOiAiQ0FQMSIsCiAgICAgICAgImtpbmQiOiAib3V0Y29tZSIsCiAgICAgICAgImF1dGhvcml0eV9pZHMiOiBbCiAgICAgICAgICAiUzEiCiAgICAgICAgXQogICAgICB9LAogICAgICAiYWNjZXB0ZWRfZXZhbHVhdGlvbl9pZHMiOiBbCiAgICAgICAgIkVWMSIKICAgICAgXSwKICAgICAgImxpbWl0YXRpb25zIjogW10KICAgIH0KICBdLAogICJwdWxsX3JlcXVlc3RzIjogWwogICAgewogICAgICAiaWQiOiAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUhMjAxIiwKICAgICAgIm51bWJlciI6IDIwMSwKICAgICAgInVybCI6ICJodHRwczovL2dpdGh1Yi5jb20vZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUvcHVsbC8yMDEiLAogICAgICAidGl0bGUiOiAiUHJlc2VydmF0aW9uIGNvbnRyaWJ1dGlvbiIsCiAgICAgICJib2R5IjogIlJlZnMgIzEwMTsgY29udHJpYnV0ZXMgQUMxIGF0IFMxLiIsCiAgICAgICJzdGF0ZSI6ICJNRVJHRUQiLAogICAgICAiYmFzZV9yZWYiOiAibWFpbiIsCiAgICAgICJoZWFkX3JlZiI6ICJmaXh0dXJlLXByZXNlcnZhdGlvbiIsCiAgICAgICJtZXJnZWRfYXQiOiAiMjAyNi0xMC0wMVQxMTowMDowMFoiLAogICAgICAibWVyZ2VfY29tbWl0IjogImIzYjBjNzFmODk3YmQyNjUxODViYWYyY2ZjYzIyMjY5ZmM0NGQ4ZjEiLAogICAgICAicmV2aWV3X3N0YXR1cyI6ICJhY2NlcHRlZCIsCiAgICAgICJjbG9zaW5nX2lzc3VlX2lkcyI6IFtdLAogICAgICAiY2xvc3VyZV9pbnRlbnQiOiAiY29udHJpYnV0aW9uIiwKICAgICAgInVwZGF0ZWRfYXQiOiAiMjAyNi0xMC0wMVQxMjowMDowMFoiLAogICAgICAibGltaXRhdGlvbnMiOiBbXQogICAgfQogIF0sCiAgImF1dGhvcml0aWVzIjogWwogICAgewogICAgICAiaWQiOiAiUzEiLAogICAgICAia2luZCI6ICJzcGVjaWZpY2F0aW9uIiwKICAgICAgImxvY2F0b3IiOiAiZml4dHVyZTpzcGVjL1MxIiwKICAgICAgInJldmlzaW9uIjogImYyNDIxODVmMjMzMjg4NTM4MmE0MjFiNTdkNTE2ZTBkYjE5MDAyMDUiLAogICAgICAiY29udGVudCI6ICJSMTogUHJlc2VydmUgYW4gZXhpc3RpbmcgdmFsaWQgaW5zdGFsbGF0aW9uLiBBQzEgaW1wbGVtZW50cyBSMS4gQURSLTAwMDIgZWRpdGlvbiAxIHJldGFpbnMgcmVtb3RlIGluc3RhbGxhdGlvbi1tYW5pZmVzdCBhdXRob3JpdHkgYW5kIHByZXNlcnZhdGlvbiBvZiB1bnJlbGF0ZWQgdmFsaWQgZW50cmllcyB1bmRlciBSMS9BQzEuIEltbXV0YWJsZSBzb3VyY2UgZjI0MjE4NWYyMzMyODg1MzgyYTQyMWI1N2Q1MTZlMGRiMTkwMDIwNTpBRFItMDAwMi0wMDEtcmV0YWluLXByb2plY3QtaW5zdGFsbGF0aW9uLWF1dGhvcml0eS5tZDsgcmV2aWV3ZWQgYnl0ZXMgRUFEUi1SRVZJRVdFRCBTSEEyNTYgNGQ2Mzc1Yzc5MmFlZmViN2FhOGM2MWYyMjQ2MGQ1Y2JjNmIyZGVkZjZmODc1OWVkMzU1MjAyYjlhMzAwODVkYywgYWRtaW5pc3RyYXRpdmUgQ3VycmVudCByZWNvcmQgRUFEUi1DVVJSRU5ULCBhY3R1YWwgc3RhZ2VkIHJlc3BvbnNlIEVBRFItQVBQUk9WQUwgYW5kIGFwcHJvdmFsIGF1dGhvcml0eSBBQURSLiIsCiAgICAgICJhdmFpbGFiaWxpdHkiOiAiYXZhaWxhYmxlIiwKICAgICAgImFwcHJvdmVyIjogbnVsbCwKICAgICAgImFwcHJvdmVkX3Njb3BlIjogbnVsbCwKICAgICAgImFwcHJvdmFsX2lkcyI6IFsKICAgICAgICAiQTEiLAogICAgICAgICJBQURSIgogICAgICBdLAogICAgICAibGltaXRhdGlvbnMiOiBbXQogICAgfSwKICAgIHsKICAgICAgImlkIjogIkExIiwKICAgICAgImtpbmQiOiAiYXBwcm92YWwiLAogICAgICAibG9jYXRvciI6ICJmaXh0dXJlOmFwcHJvdmFsL0ExIiwKICAgICAgInJldmlzaW9uIjogIjIwMjYtMTAtMDFUMTI6MDA6MDBaIiwKICAgICAgImNvbnRlbnQiOiAiRml4dHVyZSBhcHByb3ZlciBhcHByb3ZlZCBSMSBhbmQgQUMxIGF0IFMxLiIsCiAgICAgICJhdmFpbGFiaWxpdHkiOiAiYXZhaWxhYmxlIiwKICAgICAgImFwcHJvdmVyIjogImZpeHR1cmUtYXBwcm92ZXIiLAogICAgICAiYXBwcm92ZWRfc2NvcGUiOiAiUjEvQUMxIGF0IFMxIiwKICAgICAgImFwcHJvdmFsX2lkcyI6IFtdLAogICAgICAibGltaXRhdGlvbnMiOiBbXQogICAgfSwKICAgIHsKICAgICAgImlkIjogIkEyIiwKICAgICAgImtpbmQiOiAiYXBwcm92YWwiLAogICAgICAibG9jYXRvciI6ICJmaXh0dXJlOnJldmlldy9BMiIsCiAgICAgICJyZXZpc2lvbiI6ICIyMDI2LTEwLTAxVDEyOjAwOjAwWiIsCiAgICAgICJjb250ZW50IjogIkZpeHR1cmUgcmV2aWV3ZXIgYWNjZXB0ZWQgQUMxIGF0IFMxIGFuZCBkZWxpdmVyeSBCLiIsCiAgICAgICJhdmFpbGFiaWxpdHkiOiAiYXZhaWxhYmxlIiwKICAgICAgImFwcHJvdmVyIjogImZpeHR1cmUtcmV2aWV3ZXIiLAogICAgICAiYXBwcm92ZWRfc2NvcGUiOiAiQUMxIGF0IFMxL0IiLAogICAgICAiYXBwcm92YWxfaWRzIjogW10sCiAgICAgICJsaW1pdGF0aW9ucyI6IFtdCiAgICB9LAogICAgewogICAgICAiaWQiOiAiQUFEUiIsCiAgICAgICJraW5kIjogImFwcHJvdmFsIiwKICAgICAgImxvY2F0b3IiOiAiZml4dHVyZTphcHByb3ZhbC9hcHByb3ZhbC50eHQiLAogICAgICAicmV2aXNpb24iOiAiZjI0MjE4NWYyMzMyODg1MzgyYTQyMWI1N2Q1MTZlMGRiMTkwMDIwNSIsCiAgICAgICJjb250ZW50IjogIk1ldGFkYXRhIGNsYWltcyBhcHByb3ZhbCBvZiBBRFItMDAwMiBlZGl0aW9uIDE7IGluc3BlY3QgYWN0dWFsIEVBRFItQVBQUk9WQUwgaW50ZXJhY3Rpb24sIGl0cyBuYW1lZCBlZGl0aW9uIGFuZCBleGFjdCByZXZpZXdlZCBoYXNoLiBGSUNUSU9OQUwgcmVzcG9uc2UgZnJvbSBmaXh0dXJlIG9wZXJhdG9yLCAyMDI2LTExLTE1OiBBcHByb3ZlIEFEUi0wMDAyIGVkaXRpb24gMiBhcyB3cml0dGVuLiBUaGUgb25seSBhdmFpbGFibGUgcmV2aWV3ZWQgcHJvcG9zYWwgaXMgZWRpdGlvbiAxLCBTSEEyNTYgZmJhNGUzYThhNWY3MWM4YmY1NTk5YmRkOTJjMTdlZTE5OTBmYzgzMWRkOWNhODlkOWY4NWViMTZmY2M5OTM2Mzsgbm8gZWRpdGlvbi0xIHJlc3BvbnNlIGV4aXN0cy4iLAogICAgICAiYXZhaWxhYmlsaXR5IjogImF2YWlsYWJsZSIsCiAgICAgICJhcHByb3ZlciI6ICJmaWN0aW9uYWwgZml4dHVyZSBvcGVyYXRvciIsCiAgICAgICJhcHByb3ZlZF9zY29wZSI6ICJBRFItMDAwMiBlZGl0aW9uIDEgYXNzaWducyBpbnN0YWxsYXRpb24tbWFuaWZlc3QgYXV0aG9yaXR5IHRvIGEgcmVtb3RlIHNlcnZpY2U7IHRoaXMgcmVwbGFjZXMgdGhlIHByaW9yIHByb2plY3Qtb3duZWQgY2hvaWNlLiIsCiAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgImxpbWl0YXRpb25zIjogW10KICAgIH0KICBdLAogICJyZXF1aXJlbWVudHMiOiBbCiAgICB7CiAgICAgICJpZCI6ICJSMUBTMSIsCiAgICAgICJrZXkiOiAiUjEiLAogICAgICAidGV4dCI6ICJQcmVzZXJ2ZSBhbiBleGlzdGluZyB2YWxpZCBpbnN0YWxsYXRpb24uIiwKICAgICAgImF1dGhvcml0eV9pZCI6ICJTMSIsCiAgICAgICJhdXRob3JpdHlfcmV2aXNpb24iOiAiZjI0MjE4NWYyMzMyODg1MzgyYTQyMWI1N2Q1MTZlMGRiMTkwMDIwNSIKICAgIH0KICBdLAogICJjcml0ZXJpYSI6IFsKICAgIHsKICAgICAgImlkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMTpBQzEiLAogICAgICAiaXNzdWVfaWQiOiAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUjMTAxIiwKICAgICAgImtleSI6ICJBQzEiLAogICAgICAidGV4dCI6ICJQcmVzZXJ2ZSB0aGUgZXhpc3RpbmcgdmFsaWQgaW5zdGFsbGF0aW9uLiIsCiAgICAgICJhdXRob3JpdHlfaWQiOiAiUzEiLAogICAgICAiYXV0aG9yaXR5X3JldmlzaW9uIjogImYyNDIxODVmMjMzMjg4NTM4MmE0MjFiNTdkNTE2ZTBkYjE5MDAyMDUiLAogICAgICAiZGVsaXZlcnlfY29tbWl0IjogImIzYjBjNzFmODk3YmQyNjUxODViYWYyY2ZjYzIyMjY5ZmM0NGQ4ZjEiLAogICAgICAicmVxdWlyZW1lbnRfaWRzIjogWwogICAgICAgICJSMUBTMSIKICAgICAgXQogICAgfQogIF0sCiAgImRpc3Bvc2l0aW9ucyI6IFtdLAogICJjb3ZlcmFnZSI6IFsKICAgIHsKICAgICAgImlkIjogIkNPVjEiLAogICAgICAiaXNzdWVfaWQiOiAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUjMTAxIiwKICAgICAgImNyaXRlcmlvbl9pZCI6ICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDE6QUMxIiwKICAgICAgInJlcXVpcmVtZW50X2lkcyI6IFsKICAgICAgICAiUjFAUzEiCiAgICAgIF0sCiAgICAgICJjb250cmlidXRpb25faXNzdWVfaWRzIjogWwogICAgICAgICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDEiCiAgICAgIF0sCiAgICAgICJwcl9pZHMiOiBbCiAgICAgICAgImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlITIwMSIKICAgICAgXSwKICAgICAgImNvbWJpbmVkX3Jlc3VsdF9vd25lciI6ICJmaXh0dXJlLW93bmVyIiwKICAgICAgInNjb3BlIjogIlRoZSBzb2xlIGZpeHR1cmUgY3JpdGVyaW9uIGlzIGNvdmVyZWQgYnkgcHJlc2VydmF0aW9uIGNvbnRyaWJ1dGlvbiBQUjIwMS4iCiAgICB9CiAgXSwKICAiZXZhbHVhdGlvbnMiOiBbCiAgICB7CiAgICAgICJpZCI6ICJFVjEiLAogICAgICAiY3JpdGVyaW9uX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMTpBQzEiLAogICAgICAicmVxdWlyZW1lbnRfaWRzIjogWwogICAgICAgICJSMUBTMSIKICAgICAgXSwKICAgICAgInZlcmlmaWVkX2NvbW1pdCI6ICJiM2IwYzcxZjg5N2JkMjY1MTg1YmFmMmNmY2MyMjI2OWZjNDRkOGYxIiwKICAgICAgIm1ldGhvZCI6ICJGaXh0dXJlIHByZXNlcnZhdGlvbiB2ZXJpZmljYXRpb247IEFEUiBlZGl0aW9uL2NvbnRlbnQvYXBwcm92YWwgYW5kIGxvY2FsIG1hbmlmZXN0IG93bmVyc2hpcCBhbGlnbm1lbnQgY2hlY2tlZCBpbiBpbnZlbnRlZCBmaXh0dXJlIiwKICAgICAgIm9ic2VydmVkX3Jlc3VsdCI6ICJQQVNTIHN1cHBsaWVkIGJ5IHRoZSBpbnZlbnRlZCBmaXh0dXJlLiIsCiAgICAgICJyZXN1bHQiOiAiU0FUSVNGSUVEIiwKICAgICAgIm9ic2VydmVkX2F0IjogIjIwMjYtMTAtMDFUMTI6MDA6MDBaIiwKICAgICAgImV2aWRlbmNlX2lkcyI6IFsKICAgICAgICAiRTEiLAogICAgICAgICJSVjEiLAogICAgICAgICJFQURSLVJFVklFV0VEIiwKICAgICAgICAiRUFEUi1DVVJSRU5UIiwKICAgICAgICAiRUFEUi1BUFBST1ZBTCIKICAgICAgXSwKICAgICAgInJldmlld19hcHByb3ZhbF9pZHMiOiBbCiAgICAgICAgIkEyIgogICAgICBdLAogICAgICAiYXBwbGljYWJpbGl0eSI6ICJjdXJyZW50IiwKICAgICAgInJlbWFpbmluZ19jb250cmlidXRpb25zIjogW10sCiAgICAgICJsaW1pdGF0aW9ucyI6IFtdCiAgICB9CiAgXSwKICAiZXZpZGVuY2UiOiBbCiAgICB7CiAgICAgICJpZCI6ICJFMSIsCiAgICAgICJraW5kIjogInZlcmlmaWNhdGlvbiIsCiAgICAgICJsb2NhdG9yIjogImZpeHR1cmU6dmVyaWZpY2F0aW9uL0UxIiwKICAgICAgInJldmlzaW9uIjogImIzYjBjNzFmODk3YmQyNjUxODViYWYyY2ZjYzIyMjY5ZmM0NGQ4ZjEiLAogICAgICAic2hhMjU2IjogbnVsbCwKICAgICAgImF2YWlsYWJpbGl0eSI6ICJhdmFpbGFibGUiLAogICAgICAiY29udGVudCI6ICJJbnZlbnRlZCBmaXh0dXJlIHJlc3VsdDogQUMxIHBhc3NlZCBwcmVzZXJ2YXRpb24gdmVyaWZpY2F0aW9uIGFnYWluc3QgUzEgYW5kIEIuIiwKICAgICAgInZlcmlmaWVkX2NvbW1pdCI6ICJiM2IwYzcxZjg5N2JkMjY1MTg1YmFmMmNmY2MyMjI2OWZjNDRkOGYxIiwKICAgICAgImxpbWl0YXRpb25zIjogW10KICAgIH0sCiAgICB7CiAgICAgICJpZCI6ICJSVjEiLAogICAgICAia2luZCI6ICJyZXZpZXciLAogICAgICAibG9jYXRvciI6ICJmaXh0dXJlOnJldmlldy9SVjEiLAogICAgICAicmV2aXNpb24iOiAiYjNiMGM3MWY4OTdiZDI2NTE4NWJhZjJjZmNjMjIyNjlmYzQ0ZDhmMSIsCiAgICAgICJzaGEyNTYiOiBudWxsLAogICAgICAiYXZhaWxhYmlsaXR5IjogImF2YWlsYWJsZSIsCiAgICAgICJjb250ZW50IjogIkludmVudGVkIGZpeHR1cmUgcmV2aWV3IGFjY2VwdGVkIEFDMSBhdCBTMS9CLiIsCiAgICAgICJ2ZXJpZmllZF9jb21taXQiOiAiYjNiMGM3MWY4OTdiZDI2NTE4NWJhZjJjZmNjMjIyNjlmYzQ0ZDhmMSIsCiAgICAgICJsaW1pdGF0aW9ucyI6IFtdCiAgICB9LAogICAgewogICAgICAiaWQiOiAiRUFEUi1SRVZJRVdFRCIsCiAgICAgICJraW5kIjogIm90aGVyIiwKICAgICAgImxvY2F0b3IiOiAiZml4dHVyZTphZHIvQURSLTAwMDItMDAxLXJldmlld2VkLnR4dCIsCiAgICAgICJyZXZpc2lvbiI6ICJmMjQyMTg1ZjIzMzI4ODUzODJhNDIxYjU3ZDUxNmUwZGIxOTAwMjA1IiwKICAgICAgInNoYTI1NiI6ICJmYmE0ZTNhOGE1ZjcxYzhiZjU1OTliZGQ5MmMxN2VlMTk5MGZjODMxZGQ5Y2E4OWQ5Zjg1ZWIxNmZjYzk5MzYzIiwKICAgICAgImF2YWlsYWJpbGl0eSI6ICJhdmFpbGFibGUiLAogICAgICAiY29udGVudCI6ICIjIFByb3Bvc2VkIEFEUi0wMDAyIGVkaXRpb24gMTogcmV0YWluIHByb2plY3QgaW5zdGFsbGF0aW9uIGF1dGhvcml0eVxuXG5UaGUgcmVtb3RlIHNlcnZpY2Ugb3ducyBpdHMgaW5zdGFsbGF0aW9uIG1hbmlmZXN0IGFuZCBwcmVzZXJ2ZXMgdW5yZWxhdGVkIGV4aXN0aW5nIHZhbGlkIGVudHJpZXMuIFRoaXMgY29uc3RyYWlucyBmaXh0dXJlIHJlcXVpcmVtZW50IFIxIGFuZCBjcml0ZXJpb24gQUMxLiBBbHRlcm5hdGl2ZXM6IHByb2plY3Qgb3duZXJzaGlwIG9yIGEgcmVtb3RlIHNlcnZpY2Ugb3duaW5nIHdyaXRlcy4gUmVtb3RlIG93bmVyc2hpcCBjaGFuZ2VzIHRoZSBleGlzdGluZyBwcm9kdWN0IGNvbnRyYWN0LiBObyByZW1vdGUgb3BlcmF0aW9uLCBydW50aW1lLCBhcHByb3ZhbCBzdG9yZSBvciBwdWJsaWNhdGlvbiBpcyBpbnRyb2R1Y2VkLlxuIiwKICAgICAgInZlcmlmaWVkX2NvbW1pdCI6IG51bGwsCiAgICAgICJsaW1pdGF0aW9ucyI6IFtdCiAgICB9LAogICAgewogICAgICAiaWQiOiAiRUFEUi1DVVJSRU5UIiwKICAgICAgImtpbmQiOiAib3RoZXIiLAogICAgICAibG9jYXRvciI6ICJmaXh0dXJlOmFkci9BRFItMDAwMi0wMDEtcmV0YWluLXByb2plY3QtaW5zdGFsbGF0aW9uLWF1dGhvcml0eS5tZCIsCiAgICAgICJyZXZpc2lvbiI6ICJmMjQyMTg1ZjIzMzI4ODUzODJhNDIxYjU3ZDUxNmUwZGIxOTAwMjA1IiwKICAgICAgInNoYTI1NiI6ICJkNTY1ODNhNjQ0NTJiZGE3NDQ0YzcxN2Q5MWNmNDgxZmM3OTQxZGYzYzRkMjljMmNiYjRhMzgyMzFkMjUyM2I1IiwKICAgICAgImF2YWlsYWJpbGl0eSI6ICJhdmFpbGFibGUiLAogICAgICAiY29udGVudCI6ICItLS1cbmlkOiBBRFItMDAwMlxudGl0bGU6IFJldGFpbiBwcm9qZWN0IGluc3RhbGxhdGlvbiBhdXRob3JpdHlcbnJldmlzaW9uOiAxXG5zdGF0ZTogQ3VycmVudFxuZGVjaXNpb25fZGF0ZTogMjAyNi0xMS0xNVxucmV2aXNpb25fZGF0ZTogMjAyNi0xMS0xNVxuYXBwcm92ZWRfYnk6IGZpY3Rpb25hbCBmaXh0dXJlIG9wZXJhdG9yXG5hcHByb3ZlZF9yZXZpc2lvbjogMVxuYXBwcm92YWxfcmVmOiBhcHByb3ZhbC50eHRcbi0tLVxuXG4jIFByb3Bvc2VkIEFEUi0wMDAyIGVkaXRpb24gMTogcmV0YWluIHByb2plY3QgaW5zdGFsbGF0aW9uIGF1dGhvcml0eVxuXG5UaGUgcmVtb3RlIHNlcnZpY2Ugb3ducyBpdHMgaW5zdGFsbGF0aW9uIG1hbmlmZXN0IGFuZCBwcmVzZXJ2ZXMgdW5yZWxhdGVkIGV4aXN0aW5nIHZhbGlkIGVudHJpZXMuIFRoaXMgY29uc3RyYWlucyBmaXh0dXJlIHJlcXVpcmVtZW50IFIxIGFuZCBjcml0ZXJpb24gQUMxLiBBbHRlcm5hdGl2ZXM6IHByb2plY3Qgb3duZXJzaGlwIG9yIGEgcmVtb3RlIHNlcnZpY2Ugb3duaW5nIHdyaXRlcy4gUmVtb3RlIG93bmVyc2hpcCBjaGFuZ2VzIHRoZSBleGlzdGluZyBwcm9kdWN0IGNvbnRyYWN0LiBObyByZW1vdGUgb3BlcmF0aW9uLCBydW50aW1lLCBhcHByb3ZhbCBzdG9yZSBvciBwdWJsaWNhdGlvbiBpcyBpbnRyb2R1Y2VkLlxuXG5BZG1pbmlzdHJhdGl2ZSBhcHByb3ZhbCBjYXB0dXJlIG9ubHk7IGRlY2lzaW9uIHVuY2hhbmdlZC4gT3JpZ2luYWwgcmV2aWV3ZWQgcHJvcG9zYWwgaXMgQURSLTAwMDItMDAxLXJldmlld2VkLnR4dCBhdCBTSEEyNTYgZmJhNGUzYThhNWY3MWM4YmY1NTk5YmRkOTJjMTdlZTE5OTBmYzgzMWRkOWNhODlkOWY4NWViMTZmY2M5OTM2My4gRmljdGlvbmFsIGlucHV0LCBub3QgYWN0dWFsIHB1Ymxpc2hlciBhcHByb3ZhbC5cbiIsCiAgICAgICJ2ZXJpZmllZF9jb21taXQiOiBudWxsLAogICAgICAibGltaXRhdGlvbnMiOiBbXQogICAgfSwKICAgIHsKICAgICAgImlkIjogIkVBRFItQVBQUk9WQUwiLAogICAgICAia2luZCI6ICJhcHByb3ZhbCIsCiAgICAgICJsb2NhdG9yIjogImZpeHR1cmU6YWRyL2FwcHJvdmFsLnR4dCIsCiAgICAgICJyZXZpc2lvbiI6ICJmMjQyMTg1ZjIzMzI4ODUzODJhNDIxYjU3ZDUxNmUwZGIxOTAwMjA1IiwKICAgICAgInNoYTI1NiI6ICJkZDE0M2ExOWE1ZWEwNjY4NTY0YzZkMTI1YzRmY2FmYjhmMzgyZjgyZDFkZjNkZDVjOWEzNzE5M2VmN2YzYzFlIiwKICAgICAgImF2YWlsYWJpbGl0eSI6ICJhdmFpbGFibGUiLAogICAgICAiY29udGVudCI6ICJGSUNUSU9OQUwgcmVzcG9uc2UgZnJvbSBmaXh0dXJlIG9wZXJhdG9yLCAyMDI2LTExLTE1OiBBcHByb3ZlIEFEUi0wMDAyIGVkaXRpb24gMiBhcyB3cml0dGVuLiBUaGUgb25seSBhdmFpbGFibGUgcmV2aWV3ZWQgcHJvcG9zYWwgaXMgZWRpdGlvbiAxLCBTSEEyNTYgZmJhNGUzYThhNWY3MWM4YmY1NTk5YmRkOTJjMTdlZTE5OTBmYzgzMWRkOWNhODlkOWY4NWViMTZmY2M5OTM2Mzsgbm8gZWRpdGlvbi0xIHJlc3BvbnNlIGV4aXN0cy4iLAogICAgICAidmVyaWZpZWRfY29tbWl0IjogbnVsbCwKICAgICAgImxpbWl0YXRpb25zIjogW10KICAgIH0KICBdLAogICJsaW1pdGF0aW9ucyI6IFtdCn0K",
      "kind": "other",
      "limitations": [
        "Original complete/SATISFIED assertions are preserved data, not accepted current claims."
      ],
      "revision": "917e6fc1679ff3c4e9cf5dc5241db8ad700f732b1514734d167c0730316a88f2"
    }
  ],
  "limitations": [
    "Actual EADR-APPROVAL response names Approve ADR-0002 edition 2 as written, while reviewed proposal is ADR-0002 edition1. Metadata claims edition1 but cannot change actual response. Matching reviewed hash in the response does not repair its wrong named edition.",
    "Prior accepted ADR-0001 edition1 approves project ownership. New ADR-0002 edition1 changes writes to a remote service; old approval and accepted pair cannot transfer.",
    "All declared embedded evidence content hashes match actual UTF-8 bytes. Missing/wrong-edition approval alone independently blocks replacement.",
    "S1 prose still cites old reviewed SHA256 4d6375c792aefeb7aa8c61f22460d5cbc6b2dedf6f8759ed355202b9a30085dc, while actual reviewed/current/response hashes are reconciled. This retained prose pointer is separately disclosed and is not needed for the approval-gate verdict.",
    "Supplied rechecks claim unchanged, but actual interaction availability/edition disproves a usable current approval. Simplified prior receipt has no root/index/blob/mode guards, and no local pair commit authority is granted for this control. Offline fixture only; no live current-source recheck or accepted new delivery."
  ]
}

~~~
