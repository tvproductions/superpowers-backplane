This is the independant fixture note.
