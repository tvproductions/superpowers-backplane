Correct this independent fixture note.
