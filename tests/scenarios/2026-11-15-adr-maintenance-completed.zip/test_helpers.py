"""Exercise actual guide helper behavior without running a native host or network call."""

import contextlib
import hashlib
import io
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import guide_helpers as guide

SHA = "a" * 40
PRIOR = "b" * 40


class GuideBehaviorTests(unittest.TestCase):
    """Validate refusal, preservation, exact catalog state and child-process boundaries."""

    def setUp(self):
        """Allocate only an owned fixture area and supply the guide's interactive inputs."""
        temporary = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1])
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        guide.profile = self.root / "profile"
        guide.profile.mkdir()
        guide.catalog = self.root / "catalog"
        guide.repo = "tvproductions/superpowers-backplane"

    def test_pin_refuses_invalid_revision_without_writing(self):
        """Malformed source input cannot create a catalog."""
        with self.assertRaisesRegex(ValueError, "40-character"):
            guide.pin("not-a-revision")
        self.assertFalse(guide.catalog.exists())

    def test_pin_writes_exact_owned_catalog(self):
        """Verified source produces the documented native catalog with no temp residue."""
        with patch.object(guide, "native", return_value=SHA + "\n"):
            guide.pin(SHA)
        manifest = guide.catalog / ".claude-plugin/marketplace.json"
        actual = json.loads(manifest.read_text(encoding="utf-8"))
        self.assertEqual(actual, {
            "name": "superpowers-backplane",
            "description": "Pinned Backplane hosted-source catalog",
            "owner": {"name": "tvproductions"},
            "plugins": [{
                "name": "superpowers-backplane",
                "description": "Pinned Backplane package",
                "source": {"source": "github", "repo": guide.repo, "sha": SHA},
            }],
        })
        self.assertEqual(list(manifest.parent.iterdir()), [manifest])

    def test_pin_preserves_prior_on_unavailable_candidate(self):
        """Failed source verification retains the exact prior catalog bytes."""
        with patch.object(guide, "native", return_value=PRIOR):
            guide.pin(PRIOR)
        manifest = guide.catalog / ".claude-plugin/marketplace.json"
        before = manifest.read_bytes()
        with patch.object(guide, "native", return_value=PRIOR):
            with self.assertRaisesRegex(ValueError, "Source unavailable"):
                guide.pin(SHA)
        self.assertEqual(manifest.read_bytes(), before)

    def test_pin_refuses_unowned_catalog(self):
        """An occupied unrelated manifest is preserved, rather than repaired."""
        manifest = guide.catalog / ".claude-plugin/marketplace.json"
        manifest.parent.mkdir(parents=True)
        before = b'{"name":"unrelated","plugins":[]}'
        manifest.write_bytes(before)
        with self.assertRaisesRegex(ValueError, "Occupied catalog"):
            guide.pin(SHA)
        self.assertEqual(manifest.read_bytes(), before)

    def test_pin_cleans_temp_after_failed_atomic_replace(self):
        """A failed atomic replacement does not leave a partial manifest or temp file."""
        with patch.object(guide, "native", return_value=SHA):
            with patch.object(Path, "replace", side_effect=OSError("fixture replace failure")):
                with self.assertRaises(OSError):
                    guide.pin(SHA)
        self.assertEqual(list((guide.catalog / ".claude-plugin").iterdir()), [])

    def test_native_missing_command_is_explicit(self):
        """A missing executable is refused before a subprocess can start."""
        with patch.object(guide.shutil, "which", return_value=None):
            with self.assertRaisesRegex(RuntimeError, "Required command unavailable"):
                guide.native("absent-fixture-command")

    def test_native_failed_command_reports_failure(self):
        """A nonzero native result cannot be reported as successful output."""
        completed = subprocess.CompletedProcess(["verified"], 7, "fixture stdout", "fixture stderr")
        with patch.object(guide.shutil, "which", return_value="/verified/command"):
            with patch.object(guide.subprocess, "run", return_value=completed):
                with self.assertRaisesRegex(RuntimeError, "fixture stdoutfixture stderr"):
                    guide.native("gh", "api", "fixture")

    def test_native_child_receives_arguments_and_isolation(self):
        """The constructed child boundary preserves argv/encoding/scope and parent state."""
        def echo_child(argv, **kwargs):
            environment = kwargs["env"]
            observed = {
                "argv": argv,
                "profile": environment.get("CLAUDE_CONFIG_DIR"),
                "rewrite": environment.get("GIT_CONFIG_KEY_2"),
                "count": environment.get("GIT_CONFIG_COUNT"),
                "shell": kwargs["shell"],
                "encoding": kwargs["encoding"],
                "check": kwargs["check"],
            }
            return subprocess.CompletedProcess(argv, 0, json.dumps(observed), "")

        with patch.dict(os.environ, {"GIT_CONFIG_COUNT": "2", "CLAUDE_CONFIG_DIR": "parent"}):
            before = hashlib.sha256(json.dumps(dict(os.environ), sort_keys=True).encode()).hexdigest()
            with patch.object(guide.shutil, "which", return_value="/verified/claude"):
                with patch.object(guide.subprocess, "run", side_effect=echo_child):
                    with contextlib.redirect_stdout(io.StringIO()):
                        result = guide.native("claude", "plugin", "list")
            after = hashlib.sha256(json.dumps(dict(os.environ), sort_keys=True).encode()).hexdigest()
            self.assertEqual(after, before)
        self.assertEqual(json.loads(result), {
            "argv": ["/verified/claude", "plugin", "list"],
            "profile": str(guide.profile),
            "rewrite": "url.https://github.com/tvproductions/superpowers-backplane.insteadOf",
            "count": "3", "shell": False, "encoding": "utf-8", "check": False,
        })

    def test_each_ownership_field_and_valid_update(self):
        with patch.object(guide, "native", return_value=SHA):
            guide.pin(SHA)
            guide.pin(SHA)
        manifest = guide.catalog / ".claude-plugin/marketplace.json"
        original = json.loads(manifest.read_text(encoding="utf-8"))
        for field in ("name", "plugin", "kind", "repo", "empty", "multiple"):
            for value in ("aaa", "zzz"):
                with self.subTest(field=field, value=value):
                    data = json.loads(json.dumps(original))
                    if field == "name": data["name"] = value
                    elif field == "plugin": data["plugins"][0]["name"] = value
                    elif field == "kind": data["plugins"][0]["source"]["source"] = value
                    elif field == "repo": data["plugins"][0]["source"]["repo"] = value
                    elif field == "empty": data["plugins"] = []
                    else: data["plugins"] *= 2
                    before = json.dumps(data).encode()
                    manifest.write_bytes(before)
                    with self.assertRaisesRegex(ValueError, "Occupied catalog"): guide.pin(SHA)
                    self.assertEqual(manifest.read_bytes(), before)

    def test_revision_mismatch_both_directions(self):
        for observed in ("0" * 40, "f" * 40):
            with patch.object(guide, "native", return_value=observed):
                with self.assertRaisesRegex(ValueError, "Source unavailable"): guide.pin(SHA)

    def test_native_boundary_variations(self):
        for command in ("aaa", "claude", "zzz"):
            for count in ("0", "1", "2", ""):
                for output in ("result", "result\n"):
                    with self.subTest(command=command, count=count, output=output):
                        with patch.dict(os.environ, {"GIT_CONFIG_COUNT": count, "CLAUDE_CONFIG_DIR": "parent"}):
                            completed = subprocess.CompletedProcess([], 0, output, "")
                            with patch.object(guide.shutil, "which", return_value="/verified/command") as which:
                                with patch.object(guide.subprocess, "run", return_value=completed) as run:
                                    stream = io.StringIO()
                                    with contextlib.redirect_stdout(stream):
                                        self.assertEqual(guide.native("".join(list(command)), "argument"), output)
                            which.assert_called_once_with(command)
                            args, options = run.call_args
                            self.assertEqual(args[0], ["/verified/command", "argument"])
                            self.assertTrue(options["capture_output"])
                            self.assertFalse(options["shell"])
                            self.assertEqual(options["errors"], "replace")
                            self.assertEqual(options["encoding"], "utf-8")
                            if command == "claude":
                                self.assertEqual(options["env"]["GIT_CONFIG_COUNT"], str(int(count or "0") + 1))
                                self.assertEqual(options["env"]["CLAUDE_CONFIG_DIR"], str(guide.profile))
                            else: self.assertEqual(options["env"]["CLAUDE_CONFIG_DIR"], "parent")
                            self.assertTrue(stream.getvalue().endswith("result\n"))
                            self.assertFalse(stream.getvalue().endswith("result\n\n"))
        with patch.object(guide.shutil, "which", return_value=None):
            with self.assertRaisesRegex(RuntimeError, "unavailable: missing-first$"):
                guide.native("missing-first", "different-last")


if __name__ == "__main__":
    unittest.main()
