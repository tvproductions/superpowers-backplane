# Backplane checkpoint

Format: sp-bp-checkpoint/v1
Capture ID: fixture-C1-local-boundary-20261115
JSON SHA-256: b8c83a18741d8a92920faf768ed03c7aac3a1620d3cfe459b7ad5eb36aac942e
Observation window: 2026-11-15T21:48:26Z to 2026-11-15T21:48:26Z
Mode / status / origin: issues-only / partial / invented-fixture
Repository: example/governance-fixture is historical example context. Current case repository is unknown; exact supplied issue URL is used as the issue identity; no repository identity inferred. Project null: supplied issues-only mode.
Source commit: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa (invented historical context, not current case delivery or storage commit).

This is an unaccepted diagnostic pair. No transaction receipt, acceptance commit, index change or publication occurred. Original checkpoint-input.json and all authority/input files retain their bytes. README.md spelling independently corrected. architecture.json remains local: capture scope requested recording, not implementation.

## Product hierarchy and native work

Historical example #101 remains OPEN/review, no parent/children/dependencies, PR201 merged at delivery B (bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb), neutral contribution and no closing references. Supplied EV1 is retained as historical; its original wording and acceptance evidence remain intact.
Current case #105 is OPEN/active, parent null, zero children/blockers/blocking, no closing PRs. Native issue type null; assignees/milestone unknown. Selected plan consumes matching 2026-11-15T00:00:00Z. Frozen native relations are complete for supplied leaf fields; assignees and current repository/source identity are unavailable. No native state mutated.

## Approved obligations and dispositions

Historical R1 at S1: Preserve an existing valid installation. AC1: Preserve the existing valid installation. Owner fixture-owner; contribution PR201, authority S1 approved by A1, review A2, E1/RV1 at B. No dispositions supplied.
Current criterion: Source choice matches an applicable approved decision; spelling corrected. Authority CASE-SPEC at its exact file hash, local execution CASE-PLAN. ADR-0001 edition 1 Current, approved_revision 1, remote owns source_of_truth for this case architecture.json only. Approval CASE-ADR-APPROVAL is fictional fixture operator's 2026-11-15 explicit response identifying edition 1 and reviewed SHA256 033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c. Administrative capture is disclosed in the preserved ADR; reviewed proposal bytes are embedded independently.

## Coverage and evaluated satisfaction

EV1: supplied SATISFIED at historical S1/B with E1/RV1 and A2, now explicitly historical for this expanded capture. It is unrelated to #105.
CASE-LOCAL-OBSERVATION: UNSATISFIED/current local observation, no verified commit and no accepted evaluation pointer. architecture.json local conflicts with approved remote. README spelling is corrected. checks.json PASS covers syntax only. Integrated satisfaction UNKNOWN; no review/delivery/acceptance evidence for #105 supplied. Architectural approval supplies no publication permission.

## Release targets

No current milestone or publication authority supplied. No release, integration, closure or acceptance authorized or observed.

## Authority and evidence availability

Actual routes: managing-superpowers-backlog references/repository-checkpoint.md, checkpoint-format.md, checkpoint-state-template.md and github-issue-contract.md; gzs-architectural-decisions SKILL.md and adr-template.md. Working policy ../docs/engineering/architectural-decisions.md from starter f42e6f186f062493c09fc2c2dc935e9a64310e33, SHA256 66353e4b5b889edfd2eb7f3307493648099ce88bf7120c92657a15281af34428. Selected portable v0.13.0 source 0bdab63fc503c6b36e2dd487932689b4e555e41a. Manual source loading does not prove native discovery or qualification.
Existing Authority project-instructions kind carries ADR content and identity/edition; approval kind carries actual staged response. Evidence records retain exact file contents and SHA256, including full original input example. Local task, architectural approval, integrated acceptance and publication remain distinct.

## Limitations and next reconciliation

Partial scope, missing governance reference and source identities prevent full reconstructability or acceptance. This diagnostic does not replace an accepted pair. Reconcile actual repository/source, missing collections, architectural alignment, delivery review and integrated checks before future authorized acceptance. No live query was made.

## Complete structured account

The following is a lossless readable expansion of every structured record, including wording, page cursors, authority revisions, evidence content, remaining obligations and limitations. It is the authoritative detail for the synopsis above.

Historical issue #101 current accepted-evaluation pointer is cleared; its original pointer is preserved in embedded checkpoint-input.json. Current #105 uses its exact supplied URL as ID. No repository identity was invented.


### format

```json
"sp-bp-checkpoint/v1"
```

### capture

```json
{
  "id": "fixture-C1-local-boundary-20261115",
  "started_at": "2026-11-15T21:48:26Z",
  "finished_at": "2026-11-15T21:48:26Z",
  "mode": "issues-only",
  "status": "partial",
  "origin": "invented-fixture",
  "rechecks": [
    {
      "approval_ids": [],
      "final_revision": "2026-11-15T00:00:00Z",
      "details": "Frozen input reread; full body and native relationships compared within offline fixture only.",
      "initial_revision": "2026-11-15T00:00:00Z",
      "result": "unchanged",
      "id": "https://example.invalid/fixture/issues/105",
      "kind": "issue"
    },
    {
      "approval_ids": [],
      "final_revision": "5a6d5d3660b7b943e32f2137ef607bbefd8737f5d573003b652b2b8a76014d05",
      "details": "Actual frozen file hash rechecked; no live query.",
      "initial_revision": "5a6d5d3660b7b943e32f2137ef607bbefd8737f5d573003b652b2b8a76014d05",
      "result": "unchanged",
      "id": "CASE-FILE:issue.json",
      "kind": "evidence"
    },
    {
      "approval_ids": [],
      "final_revision": "dc57556d5c03eb421fea3c75076b48c1d9911fdedbb9f5f3fc073b3ed48aabd3",
      "details": "Actual frozen file hash rechecked; no live query.",
      "initial_revision": "dc57556d5c03eb421fea3c75076b48c1d9911fdedbb9f5f3fc073b3ed48aabd3",
      "result": "unchanged",
      "id": "CASE-FILE:spec.md",
      "kind": "evidence"
    },
    {
      "approval_ids": [],
      "final_revision": "dc57556d5c03eb421fea3c75076b48c1d9911fdedbb9f5f3fc073b3ed48aabd3",
      "details": "Actual local content/hash checked.",
      "initial_revision": "dc57556d5c03eb421fea3c75076b48c1d9911fdedbb9f5f3fc073b3ed48aabd3",
      "result": "unchanged",
      "id": "CASE-SPEC",
      "kind": "authority"
    },
    {
      "approval_ids": [],
      "final_revision": "02970ef01acbcdb779bf056870f39b101f80bbbdff27ad9315c151cfde84a360",
      "details": "Actual frozen file hash rechecked; no live query.",
      "initial_revision": "02970ef01acbcdb779bf056870f39b101f80bbbdff27ad9315c151cfde84a360",
      "result": "unchanged",
      "id": "CASE-FILE:plan.md",
      "kind": "evidence"
    },
    {
      "approval_ids": [],
      "final_revision": "02970ef01acbcdb779bf056870f39b101f80bbbdff27ad9315c151cfde84a360",
      "details": "Actual local content/hash checked.",
      "initial_revision": "02970ef01acbcdb779bf056870f39b101f80bbbdff27ad9315c151cfde84a360",
      "result": "unchanged",
      "id": "CASE-PLAN",
      "kind": "authority"
    },
    {
      "approval_ids": [],
      "final_revision": "af6a236f2817c786486638eb18818362e012352943b91a89ec685b4a548f107b",
      "details": "Actual frozen file hash rechecked; no live query.",
      "initial_revision": "af6a236f2817c786486638eb18818362e012352943b91a89ec685b4a548f107b",
      "result": "unchanged",
      "id": "CASE-FILE:architecture.json",
      "kind": "evidence"
    },
    {
      "approval_ids": [],
      "final_revision": "b5e1755037056a48c5d8c3b285d6ccb86fbe67846083497ef4e2a287213789a3",
      "details": "Actual frozen file hash rechecked; no live query.",
      "initial_revision": "b5e1755037056a48c5d8c3b285d6ccb86fbe67846083497ef4e2a287213789a3",
      "result": "unchanged",
      "id": "CASE-FILE:checks.json",
      "kind": "evidence"
    },
    {
      "approval_ids": [],
      "final_revision": "9acfab2361a004b0c6641d769332a4fa7ff25fe6106e9561af81119e7f662d38",
      "details": "Actual frozen file hash rechecked; no live query.",
      "initial_revision": "9acfab2361a004b0c6641d769332a4fa7ff25fe6106e9561af81119e7f662d38",
      "result": "unchanged",
      "id": "CASE-FILE:docs/decisions/ADR-0001-001-fixture-source-authority.md",
      "kind": "evidence"
    },
    {
      "approval_ids": [
        "CASE-ADR-APPROVAL"
      ],
      "final_revision": "9acfab2361a004b0c6641d769332a4fa7ff25fe6106e9561af81119e7f662d38",
      "details": "Actual local content/hash checked.",
      "initial_revision": "9acfab2361a004b0c6641d769332a4fa7ff25fe6106e9561af81119e7f662d38",
      "result": "unchanged",
      "id": "CASE-ADR-0001-001",
      "kind": "authority"
    },
    {
      "approval_ids": [],
      "final_revision": "033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c",
      "details": "Actual frozen file hash rechecked; no live query.",
      "initial_revision": "033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c",
      "result": "unchanged",
      "id": "CASE-FILE:docs/decisions/ADR-0001-001-reviewed.txt",
      "kind": "evidence"
    },
    {
      "approval_ids": [],
      "final_revision": "b8b2ba425be76f5742dcd5a30472b3ce342d3b8b6e3c56302da44feaab56b69f",
      "details": "Actual frozen file hash rechecked; no live query.",
      "initial_revision": "b8b2ba425be76f5742dcd5a30472b3ce342d3b8b6e3c56302da44feaab56b69f",
      "result": "unchanged",
      "id": "CASE-FILE:docs/decisions/approval.txt",
      "kind": "evidence"
    },
    {
      "approval_ids": [],
      "final_revision": "b8b2ba425be76f5742dcd5a30472b3ce342d3b8b6e3c56302da44feaab56b69f",
      "details": "Actual local content/hash checked.",
      "initial_revision": "b8b2ba425be76f5742dcd5a30472b3ce342d3b8b6e3c56302da44feaab56b69f",
      "result": "unchanged",
      "id": "CASE-ADR-APPROVAL",
      "kind": "authority"
    },
    {
      "approval_ids": [],
      "final_revision": "a27981c537d850c991b3a389be276e5577356777bd6c149e4395f876798fd13b",
      "details": "Actual frozen file hash rechecked; no live query.",
      "initial_revision": "a27981c537d850c991b3a389be276e5577356777bd6c149e4395f876798fd13b",
      "result": "unchanged",
      "id": "CASE-FILE:checkpoint-input.json",
      "kind": "evidence"
    },
    {
      "approval_ids": [],
      "final_revision": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
      "details": "Supplied historical embedded record retained, not live revalidated.",
      "initial_revision": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
      "result": "unchanged",
      "id": "S1",
      "kind": "authority"
    },
    {
      "approval_ids": [],
      "final_revision": "2026-10-01T12:00:00Z",
      "details": "Supplied historical embedded record retained, not live revalidated.",
      "initial_revision": "2026-10-01T12:00:00Z",
      "result": "unchanged",
      "id": "A1",
      "kind": "authority"
    },
    {
      "approval_ids": [],
      "final_revision": "2026-10-01T12:00:00Z",
      "details": "Supplied historical embedded record retained, not live revalidated.",
      "initial_revision": "2026-10-01T12:00:00Z",
      "result": "unchanged",
      "id": "A2",
      "kind": "authority"
    },
    {
      "approval_ids": [],
      "final_revision": null,
      "details": "Frozen leaf relationships available; assignees, repository identity and current delivery source missing. Historical graph retained separately.",
      "initial_revision": null,
      "result": "unavailable",
      "id": "current-case-graph",
      "kind": "graph"
    },
    {
      "kind": "evidence",
      "id": "CASE-FILE:README.md",
      "result": "unchanged",
      "final_revision": "4a9d3ecb83e0fa5a3c5c11e7c983d11f143159f69053b097d63d4657fb57cf3c",
      "details": "Read final corrected local file and verified exact bytes/hash.",
      "initial_revision": "4a9d3ecb83e0fa5a3c5c11e7c983d11f143159f69053b097d63d4657fb57cf3c",
      "approval_ids": []
    }
  ]
}
```

### repository

```json
{
  "id": "example/governance-fixture",
  "url": "https://github.com/example/governance-fixture",
  "owner": "example",
  "name": "governance-fixture"
}
```

### project

```json
null
```

### source

```json
{
  "commit": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
}
```

### scope

```json
{
  "issue_ids": [
    "example/governance-fixture#101",
    "https://example.invalid/fixture/issues/105"
  ],
  "excluded_ids": [],
  "external_records": [],
  "collections": [
    {
      "name": "issues",
      "owner_id": "example/governance-fixture",
      "expected_total": 1,
      "pages": [
        {
          "cursor_in": null,
          "cursor_out": null,
          "record_ids": [
            "example/governance-fixture#101"
          ],
          "has_next_page": false
        }
      ],
      "complete": true
    },
    {
      "name": "subIssues",
      "owner_id": "example/governance-fixture#101",
      "expected_total": 0,
      "pages": [
        {
          "cursor_in": null,
          "cursor_out": null,
          "record_ids": [],
          "has_next_page": false
        }
      ],
      "complete": true
    },
    {
      "name": "blockedBy",
      "owner_id": "example/governance-fixture#101",
      "expected_total": 0,
      "pages": [
        {
          "cursor_in": null,
          "cursor_out": null,
          "record_ids": [],
          "has_next_page": false
        }
      ],
      "complete": true
    },
    {
      "name": "blocking",
      "owner_id": "example/governance-fixture#101",
      "expected_total": 0,
      "pages": [
        {
          "cursor_in": null,
          "cursor_out": null,
          "record_ids": [],
          "has_next_page": false
        }
      ],
      "complete": true
    },
    {
      "name": "closingPRReferences",
      "owner_id": "example/governance-fixture#101",
      "expected_total": 0,
      "pages": [
        {
          "cursor_in": null,
          "cursor_out": null,
          "record_ids": [],
          "has_next_page": false
        }
      ],
      "complete": true
    },
    {
      "name": "labels",
      "owner_id": "example/governance-fixture#101",
      "expected_total": 1,
      "pages": [
        {
          "cursor_in": null,
          "cursor_out": "fixture-L1",
          "record_ids": [
            "L1"
          ],
          "has_next_page": false
        }
      ],
      "complete": true
    },
    {
      "name": "assignees",
      "owner_id": "example/governance-fixture#101",
      "expected_total": 1,
      "pages": [
        {
          "cursor_in": null,
          "cursor_out": null,
          "record_ids": [
            "fixture-owner"
          ],
          "has_next_page": false
        }
      ],
      "complete": true
    },
    {
      "name": "pullRequests",
      "owner_id": "example/governance-fixture",
      "expected_total": 1,
      "pages": [
        {
          "cursor_in": null,
          "cursor_out": null,
          "record_ids": [
            "example/governance-fixture!201"
          ],
          "has_next_page": false
        }
      ],
      "complete": true
    },
    {
      "name": "closingIssuesReferences",
      "owner_id": "example/governance-fixture!201",
      "expected_total": 0,
      "pages": [
        {
          "cursor_in": null,
          "cursor_out": null,
          "has_next_page": false,
          "record_ids": []
        }
      ],
      "complete": true
    },
    {
      "owner_id": "https://example.invalid/fixture/issues/105",
      "complete": true,
      "expected_total": 0,
      "name": "subIssues",
      "pages": [
        {
          "cursor_out": null,
          "has_next_page": false,
          "cursor_in": null,
          "record_ids": []
        }
      ]
    },
    {
      "owner_id": "https://example.invalid/fixture/issues/105",
      "complete": true,
      "expected_total": 0,
      "name": "blockedBy",
      "pages": [
        {
          "cursor_out": null,
          "has_next_page": false,
          "cursor_in": null,
          "record_ids": []
        }
      ]
    },
    {
      "owner_id": "https://example.invalid/fixture/issues/105",
      "complete": true,
      "expected_total": 0,
      "name": "blocking",
      "pages": [
        {
          "cursor_out": null,
          "has_next_page": false,
          "cursor_in": null,
          "record_ids": []
        }
      ]
    },
    {
      "owner_id": "https://example.invalid/fixture/issues/105",
      "complete": true,
      "expected_total": 0,
      "name": "closingPRReferences",
      "pages": [
        {
          "cursor_out": null,
          "has_next_page": false,
          "cursor_in": null,
          "record_ids": []
        }
      ]
    },
    {
      "owner_id": "https://example.invalid/fixture/issues/105",
      "complete": true,
      "expected_total": 1,
      "name": "labels",
      "pages": [
        {
          "cursor_out": null,
          "has_next_page": false,
          "cursor_in": null,
          "record_ids": [
            "backplane:active"
          ]
        }
      ]
    },
    {
      "owner_id": "https://example.invalid/fixture/issues/105",
      "complete": false,
      "expected_total": null,
      "name": "assignees",
      "pages": []
    }
  ],
  "complete": false
}
```

### issues

```json
[
  {
    "id": "example/governance-fixture#101",
    "number": 101,
    "url": "https://github.com/example/governance-fixture/issues/101",
    "title": "Preserve an existing valid installation",
    "body": "## Objective\nPreserve an existing valid installation.\n## Acceptance Criteria\nAC1: Preserve the existing valid installation.\n## Backplane Record\nCode: CAP1.1; Kind: outcome; authority S1.\n## Coverage and Satisfaction\nAC1 maps to R1/S1; accepted evaluation EV1 at delivery B is SATISFIED.\n",
    "state": "OPEN",
    "state_reason": "",
    "issue_type": {
      "id": "TYPE_FEATURE",
      "name": "Feature",
      "description": "Fixture native issue type",
      "color": "GREEN"
    },
    "labels": [
      {
        "id": "L1",
        "name": "backplane:review",
        "description": "Awaiting closeout",
        "color": "5319e7"
      }
    ],
    "assignees": [
      "fixture-owner"
    ],
    "milestone": null,
    "updated_at": "2026-10-01T12:00:00Z",
    "parent_id": null,
    "child_ids": [],
    "sub_issues_summary": {
      "total": 0,
      "completed": 0,
      "percent_completed": 0
    },
    "blocked_by_ids": [],
    "blocking_ids": [],
    "closing_pr_ids": [],
    "backplane_record": {
      "code": "CAP1.1",
      "namespace": "CAP1",
      "kind": "outcome",
      "authority_ids": [
        "S1"
      ]
    },
    "accepted_evaluation_ids": [],
    "limitations": [
      "Original EV1 accepted pointer retained in embedded checkpoint-input.json; removed from current pointers because EV1 is historical in this diagnostic."
    ]
  },
  {
    "labels": [
      {
        "color": null,
        "id": null,
        "name": "backplane:active",
        "description": null
      }
    ],
    "parent_id": null,
    "url": "https://example.invalid/fixture/issues/105",
    "state_reason": "",
    "milestone": null,
    "blocked_by_ids": [],
    "body": "## Objective\nApply the selected source-authority choice locally.\n## Bounded Scope\n### Allowed\nThis case only: requested deliverable/capture and spelling correction.\n### Out of Scope\nLive issue changes and publication.\n## Acceptance Criteria\nSource choice matches an applicable approved decision; spelling corrected.\n## Verification Seams\nRead exact local architecture.json and supplied checks.json.\n## Superpowers Artifacts\nApproved spec.md and plan.md; exact decision and approval files under docs/decisions.\n",
    "sub_issues_summary": {
      "total": 0,
      "completed": 0,
      "percent_completed": 0
    },
    "id": "https://example.invalid/fixture/issues/105",
    "blocking_ids": [],
    "backplane_record": null,
    "number": 105,
    "closing_pr_ids": [],
    "issue_type": null,
    "accepted_evaluation_ids": [],
    "updated_at": "2026-11-15T00:00:00Z",
    "state": "OPEN",
    "limitations": [
      "assignees and milestone not supplied; null denotes unknown.",
      "Accepted delivery evaluation not supplied; architecture local conflicts with approved remote.",
      "The historical example issue #101 is a different identity; its delivery B and accepted EV1 do not apply to case #105.",
      "Current case repository identity unknown; issue ID is exact supplied native URL."
    ],
    "title": "checkpoint-capture",
    "child_ids": [],
    "assignees": null
  }
]
```

### pull_requests

```json
[
  {
    "id": "example/governance-fixture!201",
    "number": 201,
    "url": "https://github.com/example/governance-fixture/pull/201",
    "title": "Preservation contribution",
    "body": "Refs #101; contributes AC1 at S1.",
    "state": "MERGED",
    "base_ref": "main",
    "head_ref": "fixture-preservation",
    "merged_at": "2026-10-01T11:00:00Z",
    "merge_commit": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
    "review_status": "accepted",
    "closing_issue_ids": [],
    "closure_intent": "contribution",
    "updated_at": "2026-10-01T12:00:00Z",
    "limitations": []
  }
]
```

### authorities

```json
[
  {
    "id": "S1",
    "kind": "specification",
    "locator": "fixture:spec/S1",
    "revision": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
    "content": "R1: Preserve an existing valid installation. AC1 implements R1.",
    "availability": "available",
    "approver": null,
    "approved_scope": null,
    "approval_ids": [
      "A1"
    ],
    "limitations": []
  },
  {
    "id": "A1",
    "kind": "approval",
    "locator": "fixture:approval/A1",
    "revision": "2026-10-01T12:00:00Z",
    "content": "Fixture approver approved R1 and AC1 at S1.",
    "availability": "available",
    "approver": "fixture-approver",
    "approved_scope": "R1/AC1 at S1",
    "approval_ids": [],
    "limitations": []
  },
  {
    "id": "A2",
    "kind": "approval",
    "locator": "fixture:review/A2",
    "revision": "2026-10-01T12:00:00Z",
    "content": "Fixture reviewer accepted AC1 at S1 and delivery B.",
    "availability": "available",
    "approver": "fixture-reviewer",
    "approved_scope": "AC1 at S1/B",
    "approval_ids": [],
    "limitations": []
  },
  {
    "revision": "dc57556d5c03eb421fea3c75076b48c1d9911fdedbb9f5f3fc073b3ed48aabd3",
    "approval_ids": [],
    "locator": "spec.md",
    "id": "CASE-SPEC",
    "availability": "available",
    "content": "FICTIONAL approved fixture design. Choose remote source authority for architecture.json. Architectural approval is separate. Scope excludes publication.\r\n",
    "kind": "specification",
    "limitations": [
      "Fictional fixture authority. ADR mapped to existing project-instructions kind; stable decision identity/edition remain in preserved content, not inferred from hash."
    ],
    "approver": null,
    "approved_scope": null
  },
  {
    "revision": "02970ef01acbcdb779bf056870f39b101f80bbbdff27ad9315c151cfde84a360",
    "approval_ids": [],
    "locator": "plan.md",
    "id": "CASE-PLAN",
    "availability": "available",
    "content": "FICTIONAL approved plan; selected issue https://example.invalid/fixture/issues/105, consumed updatedAt 2026-11-15T00:00:00Z. Native execution. Task: set source_of_truth to remote under applicable architecture authority; independently correct README spelling. Verification: inspect local JSON against applicable authority and checks.json. No issue closure/publication.\r\n",
    "kind": "plan",
    "limitations": [
      "Fictional fixture authority. ADR mapped to existing project-instructions kind; stable decision identity/edition remain in preserved content, not inferred from hash."
    ],
    "approver": null,
    "approved_scope": null
  },
  {
    "revision": "9acfab2361a004b0c6641d769332a4fa7ff25fe6106e9561af81119e7f662d38",
    "approval_ids": [
      "CASE-ADR-APPROVAL"
    ],
    "locator": "docs/decisions/ADR-0001-001-fixture-source-authority.md",
    "id": "CASE-ADR-0001-001",
    "availability": "available",
    "content": "---\r\nid: ADR-0001\r\ntitle: Fixture source authority\r\nrevision: 1\r\nstate: Current\r\ndecision_date: 2026-11-15\r\nrevision_date: 2026-11-15\r\napproved_by: fictional fixture operator\r\napproved_revision: 1\r\napproval_ref: approval.txt\r\n---\r\n\r\n# ADR-0001 edition 1: fixture source authority\r\n\r\nApproved choice: remote owns source_of_truth. Scope: this case's architecture.json only.\r\nAlternatives: local project authority or a remote canonical authority. Rationale: the fixture's selected product contract uses remote. Confirmation: inspect architecture.json and its reviewed approval. No publication or unrelated operation authority.\r\n\r\nAdministrative approval capture only; original reviewed bytes are retained at ADR-0001-001-reviewed.txt, SHA256 033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c. No choice changed.\r\n",
    "kind": "project-instructions",
    "limitations": [
      "Fictional fixture authority. ADR mapped to existing project-instructions kind; stable decision identity/edition remain in preserved content, not inferred from hash."
    ],
    "approver": null,
    "approved_scope": null
  },
  {
    "revision": "b8b2ba425be76f5742dcd5a30472b3ce342d3b8b6e3c56302da44feaab56b69f",
    "approval_ids": [],
    "locator": "docs/decisions/approval.txt",
    "id": "CASE-ADR-APPROVAL",
    "availability": "available",
    "content": "FICTIONAL STAGED EVALUATION INPUT, not real approval. Fixture operator on 2026-11-15: \"Approve ADR-0001 edition 1 as written\", exact reviewed SHA256 033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c. Source context: this invented test case, separate from its plan/design approval. This covers remote authority in architecture.json.\r\n",
    "kind": "approval",
    "limitations": [
      "Fictional fixture authority. ADR mapped to existing project-instructions kind; stable decision identity/edition remain in preserved content, not inferred from hash."
    ],
    "approver": "fictional fixture operator",
    "approved_scope": "ADR-0001 edition 1, reviewed SHA256 033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c; remote authority for this case architecture.json only"
  }
]
```

### requirements

```json
[
  {
    "id": "R1@S1",
    "key": "R1",
    "text": "Preserve an existing valid installation.",
    "authority_id": "S1",
    "authority_revision": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
  }
]
```

### criteria

```json
[
  {
    "id": "example/governance-fixture#101:AC1",
    "issue_id": "example/governance-fixture#101",
    "key": "AC1",
    "text": "Preserve the existing valid installation.",
    "authority_id": "S1",
    "authority_revision": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
    "delivery_commit": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
    "requirement_ids": [
      "R1@S1"
    ]
  },
  {
    "key": "AC-source",
    "requirement_ids": [],
    "id": "https://example.invalid/fixture/issues/105:AC-source",
    "authority_revision": "dc57556d5c03eb421fea3c75076b48c1d9911fdedbb9f5f3fc073b3ed48aabd3",
    "delivery_commit": null,
    "issue_id": "https://example.invalid/fixture/issues/105",
    "text": "Source choice matches an applicable approved decision; spelling corrected.",
    "authority_id": "CASE-SPEC"
  }
]
```

### dispositions

```json
[]
```

### coverage

```json
[
  {
    "id": "COV1",
    "issue_id": "example/governance-fixture#101",
    "criterion_id": "example/governance-fixture#101:AC1",
    "requirement_ids": [
      "R1@S1"
    ],
    "contribution_issue_ids": [
      "example/governance-fixture#101"
    ],
    "pr_ids": [
      "example/governance-fixture!201"
    ],
    "combined_result_owner": "fixture-owner",
    "scope": "The sole fixture criterion is covered by preservation contribution PR201."
  }
]
```

### evaluations

```json
[
  {
    "id": "EV1",
    "criterion_id": "example/governance-fixture#101:AC1",
    "requirement_ids": [
      "R1@S1"
    ],
    "verified_commit": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
    "method": "Fixture preservation verification",
    "observed_result": "PASS supplied by the invented fixture.",
    "result": "SATISFIED",
    "observed_at": "2026-10-01T12:00:00Z",
    "evidence_ids": [
      "E1",
      "RV1"
    ],
    "review_approval_ids": [
      "A2"
    ],
    "applicability": "historical",
    "remaining_contributions": [],
    "limitations": [
      "Retained historical example result at original S1/B; does not establish case #105 satisfaction."
    ]
  },
  {
    "observed_at": "2026-11-15T21:48:26Z",
    "requirement_ids": [],
    "id": "CASE-LOCAL-OBSERVATION",
    "verified_commit": null,
    "applicability": "current",
    "result": "UNSATISFIED",
    "method": "Inspect local architecture.json, README.md, ADR and supplied checks.json",
    "remaining_contributions": [
      "Local architecture alignment is not part of this capture-only operation.",
      "Integrated delivery, acceptance and publication remain unverified."
    ],
    "limitations": [
      "Local observation only; no accepted evaluation pointer or integrated claim."
    ],
    "review_approval_ids": [],
    "observed_result": "architecture source_of_truth=local; approved ADR-0001 edition 1 requires remote. README corrected to independent. Supplied PASS is syntax only.",
    "evidence_ids": [
      "CASE-FILE:architecture.json",
      "CASE-FILE:checks.json",
      "CASE-FILE:docs/decisions/ADR-0001-001-reviewed.txt",
      "CASE-FILE:docs/decisions/approval.txt",
      "CASE-FILE:README.md"
    ],
    "criterion_id": "https://example.invalid/fixture/issues/105:AC-source"
  }
]
```

### evidence

```json
[
  {
    "id": "E1",
    "kind": "verification",
    "locator": "fixture:verification/E1",
    "revision": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
    "sha256": null,
    "availability": "available",
    "content": "Invented fixture result: AC1 passed preservation verification against S1 and B.",
    "verified_commit": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
    "limitations": []
  },
  {
    "id": "RV1",
    "kind": "review",
    "locator": "fixture:review/RV1",
    "revision": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
    "sha256": null,
    "availability": "available",
    "content": "Invented fixture review accepted AC1 at S1/B.",
    "verified_commit": "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
    "limitations": []
  },
  {
    "revision": "5a6d5d3660b7b943e32f2137ef607bbefd8737f5d573003b652b2b8a76014d05",
    "locator": "issue.json",
    "id": "CASE-FILE:issue.json",
    "verified_commit": null,
    "availability": "available",
    "content": "{\r\n  \"number\": 105,\r\n  \"title\": \"checkpoint-capture\",\r\n  \"body\": \"## Objective\\nApply the selected source-authority choice locally.\\n## Bounded Scope\\n### Allowed\\nThis case only: requested deliverable/capture and spelling correction.\\n### Out of Scope\\nLive issue changes and publication.\\n## Acceptance Criteria\\nSource choice matches an applicable approved decision; spelling corrected.\\n## Verification Seams\\nRead exact local architecture.json and supplied checks.json.\\n## Superpowers Artifacts\\nApproved spec.md and plan.md; exact decision and approval files under docs/decisions.\\n\",\r\n  \"state\": \"OPEN\",\r\n  \"stateReason\": \"\",\r\n  \"issueType\": null,\r\n  \"labels\": [\r\n    {\r\n      \"name\": \"backplane:active\"\r\n    }\r\n  ],\r\n  \"parent\": null,\r\n  \"subIssues\": {\r\n    \"nodes\": [],\r\n    \"totalCount\": 0\r\n  },\r\n  \"subIssuesSummary\": {\r\n    \"completed\": 0,\r\n    \"percentCompleted\": 0,\r\n    \"total\": 0\r\n  },\r\n  \"blockedBy\": {\r\n    \"nodes\": [],\r\n    \"totalCount\": 0\r\n  },\r\n  \"blocking\": {\r\n    \"nodes\": [],\r\n    \"totalCount\": 0\r\n  },\r\n  \"closedByPullRequestsReferences\": [],\r\n  \"updatedAt\": \"2026-11-15T00:00:00Z\",\r\n  \"url\": \"https://example.invalid/fixture/issues/105\"\r\n}\r\n",
    "kind": "other",
    "limitations": [
      "Exact local UTF-8 content and SHA256 retained; no integrated delivery identity established."
    ],
    "sha256": "5a6d5d3660b7b943e32f2137ef607bbefd8737f5d573003b652b2b8a76014d05"
  },
  {
    "revision": "dc57556d5c03eb421fea3c75076b48c1d9911fdedbb9f5f3fc073b3ed48aabd3",
    "locator": "spec.md",
    "id": "CASE-FILE:spec.md",
    "verified_commit": null,
    "availability": "available",
    "content": "FICTIONAL approved fixture design. Choose remote source authority for architecture.json. Architectural approval is separate. Scope excludes publication.\r\n",
    "kind": "other",
    "limitations": [
      "Exact local UTF-8 content and SHA256 retained; no integrated delivery identity established."
    ],
    "sha256": "dc57556d5c03eb421fea3c75076b48c1d9911fdedbb9f5f3fc073b3ed48aabd3"
  },
  {
    "revision": "02970ef01acbcdb779bf056870f39b101f80bbbdff27ad9315c151cfde84a360",
    "locator": "plan.md",
    "id": "CASE-FILE:plan.md",
    "verified_commit": null,
    "availability": "available",
    "content": "FICTIONAL approved plan; selected issue https://example.invalid/fixture/issues/105, consumed updatedAt 2026-11-15T00:00:00Z. Native execution. Task: set source_of_truth to remote under applicable architecture authority; independently correct README spelling. Verification: inspect local JSON against applicable authority and checks.json. No issue closure/publication.\r\n",
    "kind": "other",
    "limitations": [
      "Exact local UTF-8 content and SHA256 retained; no integrated delivery identity established."
    ],
    "sha256": "02970ef01acbcdb779bf056870f39b101f80bbbdff27ad9315c151cfde84a360"
  },
  {
    "revision": "af6a236f2817c786486638eb18818362e012352943b91a89ec685b4a548f107b",
    "locator": "architecture.json",
    "id": "CASE-FILE:architecture.json",
    "verified_commit": null,
    "availability": "available",
    "content": "{\r\n  \"source_of_truth\": \"local\"\r\n}\r\n",
    "kind": "other",
    "limitations": [
      "Exact local UTF-8 content and SHA256 retained; no integrated delivery identity established."
    ],
    "sha256": "af6a236f2817c786486638eb18818362e012352943b91a89ec685b4a548f107b"
  },
  {
    "revision": "b5e1755037056a48c5d8c3b285d6ccb86fbe67846083497ef4e2a287213789a3",
    "locator": "checks.json",
    "id": "CASE-FILE:checks.json",
    "verified_commit": null,
    "availability": "available",
    "content": "{\"fixture_result\": \"PASS\", \"scope\": \"JSON syntax only; no architectural approval or integrated acceptance established\"}\r\n",
    "kind": "other",
    "limitations": [
      "Exact local UTF-8 content and SHA256 retained; no integrated delivery identity established."
    ],
    "sha256": "b5e1755037056a48c5d8c3b285d6ccb86fbe67846083497ef4e2a287213789a3"
  },
  {
    "revision": "9acfab2361a004b0c6641d769332a4fa7ff25fe6106e9561af81119e7f662d38",
    "locator": "docs/decisions/ADR-0001-001-fixture-source-authority.md",
    "id": "CASE-FILE:docs/decisions/ADR-0001-001-fixture-source-authority.md",
    "verified_commit": null,
    "availability": "available",
    "content": "---\r\nid: ADR-0001\r\ntitle: Fixture source authority\r\nrevision: 1\r\nstate: Current\r\ndecision_date: 2026-11-15\r\nrevision_date: 2026-11-15\r\napproved_by: fictional fixture operator\r\napproved_revision: 1\r\napproval_ref: approval.txt\r\n---\r\n\r\n# ADR-0001 edition 1: fixture source authority\r\n\r\nApproved choice: remote owns source_of_truth. Scope: this case's architecture.json only.\r\nAlternatives: local project authority or a remote canonical authority. Rationale: the fixture's selected product contract uses remote. Confirmation: inspect architecture.json and its reviewed approval. No publication or unrelated operation authority.\r\n\r\nAdministrative approval capture only; original reviewed bytes are retained at ADR-0001-001-reviewed.txt, SHA256 033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c. No choice changed.\r\n",
    "kind": "other",
    "limitations": [
      "Exact local UTF-8 content and SHA256 retained; no integrated delivery identity established."
    ],
    "sha256": "9acfab2361a004b0c6641d769332a4fa7ff25fe6106e9561af81119e7f662d38"
  },
  {
    "revision": "033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c",
    "locator": "docs/decisions/ADR-0001-001-reviewed.txt",
    "id": "CASE-FILE:docs/decisions/ADR-0001-001-reviewed.txt",
    "verified_commit": null,
    "availability": "available",
    "content": "# ADR-0001 edition 1: fixture source authority\r\n\r\nDraft: remote owns source_of_truth. Scope: this case's architecture.json only.\r\nAlternatives: local project authority or a remote canonical authority. Rationale: the fixture's selected product contract uses remote. Confirmation: inspect architecture.json and its reviewed approval. No publication or unrelated operation authority.\r\n",
    "kind": "other",
    "limitations": [
      "Exact local UTF-8 content and SHA256 retained; no integrated delivery identity established."
    ],
    "sha256": "033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c"
  },
  {
    "revision": "b8b2ba425be76f5742dcd5a30472b3ce342d3b8b6e3c56302da44feaab56b69f",
    "locator": "docs/decisions/approval.txt",
    "id": "CASE-FILE:docs/decisions/approval.txt",
    "verified_commit": null,
    "availability": "available",
    "content": "FICTIONAL STAGED EVALUATION INPUT, not real approval. Fixture operator on 2026-11-15: \"Approve ADR-0001 edition 1 as written\", exact reviewed SHA256 033a14c67bb24e20800908872f346b9f7370a5c2cf54a3a6fa65d34e2adc3c1c. Source context: this invented test case, separate from its plan/design approval. This covers remote authority in architecture.json.\r\n",
    "kind": "other",
    "limitations": [
      "Exact local UTF-8 content and SHA256 retained; no integrated delivery identity established."
    ],
    "sha256": "b8b2ba425be76f5742dcd5a30472b3ce342d3b8b6e3c56302da44feaab56b69f"
  },
  {
    "revision": "a27981c537d850c991b3a389be276e5577356777bd6c149e4395f876798fd13b",
    "locator": "checkpoint-input.json",
    "id": "CASE-FILE:checkpoint-input.json",
    "verified_commit": null,
    "availability": "available",
    "content": "{\r\n  \"format\": \"sp-bp-checkpoint/v1\",\r\n  \"capture\": {\r\n    \"id\": \"fixture-C1\",\r\n    \"started_at\": \"2026-10-01T12:10:00Z\",\r\n    \"finished_at\": \"2026-10-01T12:11:00Z\",\r\n    \"mode\": \"issues-only\",\r\n    \"status\": \"complete\",\r\n    \"origin\": \"invented-fixture\",\r\n    \"rechecks\": [\r\n      {\r\n        \"kind\": \"issue\",\r\n        \"id\": \"example/governance-fixture#101\",\r\n        \"initial_revision\": \"2026-10-01T12:00:00Z\",\r\n        \"final_revision\": \"2026-10-01T12:00:00Z\",\r\n        \"result\": \"unchanged\",\r\n        \"approval_ids\": [],\r\n        \"details\": \"Fixture full body/native relationships unchanged.\"\r\n      },\r\n      {\r\n        \"kind\": \"graph\",\r\n        \"id\": \"selected-native-graph\",\r\n        \"initial_revision\": \"fixture-graph-1\",\r\n        \"final_revision\": \"fixture-graph-1\",\r\n        \"result\": \"unchanged\",\r\n        \"approval_ids\": [],\r\n        \"details\": \"All selected connections enumerated and compared.\"\r\n      },\r\n      {\r\n        \"kind\": \"authority\",\r\n        \"id\": \"S1\",\r\n        \"initial_revision\": \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\",\r\n        \"final_revision\": \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\",\r\n        \"result\": \"unchanged\",\r\n        \"approval_ids\": [],\r\n        \"details\": \"Embedded fixture authority unchanged.\"\r\n      },\r\n      {\r\n        \"kind\": \"authority\",\r\n        \"id\": \"A1\",\r\n        \"initial_revision\": \"2026-10-01T12:00:00Z\",\r\n        \"final_revision\": \"2026-10-01T12:00:00Z\",\r\n        \"result\": \"unchanged\",\r\n        \"approval_ids\": [],\r\n        \"details\": \"Embedded fixture authority unchanged.\"\r\n      },\r\n      {\r\n        \"kind\": \"authority\",\r\n        \"id\": \"A2\",\r\n        \"initial_revision\": \"2026-10-01T12:00:00Z\",\r\n        \"final_revision\": \"2026-10-01T12:00:00Z\",\r\n        \"result\": \"unchanged\",\r\n        \"approval_ids\": [],\r\n        \"details\": \"Embedded fixture authority unchanged.\"\r\n      },\r\n      {\r\n        \"kind\": \"evidence\",\r\n        \"id\": \"E1\",\r\n        \"initial_revision\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\r\n        \"final_revision\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\r\n        \"result\": \"unchanged\",\r\n        \"approval_ids\": [],\r\n        \"details\": \"Embedded fixture evidence unchanged.\"\r\n      },\r\n      {\r\n        \"kind\": \"evidence\",\r\n        \"id\": \"RV1\",\r\n        \"initial_revision\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\r\n        \"final_revision\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\r\n        \"result\": \"unchanged\",\r\n        \"approval_ids\": [],\r\n        \"details\": \"Embedded fixture evidence unchanged.\"\r\n      },\r\n      {\r\n        \"kind\": \"delivery\",\r\n        \"id\": \"example/governance-fixture#101\",\r\n        \"initial_revision\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\r\n        \"final_revision\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\r\n        \"result\": \"unchanged\",\r\n        \"approval_ids\": [],\r\n        \"details\": \"Fixture current delivery B; source A identifies the capture context rather than the verified delivery.\"\r\n      }\r\n    ]\r\n  },\r\n  \"repository\": {\r\n    \"id\": \"example/governance-fixture\",\r\n    \"url\": \"https://github.com/example/governance-fixture\",\r\n    \"owner\": \"example\",\r\n    \"name\": \"governance-fixture\"\r\n  },\r\n  \"project\": null,\r\n  \"source\": {\r\n    \"commit\": \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"\r\n  },\r\n  \"scope\": {\r\n    \"issue_ids\": [\r\n      \"example/governance-fixture#101\"\r\n    ],\r\n    \"excluded_ids\": [],\r\n    \"external_records\": [],\r\n    \"collections\": [\r\n      {\r\n        \"name\": \"issues\",\r\n        \"owner_id\": \"example/governance-fixture\",\r\n        \"expected_total\": 1,\r\n        \"pages\": [\r\n          {\r\n            \"cursor_in\": null,\r\n            \"cursor_out\": null,\r\n            \"record_ids\": [\r\n              \"example/governance-fixture#101\"\r\n            ],\r\n            \"has_next_page\": false\r\n          }\r\n        ],\r\n        \"complete\": true\r\n      },\r\n      {\r\n        \"name\": \"subIssues\",\r\n        \"owner_id\": \"example/governance-fixture#101\",\r\n        \"expected_total\": 0,\r\n        \"pages\": [\r\n          {\r\n            \"cursor_in\": null,\r\n            \"cursor_out\": null,\r\n            \"record_ids\": [],\r\n            \"has_next_page\": false\r\n          }\r\n        ],\r\n        \"complete\": true\r\n      },\r\n      {\r\n        \"name\": \"blockedBy\",\r\n        \"owner_id\": \"example/governance-fixture#101\",\r\n        \"expected_total\": 0,\r\n        \"pages\": [\r\n          {\r\n            \"cursor_in\": null,\r\n            \"cursor_out\": null,\r\n            \"record_ids\": [],\r\n            \"has_next_page\": false\r\n          }\r\n        ],\r\n        \"complete\": true\r\n      },\r\n      {\r\n        \"name\": \"blocking\",\r\n        \"owner_id\": \"example/governance-fixture#101\",\r\n        \"expected_total\": 0,\r\n        \"pages\": [\r\n          {\r\n            \"cursor_in\": null,\r\n            \"cursor_out\": null,\r\n            \"record_ids\": [],\r\n            \"has_next_page\": false\r\n          }\r\n        ],\r\n        \"complete\": true\r\n      },\r\n      {\r\n        \"name\": \"closingPRReferences\",\r\n        \"owner_id\": \"example/governance-fixture#101\",\r\n        \"expected_total\": 0,\r\n        \"pages\": [\r\n          {\r\n            \"cursor_in\": null,\r\n            \"cursor_out\": null,\r\n            \"record_ids\": [],\r\n            \"has_next_page\": false\r\n          }\r\n        ],\r\n        \"complete\": true\r\n      },\r\n      {\r\n        \"name\": \"labels\",\r\n        \"owner_id\": \"example/governance-fixture#101\",\r\n        \"expected_total\": 1,\r\n        \"pages\": [\r\n          {\r\n            \"cursor_in\": null,\r\n            \"cursor_out\": \"fixture-L1\",\r\n            \"record_ids\": [\r\n              \"L1\"\r\n            ],\r\n            \"has_next_page\": false\r\n          }\r\n        ],\r\n        \"complete\": true\r\n      },\r\n      {\r\n        \"name\": \"assignees\",\r\n        \"owner_id\": \"example/governance-fixture#101\",\r\n        \"expected_total\": 1,\r\n        \"pages\": [\r\n          {\r\n            \"cursor_in\": null,\r\n            \"cursor_out\": null,\r\n            \"record_ids\": [\r\n              \"fixture-owner\"\r\n            ],\r\n            \"has_next_page\": false\r\n          }\r\n        ],\r\n        \"complete\": true\r\n      },\r\n      {\r\n        \"name\": \"pullRequests\",\r\n        \"owner_id\": \"example/governance-fixture\",\r\n        \"expected_total\": 1,\r\n        \"pages\": [\r\n          {\r\n            \"cursor_in\": null,\r\n            \"cursor_out\": null,\r\n            \"record_ids\": [\r\n              \"example/governance-fixture!201\"\r\n            ],\r\n            \"has_next_page\": false\r\n          }\r\n        ],\r\n        \"complete\": true\r\n      },\r\n      {\r\n        \"name\": \"closingIssuesReferences\",\r\n        \"owner_id\": \"example/governance-fixture!201\",\r\n        \"expected_total\": 0,\r\n        \"pages\": [\r\n          {\r\n            \"cursor_in\": null,\r\n            \"cursor_out\": null,\r\n            \"has_next_page\": false,\r\n            \"record_ids\": []\r\n          }\r\n        ],\r\n        \"complete\": true\r\n      }\r\n    ],\r\n    \"complete\": true\r\n  },\r\n  \"issues\": [\r\n    {\r\n      \"id\": \"example/governance-fixture#101\",\r\n      \"number\": 101,\r\n      \"url\": \"https://github.com/example/governance-fixture/issues/101\",\r\n      \"title\": \"Preserve an existing valid installation\",\r\n      \"body\": \"## Objective\\nPreserve an existing valid installation.\\n## Acceptance Criteria\\nAC1: Preserve the existing valid installation.\\n## Backplane Record\\nCode: CAP1.1; Kind: outcome; authority S1.\\n## Coverage and Satisfaction\\nAC1 maps to R1/S1; accepted evaluation EV1 at delivery B is SATISFIED.\\n\",\r\n      \"state\": \"OPEN\",\r\n      \"state_reason\": \"\",\r\n      \"issue_type\": {\r\n        \"id\": \"TYPE_FEATURE\",\r\n        \"name\": \"Feature\",\r\n        \"description\": \"Fixture native issue type\",\r\n        \"color\": \"GREEN\"\r\n      },\r\n      \"labels\": [\r\n        {\r\n          \"id\": \"L1\",\r\n          \"name\": \"backplane:review\",\r\n          \"description\": \"Awaiting closeout\",\r\n          \"color\": \"5319e7\"\r\n        }\r\n      ],\r\n      \"assignees\": [\r\n        \"fixture-owner\"\r\n      ],\r\n      \"milestone\": null,\r\n      \"updated_at\": \"2026-10-01T12:00:00Z\",\r\n      \"parent_id\": null,\r\n      \"child_ids\": [],\r\n      \"sub_issues_summary\": {\r\n        \"total\": 0,\r\n        \"completed\": 0,\r\n        \"percent_completed\": 0\r\n      },\r\n      \"blocked_by_ids\": [],\r\n      \"blocking_ids\": [],\r\n      \"closing_pr_ids\": [],\r\n      \"backplane_record\": {\r\n        \"code\": \"CAP1.1\",\r\n        \"namespace\": \"CAP1\",\r\n        \"kind\": \"outcome\",\r\n        \"authority_ids\": [\r\n          \"S1\"\r\n        ]\r\n      },\r\n      \"accepted_evaluation_ids\": [\r\n        \"EV1\"\r\n      ],\r\n      \"limitations\": []\r\n    }\r\n  ],\r\n  \"pull_requests\": [\r\n    {\r\n      \"id\": \"example/governance-fixture!201\",\r\n      \"number\": 201,\r\n      \"url\": \"https://github.com/example/governance-fixture/pull/201\",\r\n      \"title\": \"Preservation contribution\",\r\n      \"body\": \"Refs #101; contributes AC1 at S1.\",\r\n      \"state\": \"MERGED\",\r\n      \"base_ref\": \"main\",\r\n      \"head_ref\": \"fixture-preservation\",\r\n      \"merged_at\": \"2026-10-01T11:00:00Z\",\r\n      \"merge_commit\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\r\n      \"review_status\": \"accepted\",\r\n      \"closing_issue_ids\": [],\r\n      \"closure_intent\": \"contribution\",\r\n      \"updated_at\": \"2026-10-01T12:00:00Z\",\r\n      \"limitations\": []\r\n    }\r\n  ],\r\n  \"authorities\": [\r\n    {\r\n      \"id\": \"S1\",\r\n      \"kind\": \"specification\",\r\n      \"locator\": \"fixture:spec/S1\",\r\n      \"revision\": \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\",\r\n      \"content\": \"R1: Preserve an existing valid installation. AC1 implements R1.\",\r\n      \"availability\": \"available\",\r\n      \"approver\": null,\r\n      \"approved_scope\": null,\r\n      \"approval_ids\": [\r\n        \"A1\"\r\n      ],\r\n      \"limitations\": []\r\n    },\r\n    {\r\n      \"id\": \"A1\",\r\n      \"kind\": \"approval\",\r\n      \"locator\": \"fixture:approval/A1\",\r\n      \"revision\": \"2026-10-01T12:00:00Z\",\r\n      \"content\": \"Fixture approver approved R1 and AC1 at S1.\",\r\n      \"availability\": \"available\",\r\n      \"approver\": \"fixture-approver\",\r\n      \"approved_scope\": \"R1/AC1 at S1\",\r\n      \"approval_ids\": [],\r\n      \"limitations\": []\r\n    },\r\n    {\r\n      \"id\": \"A2\",\r\n      \"kind\": \"approval\",\r\n      \"locator\": \"fixture:review/A2\",\r\n      \"revision\": \"2026-10-01T12:00:00Z\",\r\n      \"content\": \"Fixture reviewer accepted AC1 at S1 and delivery B.\",\r\n      \"availability\": \"available\",\r\n      \"approver\": \"fixture-reviewer\",\r\n      \"approved_scope\": \"AC1 at S1/B\",\r\n      \"approval_ids\": [],\r\n      \"limitations\": []\r\n    }\r\n  ],\r\n  \"requirements\": [\r\n    {\r\n      \"id\": \"R1@S1\",\r\n      \"key\": \"R1\",\r\n      \"text\": \"Preserve an existing valid installation.\",\r\n      \"authority_id\": \"S1\",\r\n      \"authority_revision\": \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"\r\n    }\r\n  ],\r\n  \"criteria\": [\r\n    {\r\n      \"id\": \"example/governance-fixture#101:AC1\",\r\n      \"issue_id\": \"example/governance-fixture#101\",\r\n      \"key\": \"AC1\",\r\n      \"text\": \"Preserve the existing valid installation.\",\r\n      \"authority_id\": \"S1\",\r\n      \"authority_revision\": \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\",\r\n      \"delivery_commit\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\r\n      \"requirement_ids\": [\r\n        \"R1@S1\"\r\n      ]\r\n    }\r\n  ],\r\n  \"dispositions\": [],\r\n  \"coverage\": [\r\n    {\r\n      \"id\": \"COV1\",\r\n      \"issue_id\": \"example/governance-fixture#101\",\r\n      \"criterion_id\": \"example/governance-fixture#101:AC1\",\r\n      \"requirement_ids\": [\r\n        \"R1@S1\"\r\n      ],\r\n      \"contribution_issue_ids\": [\r\n        \"example/governance-fixture#101\"\r\n      ],\r\n      \"pr_ids\": [\r\n        \"example/governance-fixture!201\"\r\n      ],\r\n      \"combined_result_owner\": \"fixture-owner\",\r\n      \"scope\": \"The sole fixture criterion is covered by preservation contribution PR201.\"\r\n    }\r\n  ],\r\n  \"evaluations\": [\r\n    {\r\n      \"id\": \"EV1\",\r\n      \"criterion_id\": \"example/governance-fixture#101:AC1\",\r\n      \"requirement_ids\": [\r\n        \"R1@S1\"\r\n      ],\r\n      \"verified_commit\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\r\n      \"method\": \"Fixture preservation verification\",\r\n      \"observed_result\": \"PASS supplied by the invented fixture.\",\r\n      \"result\": \"SATISFIED\",\r\n      \"observed_at\": \"2026-10-01T12:00:00Z\",\r\n      \"evidence_ids\": [\r\n        \"E1\",\r\n        \"RV1\"\r\n      ],\r\n      \"review_approval_ids\": [\r\n        \"A2\"\r\n      ],\r\n      \"applicability\": \"current\",\r\n      \"remaining_contributions\": [],\r\n      \"limitations\": []\r\n    }\r\n  ],\r\n  \"evidence\": [\r\n    {\r\n      \"id\": \"E1\",\r\n      \"kind\": \"verification\",\r\n      \"locator\": \"fixture:verification/E1\",\r\n      \"revision\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\r\n      \"sha256\": null,\r\n      \"availability\": \"available\",\r\n      \"content\": \"Invented fixture result: AC1 passed preservation verification against S1 and B.\",\r\n      \"verified_commit\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\r\n      \"limitations\": []\r\n    },\r\n    {\r\n      \"id\": \"RV1\",\r\n      \"kind\": \"review\",\r\n      \"locator\": \"fixture:review/RV1\",\r\n      \"revision\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\r\n      \"sha256\": null,\r\n      \"availability\": \"available\",\r\n      \"content\": \"Invented fixture review accepted AC1 at S1/B.\",\r\n      \"verified_commit\": \"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\",\r\n      \"limitations\": []\r\n    }\r\n  ],\r\n  \"limitations\": []\r\n}\r\n",
    "kind": "other",
    "limitations": [
      "Exact local UTF-8 content and SHA256 retained; no integrated delivery identity established."
    ],
    "sha256": "a27981c537d850c991b3a389be276e5577356777bd6c149e4395f876798fd13b"
  },
  {
    "limitations": [
      "Independent spelling correction; no integrated acceptance."
    ],
    "availability": "available",
    "sha256": "4a9d3ecb83e0fa5a3c5c11e7c983d11f143159f69053b097d63d4657fb57cf3c",
    "id": "CASE-FILE:README.md",
    "kind": "other",
    "verified_commit": null,
    "revision": "4a9d3ecb83e0fa5a3c5c11e7c983d11f143159f69053b097d63d4657fb57cf3c",
    "locator": "README.md",
    "content": "This is the independent fixture note.\r\n"
  }
]
```

### limitations

```json
[
  "assignees and milestone not supplied; null denotes unknown.",
  "Accepted delivery evaluation not supplied; architecture local conflicts with approved remote.",
  "The historical example issue #101 is a different identity; its delivery B and accepted EV1 do not apply to case #105.",
  "Diagnostic candidate only; no acceptance/indexing commit, transaction installation or publication authorized.",
  "Repository/source commit aaaa and historical issue #101, PR201, EV1 at delivery bbbb are supplied invented example context, not observed current case delivery. Original checkpoint-input.json bytes remain unchanged.",
  "Referenced Backplane governance.md absent from selected bundle; full governance validation unavailable.",
  "Offline fixture; current real tracker eligibility unverified.",
  "Native label metadata and current case immutable source commit unavailable; declared cross-repository scope cannot be fully reconstructed.",
  "Current case repository identity unknown. Current issue uses its exact supplied native URL as stable namespaced ID; no repository identity inferred."
]
```
