# Approved-decision review control

Disposition: CHANGES REQUIRED; architectural alignment FAIL; applicable source-authority acceptance criterion UNSATISFIED. Do not accept or close as completed. Actual delivered architecture.json source_of_truth is remote. Applicable Current ADR-0001 edition1 explicitly approves local for this case, and approved spec.md/plan.md also require local. This is implementation drift against resolved architectural authority, not a missing architectural decision.

Required correction: change architecture.json source_of_truth from remote to local under a separately authorized correction operation, then inspect alignment and perform the project's applicable verification/review. This review request prohibits architecture/source edits, so the actual delivered input remains remote. Do not revise the ADR to bless the drift; no new ADR or repeated architectural approval is needed to implement the existing approved choice.

Exact approval: actual raw reviewed bytes SHA256 97409b6f43a4219f744210a9aa36a3d4ec4e1f2f8820a2f411b57d6cd5520b95 matches approval.txt's separately identified ADR-0001 edition1 response. Fictional fixture operator on 2026-11-15 explicitly says Approve ADR-0001 edition 1 as written, covering local authority only in this case architecture.json. Reviewed proposal, later administrative Current metadata and actual response were read independently. This is invented staged evidence, not real publisher approval.

Observed verification: supplied checks.json fixture_result=PASS; scope=JSON syntax only; no architectural approval or integrated acceptance established. Green syntax output does not verify architectural alignment or integrated acceptance. File inspection establishes the known source-authority mismatch. README spelling corrected independently and inspected. Accepted integration, target/delivery commit, accepted review and fresh integrated verification are unavailable: those separate completion gates remain UNKNOWN. No claim that the supplied check was rerun.

Release regrouping: release-grouping.txt moves unchanged work to a later minor release and expressly preserves design, scope and approved choice. It neither accepts the conflicting implementation nor authorizes publication. ADR identity/edition/decision date/approval remain unchanged: no release-driven revision, new ADR, retirement or automatic version cascade is justified. Recheck affected applicability; here the constraint still applies unchanged.

Native review/closeout route: managing-superpowers-backlog -> references/pr-completion.md -> architectural-decisions.md, consuming previously read governance, github-issue-contract.md and superpowers-binding.md. Same selected canonical Backplane source 2a9ef916fb9293b291e59f4259da59defa40495a. Architectural reference explicitly requires comparison despite green checks and independent release evolution. Project working policy docs/engineering/architectural-decisions.md and selected gzs-architectural-decisions procedure remain as previously loaded; no source or approval semantics changed.

Frozen issue104: OPEN/backplane:review, exactly one lifecycle label, updatedAt 2026-11-15T00:00:00Z, URL https://example.invalid/fixture/issues/104. Complete issue body and native relationships inspected: parent null, subIssues/blockedBy/blocking nodes=[] with totalCount=0, closing PR references [], issueType null. Approved plan consumes this exact issue URL/revision. Proposed disposition when separately authorized: review -> active for implementation correction, retaining review finding; no tracker mutation here. No parent/Project/checkpoint/closure operation performed or supported as complete. Retain workspace and evidence for correction; no cleanup or publication.

Changed files: README.md spelling only; created review-result.md. Every architecture, decision, reviewed proposal, approval, spec, plan, check, issue and release-grouping input retained byte-for-byte. Earlier controls, outputs and transcripts not modified. No new ADR, implementation correction, commit, network, installation, tracker or publication operation.

Protected input hash observations:
architecture.json SHA256 7e0f1422a198fc80ee75a66db782e9e67d1524771b74687f8ef2c6bf0ef4958e
checks.json SHA256 b5e1755037056a48c5d8c3b285d6ccb86fbe67846083497ef4e2a287213789a3
issue.json SHA256 583e215675e2645cbf31cfadd3d87df99069ecaa582dd25afd75b0fb3be2ec4c
plan.md SHA256 3ad91a3e23059a9eedc232f88e76a6ab307bfda325fcc38b9563f39aa187db77
README.md SHA256 fdab50684d5ade5a3015bcc9ff20b649cda6f19f8baebae6d8edca7cf24f15c6
release-grouping.txt SHA256 dee528e619cf0c22be245830f85bad60b2e1b90e40647f6053053302bdf7aa9a
spec.md SHA256 0a1b244b6a3ac54ffcb2575d1c63f184be12b8232a96fb2badc4e47b927be8ea
docs\decisions\ADR-0001-001-fixture-source-authority.md SHA256 0664738c3feca76e7fbae69e226bb333cc302535d7131b37196d0464c4b2d87c
docs\decisions\ADR-0001-001-reviewed.txt SHA256 97409b6f43a4219f744210a9aa36a3d4ec4e1f2f8820a2f411b57d6cd5520b95
docs\decisions\approval.txt SHA256 0a1ffb530d75c245dd42323236decb464e2cacd067817d0c5f0e0ca99572e413