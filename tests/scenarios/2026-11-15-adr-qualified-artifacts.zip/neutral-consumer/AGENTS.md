# Invented language-neutral consumer

Native Superpowers and Backplane are independently supplied in .agents/skills/.
This project owns its own ADR workflow and docs/decisions collection. Reuse a
retrievable applicable Current decision with its actual separate named-edition
approval and reviewed bytes; consequential new/material choices require separate
approval first. Continue independent already-authorized tasks. Source documents
are directly readable through their exact linked paths; discovery aliases are
Windows junctions. This project does not adopt a starter or require any supporting
skill bundle. Do not install tooling or read unrelated user/profile material.

An approved local task/plan selects setting architecture.json ready=true while
retaining the approved local source authority; independently correct README
spelling. The local design/plan is approved fictional fixture input. Architectural
approval is supplied separately under docs/decisions, not inferred from this task.
The existing native issue response is frozen in issue.json; use it without live
GitHub queries or mutations. Exact project verification is git diff --check plus
inspection of requested file values. No consumer language/runtime/framework is
required. Work only on the two local requested files; no new plans/worktrees,
commits, publication, source edits or remote actions. This is invented test input.
