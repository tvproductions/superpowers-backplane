This is the independent fixture note.
