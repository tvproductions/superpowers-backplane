# source-drift observed assessment

Replacement requested now: REFUSED by actual native capture/acceptance/recovery gates.

EADR-REVIEWED changed from f242185f2332885382a421b57d516e0db1900205 to b3b0c71f897bd265185baf2cfcc22269fc44d8f1; recheck explicitly changed. Current hash 7a6b8e8b32eb24ed65989a5e3fcf373eb9c1a410e9219fca7305e8d222aaf85e assigns writes to a remote service; approval remains bound to project-owned bytes 4d6375c792aefeb7aa8c61f22460d5cbc6b2dedf6f8759ed355202b9a30085dc. No accepted semantic reconciliation or replacement approval.

Prior receipt expected JSON a4aa1651edab56d412818258e039018b5bbbf1b4e399c54867f9e4d8b5c0c167; Markdown a94b29e122a8458bc8c2e7c501ddba9fd31d2196d03775ab4bc546872ee0f520. Actual before/after preserved JSON a4aa1651edab56d412818258e039018b5bbbf1b4e399c54867f9e4d8b5c0c167; Markdown a94b29e122a8458bc8c2e7c501ddba9fd31d2196d03775ab4bc546872ee0f520. Prior identity assertion: source-identical copy of actual locally accepted invented pair c129e97d2ed3cadcd7384858b1e880bcee6e2639. Candidate SHA256 0ca23a3d7ada8a20e9d5c1bfdc04a22af2e21c1790a453ef033c8e66e93531ae unchanged.

Actions: inspected candidate, prior receipt and actual outputs; wrote stale diagnostic pair retaining exact input bytes; independently corrected README. Typed Authority approval_ids and Evaluation evidence_ids/review_approval_ids resolve in correct collections; pointer existence cannot repair unavailable approval, wrong edition or changed content. Prior accepted bytes do not approve another decision. No output replaced or rolled back. Supplied receipt lacks full root/index/blob/mode/expected-HEAD guards, and no fixture-local acceptance history/commit authority supplied here.

Loaded native repository-checkpoint.md, checkpoint-format.md, checkpoint-state-template.md, architectural-decisions.md, github-issue-contract.md and exact linked governance.md SHA256 0702f984e007ab20095def7ed9967bfafeecdf5543ebf01ad5dfb59c40bae880. Architectural, local task, integrated acceptance and publication authorities remain distinct. No tracker/network/publication or canonical product change.
