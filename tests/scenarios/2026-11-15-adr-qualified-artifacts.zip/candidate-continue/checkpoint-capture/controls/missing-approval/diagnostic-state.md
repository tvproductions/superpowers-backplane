# Backplane checkpoint control diagnostic

Format: sp-bp-checkpoint/v1
Capture ID: invented-adr-capture-20261115-missing-approval-diagnostic
JSON SHA-256: 597f516e21cbe1e1b84137219838adb80509d7b8d0869463cddd5884919c8b76
Mode/status/origin: issues-only / partial / invented-fixture

AADR and EADR-APPROVAL unavailable/null for new ADR-0002 edition1 (remote-service ownership). Current metadata cannot approve it. S1/current administrative record cite old reviewed hash 4d6375... while actual ADR-0002 bytes hash eb38335805074af3b38beb668680b534020adb80a8676db3d0ed86bd0f8bceb9. No matching immutable ADR-0002 source object supplied.

Original source f242185f2332885382a421b57d516e0db1900205; delivery b3b0c71f897bd265185baf2cfcc22269fc44d8f1 remain distinct from absent acceptance commit. No output installed/recovered. Lossless rendering below retains all obligations, graph, authorities, evidence, limitations and original input bytes. This diagnostic is not an accepted pair.

~~~json
{
  "format": "sp-bp-checkpoint/v1",
  "capture": {
    "id": "invented-adr-capture-20261115-missing-approval-diagnostic",
    "started_at": "2026-11-15T22:00:00Z",
    "finished_at": "2026-11-15T22:18:23.593214Z",
    "mode": "issues-only",
    "status": "partial",
    "origin": "invented-fixture",
    "rechecks": [
      {
        "kind": "issue",
        "id": "example/governance-fixture#101",
        "initial_revision": "2026-10-01T12:00:00Z",
        "final_revision": "2026-10-01T12:00:00Z",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Fixture full body/native relationships unchanged."
      },
      {
        "kind": "graph",
        "id": "selected-native-graph",
        "initial_revision": "fixture-graph-1",
        "final_revision": "fixture-graph-1",
        "result": "unchanged",
        "approval_ids": [],
        "details": "All selected connections enumerated and compared."
      },
      {
        "kind": "authority",
        "id": "S1",
        "initial_revision": "f242185f2332885382a421b57d516e0db1900205",
        "final_revision": "f242185f2332885382a421b57d516e0db1900205",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Embedded fixture authority unchanged."
      },
      {
        "kind": "authority",
        "id": "A1",
        "initial_revision": "2026-10-01T12:00:00Z",
        "final_revision": "2026-10-01T12:00:00Z",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Embedded fixture authority unchanged."
      },
      {
        "kind": "authority",
        "id": "A2",
        "initial_revision": "2026-10-01T12:00:00Z",
        "final_revision": "2026-10-01T12:00:00Z",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Embedded fixture authority unchanged."
      },
      {
        "kind": "evidence",
        "id": "E1",
        "initial_revision": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
        "final_revision": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Embedded fixture evidence unchanged."
      },
      {
        "kind": "evidence",
        "id": "RV1",
        "initial_revision": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
        "final_revision": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Embedded fixture evidence unchanged."
      },
      {
        "kind": "delivery",
        "id": "example/governance-fixture#101",
        "initial_revision": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
        "final_revision": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Fixture current delivery B; source A identifies the capture context rather than the verified delivery."
      },
      {
        "kind": "evidence",
        "id": "EADR-REVIEWED",
        "initial_revision": "f242185f2332885382a421b57d516e0db1900205",
        "final_revision": "f242185f2332885382a421b57d516e0db1900205",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Invented available source bytes rechecked exactly; no real approval claim."
      },
      {
        "kind": "evidence",
        "id": "EADR-CURRENT",
        "initial_revision": "f242185f2332885382a421b57d516e0db1900205",
        "final_revision": "f242185f2332885382a421b57d516e0db1900205",
        "result": "unchanged",
        "approval_ids": [],
        "details": "Invented available source bytes rechecked exactly; no real approval claim."
      },
      {
        "kind": "evidence",
        "id": "EADR-APPROVAL",
        "initial_revision": "f242185f2332885382a421b57d516e0db1900205",
        "final_revision": null,
        "result": "unavailable",
        "approval_ids": [],
        "details": "Actual current approval null/unavailable despite original unchanged assertion; original input preserved."
      },
      {
        "kind": "authority",
        "id": "AADR",
        "initial_revision": "f242185f2332885382a421b57d516e0db1900205",
        "final_revision": null,
        "result": "unavailable",
        "approval_ids": [],
        "details": "Actual current approval null/unavailable despite original unchanged assertion; original input preserved."
      }
    ]
  },
  "repository": {
    "id": "example/governance-fixture",
    "url": "https://github.com/example/governance-fixture",
    "owner": "example",
    "name": "governance-fixture"
  },
  "project": null,
  "source": {
    "commit": "f242185f2332885382a421b57d516e0db1900205"
  },
  "scope": {
    "issue_ids": [
      "example/governance-fixture#101"
    ],
    "excluded_ids": [],
    "external_records": [],
    "collections": [
      {
        "name": "issues",
        "owner_id": "example/governance-fixture",
        "expected_total": 1,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [
              "example/governance-fixture#101"
            ],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "subIssues",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "blockedBy",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "blocking",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "closingPRReferences",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "labels",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 1,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": "fixture-L1",
            "record_ids": [
              "L1"
            ],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "assignees",
        "owner_id": "example/governance-fixture#101",
        "expected_total": 1,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [
              "fixture-owner"
            ],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "pullRequests",
        "owner_id": "example/governance-fixture",
        "expected_total": 1,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "record_ids": [
              "example/governance-fixture!201"
            ],
            "has_next_page": false
          }
        ],
        "complete": true
      },
      {
        "name": "closingIssuesReferences",
        "owner_id": "example/governance-fixture!201",
        "expected_total": 0,
        "pages": [
          {
            "cursor_in": null,
            "cursor_out": null,
            "has_next_page": false,
            "record_ids": []
          }
        ],
        "complete": true
      }
    ],
    "complete": true
  },
  "issues": [
    {
      "id": "example/governance-fixture#101",
      "number": 101,
      "url": "https://github.com/example/governance-fixture/issues/101",
      "title": "Preserve an existing valid installation",
      "body": "## Objective\nPreserve an existing valid installation.\n## Acceptance Criteria\nAC1: Preserve the existing valid installation.\n## Backplane Record\nCode: CAP1.1; Kind: outcome; authority S1.\n## Coverage and Satisfaction\nAC1 maps to R1/S1; accepted evaluation EV1 at delivery B is SATISFIED.\n",
      "state": "OPEN",
      "state_reason": "",
      "issue_type": {
        "id": "TYPE_FEATURE",
        "name": "Feature",
        "description": "Fixture native issue type",
        "color": "GREEN"
      },
      "labels": [
        {
          "id": "L1",
          "name": "backplane:review",
          "description": "Awaiting closeout",
          "color": "5319e7"
        }
      ],
      "assignees": [
        "fixture-owner"
      ],
      "milestone": null,
      "updated_at": "2026-10-01T12:00:00Z",
      "parent_id": null,
      "child_ids": [],
      "sub_issues_summary": {
        "total": 0,
        "completed": 0,
        "percent_completed": 0
      },
      "blocked_by_ids": [],
      "blocking_ids": [],
      "closing_pr_ids": [],
      "backplane_record": {
        "code": "CAP1.1",
        "namespace": "CAP1",
        "kind": "outcome",
        "authority_ids": [
          "S1"
        ]
      },
      "accepted_evaluation_ids": [
        "EV1"
      ],
      "limitations": []
    }
  ],
  "pull_requests": [
    {
      "id": "example/governance-fixture!201",
      "number": 201,
      "url": "https://github.com/example/governance-fixture/pull/201",
      "title": "Preservation contribution",
      "body": "Refs #101; contributes AC1 at S1.",
      "state": "MERGED",
      "base_ref": "main",
      "head_ref": "fixture-preservation",
      "merged_at": "2026-10-01T11:00:00Z",
      "merge_commit": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
      "review_status": "accepted",
      "closing_issue_ids": [],
      "closure_intent": "contribution",
      "updated_at": "2026-10-01T12:00:00Z",
      "limitations": []
    }
  ],
  "authorities": [
    {
      "id": "S1",
      "kind": "specification",
      "locator": "fixture:spec/S1",
      "revision": "f242185f2332885382a421b57d516e0db1900205",
      "content": "R1: Preserve an existing valid installation. AC1 implements R1. ADR-0002 edition 1 retains project installation-manifest authority and preservation of unrelated valid entries under R1/AC1. Immutable source f242185f2332885382a421b57d516e0db1900205:ADR-0002-001-retain-project-installation-authority.md; reviewed bytes EADR-REVIEWED SHA256 4d6375c792aefeb7aa8c61f22460d5cbc6b2dedf6f8759ed355202b9a30085dc, administrative Current record EADR-CURRENT, actual staged response EADR-APPROVAL and approval authority AADR.",
      "availability": "available",
      "approver": null,
      "approved_scope": null,
      "approval_ids": [
        "A1",
        "AADR"
      ],
      "limitations": []
    },
    {
      "id": "A1",
      "kind": "approval",
      "locator": "fixture:approval/A1",
      "revision": "2026-10-01T12:00:00Z",
      "content": "Fixture approver approved R1 and AC1 at S1.",
      "availability": "available",
      "approver": "fixture-approver",
      "approved_scope": "R1/AC1 at S1",
      "approval_ids": [],
      "limitations": []
    },
    {
      "id": "A2",
      "kind": "approval",
      "locator": "fixture:review/A2",
      "revision": "2026-10-01T12:00:00Z",
      "content": "Fixture reviewer accepted AC1 at S1 and delivery B.",
      "availability": "available",
      "approver": "fixture-reviewer",
      "approved_scope": "AC1 at S1/B",
      "approval_ids": [],
      "limitations": []
    },
    {
      "id": "AADR",
      "kind": "approval",
      "locator": "fixture:approval/approval.txt",
      "revision": "f242185f2332885382a421b57d516e0db1900205",
      "content": null,
      "availability": "unavailable",
      "approver": "fictional fixture operator",
      "approved_scope": "ADR-0002 edition 1 retains project installation-manifest authority and preservation of unrelated valid entries under R1/AC1.",
      "approval_ids": [],
      "limitations": [
        "Current exact-edition approval interaction unavailable."
      ]
    }
  ],
  "requirements": [
    {
      "id": "R1@S1",
      "key": "R1",
      "text": "Preserve an existing valid installation.",
      "authority_id": "S1",
      "authority_revision": "f242185f2332885382a421b57d516e0db1900205"
    }
  ],
  "criteria": [
    {
      "id": "example/governance-fixture#101:AC1",
      "issue_id": "example/governance-fixture#101",
      "key": "AC1",
      "text": "Preserve the existing valid installation.",
      "authority_id": "S1",
      "authority_revision": "f242185f2332885382a421b57d516e0db1900205",
      "delivery_commit": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
      "requirement_ids": [
        "R1@S1"
      ]
    }
  ],
  "dispositions": [],
  "coverage": [
    {
      "id": "COV1",
      "issue_id": "example/governance-fixture#101",
      "criterion_id": "example/governance-fixture#101:AC1",
      "requirement_ids": [
        "R1@S1"
      ],
      "contribution_issue_ids": [
        "example/governance-fixture#101"
      ],
      "pr_ids": [
        "example/governance-fixture!201"
      ],
      "combined_result_owner": "fixture-owner",
      "scope": "The sole fixture criterion is covered by preservation contribution PR201."
    }
  ],
  "evaluations": [
    {
      "id": "EV1",
      "criterion_id": "example/governance-fixture#101:AC1",
      "requirement_ids": [
        "R1@S1"
      ],
      "verified_commit": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
      "method": "Fixture preservation verification; ADR edition/content/approval and local manifest ownership alignment checked in invented fixture",
      "observed_result": "Original PASS/SATISFIED claim is unsupported after actual authority/source reconciliation.",
      "result": "UNKNOWN",
      "observed_at": "2026-10-01T12:00:00Z",
      "evidence_ids": [
        "E1",
        "RV1",
        "EADR-REVIEWED",
        "EADR-CURRENT",
        "EADR-APPROVAL"
      ],
      "review_approval_ids": [
        "A2"
      ],
      "applicability": "unreconciled",
      "remaining_contributions": [
        "Resolve exact-edition approval/content/source applicability; revalidate before replacement."
      ],
      "limitations": [
        "AADR and EADR-APPROVAL unavailable/null for new ADR-0002 edition1 (remote-service ownership). Current metadata cannot approve it. S1/current administrative record cite old reviewed hash 4d6375... while actual ADR-0002 bytes hash eb38335805074af3b38beb668680b534020adb80a8676db3d0ed86bd0f8bceb9. No matching immutable ADR-0002 source object supplied."
      ]
    }
  ],
  "evidence": [
    {
      "id": "E1",
      "kind": "verification",
      "locator": "fixture:verification/E1",
      "revision": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
      "sha256": null,
      "availability": "available",
      "content": "Invented fixture result: AC1 passed preservation verification against S1 and B.",
      "verified_commit": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
      "limitations": []
    },
    {
      "id": "RV1",
      "kind": "review",
      "locator": "fixture:review/RV1",
      "revision": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
      "sha256": null,
      "availability": "available",
      "content": "Invented fixture review accepted AC1 at S1/B.",
      "verified_commit": "b3b0c71f897bd265185baf2cfcc22269fc44d8f1",
      "limitations": []
    },
    {
      "id": "EADR-REVIEWED",
      "kind": "other",
      "locator": "fixture:adr/ADR-0002-001-reviewed.txt",
      "revision": "f242185f2332885382a421b57d516e0db1900205",
      "sha256": "eb38335805074af3b38beb668680b534020adb80a8676db3d0ed86bd0f8bceb9",
      "availability": "available",
      "content": "# Proposed ADR-0002 edition 1: retain project installation authority\n\nThe remote service owns its installation manifest and preserves unrelated existing valid entries. This constrains fixture requirement R1 and criterion AC1. Alternatives: project ownership or a remote service owning writes. Project ownership preserves the existing product contract. No remote operation, runtime, approval store or publication is introduced.\n",
      "verified_commit": null,
      "limitations": []
    },
    {
      "id": "EADR-CURRENT",
      "kind": "other",
      "locator": "fixture:adr/ADR-0002-001-retain-project-installation-authority.md",
      "revision": "f242185f2332885382a421b57d516e0db1900205",
      "sha256": "221fc56a28326225c2bef48c1cc1c93c8fb847c11c2d9a9d52c2e38ba5b5ec87",
      "availability": "available",
      "content": "---\nid: ADR-0002\ntitle: Retain project installation authority\nrevision: 1\nstate: Current\ndecision_date: 2026-11-15\nrevision_date: 2026-11-15\napproved_by: fictional fixture operator\napproved_revision: 1\napproval_ref: approval.txt\n---\n\n# Proposed ADR-0002 edition 1: retain project installation authority\n\nThe remote service owns its installation manifest and preserves unrelated existing valid entries. This constrains fixture requirement R1 and criterion AC1. Alternatives: project ownership or a remote service owning writes. Project ownership preserves the existing product contract. No remote operation, runtime, approval store or publication is introduced.\n\nAdministrative approval capture only; decision unchanged. Original reviewed proposal is ADR-0002-001-reviewed.txt at SHA256 4d6375c792aefeb7aa8c61f22460d5cbc6b2dedf6f8759ed355202b9a30085dc. Fictional input, not actual publisher approval.\n",
      "verified_commit": null,
      "limitations": []
    },
    {
      "id": "EADR-APPROVAL",
      "kind": "approval",
      "locator": "fixture:adr/approval.txt",
      "revision": "f242185f2332885382a421b57d516e0db1900205",
      "sha256": null,
      "availability": "unavailable",
      "content": null,
      "verified_commit": null,
      "limitations": [
        "Current required ADR-0002 edition-1 interaction is unavailable; prior pair records another decision."
      ]
    },
    {
      "limitations": [
        "Original claims preserved as input, not accepted current verdicts."
      ],
      "kind": "other",
      "id": "CONTROL-RAW-CANDIDATE",
      "locator": "candidate-input.json",
      "verified_commit": null,
      "availability": "available",
      "revision": "da4af3682042175fabacb799fe72b8eb7952dd7bc4710d4c4a459c66f9233f0a",
      "sha256": "da4af3682042175fabacb799fe72b8eb7952dd7bc4710d4c4a459c66f9233f0a",
      "content": "Original exact bytes base64: ewogICJmb3JtYXQiOiAic3AtYnAtY2hlY2twb2ludC92MSIsCiAgImNhcHR1cmUiOiB7CiAgICAiaWQiOiAiaW52ZW50ZWQtYWRyLWNhcHR1cmUtMjAyNjExMTUiLAogICAgInN0YXJ0ZWRfYXQiOiAiMjAyNi0xMS0xNVQyMjowMDowMFoiLAogICAgImZpbmlzaGVkX2F0IjogIjIwMjYtMTEtMTVUMjI6MTg6MjMuNTkzMjE0WiIsCiAgICAibW9kZSI6ICJpc3N1ZXMtb25seSIsCiAgICAic3RhdHVzIjogImNvbXBsZXRlIiwKICAgICJvcmlnaW4iOiAiaW52ZW50ZWQtZml4dHVyZSIsCiAgICAicmVjaGVja3MiOiBbCiAgICAgIHsKICAgICAgICAia2luZCI6ICJpc3N1ZSIsCiAgICAgICAgImlkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICAgImluaXRpYWxfcmV2aXNpb24iOiAiMjAyNi0xMC0wMVQxMjowMDowMFoiLAogICAgICAgICJmaW5hbF9yZXZpc2lvbiI6ICIyMDI2LTEwLTAxVDEyOjAwOjAwWiIsCiAgICAgICAgInJlc3VsdCI6ICJ1bmNoYW5nZWQiLAogICAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgICAiZGV0YWlscyI6ICJGaXh0dXJlIGZ1bGwgYm9keS9uYXRpdmUgcmVsYXRpb25zaGlwcyB1bmNoYW5nZWQuIgogICAgICB9LAogICAgICB7CiAgICAgICAgImtpbmQiOiAiZ3JhcGgiLAogICAgICAgICJpZCI6ICJzZWxlY3RlZC1uYXRpdmUtZ3JhcGgiLAogICAgICAgICJpbml0aWFsX3JldmlzaW9uIjogImZpeHR1cmUtZ3JhcGgtMSIsCiAgICAgICAgImZpbmFsX3JldmlzaW9uIjogImZpeHR1cmUtZ3JhcGgtMSIsCiAgICAgICAgInJlc3VsdCI6ICJ1bmNoYW5nZWQiLAogICAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgICAiZGV0YWlscyI6ICJBbGwgc2VsZWN0ZWQgY29ubmVjdGlvbnMgZW51bWVyYXRlZCBhbmQgY29tcGFyZWQuIgogICAgICB9LAogICAgICB7CiAgICAgICAgImtpbmQiOiAiYXV0aG9yaXR5IiwKICAgICAgICAiaWQiOiAiUzEiLAogICAgICAgICJpbml0aWFsX3JldmlzaW9uIjogImYyNDIxODVmMjMzMjg4NTM4MmE0MjFiNTdkNTE2ZTBkYjE5MDAyMDUiLAogICAgICAgICJmaW5hbF9yZXZpc2lvbiI6ICJmMjQyMTg1ZjIzMzI4ODUzODJhNDIxYjU3ZDUxNmUwZGIxOTAwMjA1IiwKICAgICAgICAicmVzdWx0IjogInVuY2hhbmdlZCIsCiAgICAgICAgImFwcHJvdmFsX2lkcyI6IFtdLAogICAgICAgICJkZXRhaWxzIjogIkVtYmVkZGVkIGZpeHR1cmUgYXV0aG9yaXR5IHVuY2hhbmdlZC4iCiAgICAgIH0sCiAgICAgIHsKICAgICAgICAia2luZCI6ICJhdXRob3JpdHkiLAogICAgICAgICJpZCI6ICJBMSIsCiAgICAgICAgImluaXRpYWxfcmV2aXNpb24iOiAiMjAyNi0xMC0wMVQxMjowMDowMFoiLAogICAgICAgICJmaW5hbF9yZXZpc2lvbiI6ICIyMDI2LTEwLTAxVDEyOjAwOjAwWiIsCiAgICAgICAgInJlc3VsdCI6ICJ1bmNoYW5nZWQiLAogICAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgICAiZGV0YWlscyI6ICJFbWJlZGRlZCBmaXh0dXJlIGF1dGhvcml0eSB1bmNoYW5nZWQuIgogICAgICB9LAogICAgICB7CiAgICAgICAgImtpbmQiOiAiYXV0aG9yaXR5IiwKICAgICAgICAiaWQiOiAiQTIiLAogICAgICAgICJpbml0aWFsX3JldmlzaW9uIjogIjIwMjYtMTAtMDFUMTI6MDA6MDBaIiwKICAgICAgICAiZmluYWxfcmV2aXNpb24iOiAiMjAyNi0xMC0wMVQxMjowMDowMFoiLAogICAgICAgICJyZXN1bHQiOiAidW5jaGFuZ2VkIiwKICAgICAgICAiYXBwcm92YWxfaWRzIjogW10sCiAgICAgICAgImRldGFpbHMiOiAiRW1iZWRkZWQgZml4dHVyZSBhdXRob3JpdHkgdW5jaGFuZ2VkLiIKICAgICAgfSwKICAgICAgewogICAgICAgICJraW5kIjogImV2aWRlbmNlIiwKICAgICAgICAiaWQiOiAiRTEiLAogICAgICAgICJpbml0aWFsX3JldmlzaW9uIjogImIzYjBjNzFmODk3YmQyNjUxODViYWYyY2ZjYzIyMjY5ZmM0NGQ4ZjEiLAogICAgICAgICJmaW5hbF9yZXZpc2lvbiI6ICJiM2IwYzcxZjg5N2JkMjY1MTg1YmFmMmNmY2MyMjI2OWZjNDRkOGYxIiwKICAgICAgICAicmVzdWx0IjogInVuY2hhbmdlZCIsCiAgICAgICAgImFwcHJvdmFsX2lkcyI6IFtdLAogICAgICAgICJkZXRhaWxzIjogIkVtYmVkZGVkIGZpeHR1cmUgZXZpZGVuY2UgdW5jaGFuZ2VkLiIKICAgICAgfSwKICAgICAgewogICAgICAgICJraW5kIjogImV2aWRlbmNlIiwKICAgICAgICAiaWQiOiAiUlYxIiwKICAgICAgICAiaW5pdGlhbF9yZXZpc2lvbiI6ICJiM2IwYzcxZjg5N2JkMjY1MTg1YmFmMmNmY2MyMjI2OWZjNDRkOGYxIiwKICAgICAgICAiZmluYWxfcmV2aXNpb24iOiAiYjNiMGM3MWY4OTdiZDI2NTE4NWJhZjJjZmNjMjIyNjlmYzQ0ZDhmMSIsCiAgICAgICAgInJlc3VsdCI6ICJ1bmNoYW5nZWQiLAogICAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgICAiZGV0YWlscyI6ICJFbWJlZGRlZCBmaXh0dXJlIGV2aWRlbmNlIHVuY2hhbmdlZC4iCiAgICAgIH0sCiAgICAgIHsKICAgICAgICAia2luZCI6ICJkZWxpdmVyeSIsCiAgICAgICAgImlkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICAgImluaXRpYWxfcmV2aXNpb24iOiAiYjNiMGM3MWY4OTdiZDI2NTE4NWJhZjJjZmNjMjIyNjlmYzQ0ZDhmMSIsCiAgICAgICAgImZpbmFsX3JldmlzaW9uIjogImIzYjBjNzFmODk3YmQyNjUxODViYWYyY2ZjYzIyMjY5ZmM0NGQ4ZjEiLAogICAgICAgICJyZXN1bHQiOiAidW5jaGFuZ2VkIiwKICAgICAgICAiYXBwcm92YWxfaWRzIjogW10sCiAgICAgICAgImRldGFpbHMiOiAiRml4dHVyZSBjdXJyZW50IGRlbGl2ZXJ5IEI7IHNvdXJjZSBBIGlkZW50aWZpZXMgdGhlIGNhcHR1cmUgY29udGV4dCByYXRoZXIgdGhhbiB0aGUgdmVyaWZpZWQgZGVsaXZlcnkuIgogICAgICB9LAogICAgICB7CiAgICAgICAgImtpbmQiOiAiZXZpZGVuY2UiLAogICAgICAgICJpZCI6ICJFQURSLVJFVklFV0VEIiwKICAgICAgICAiaW5pdGlhbF9yZXZpc2lvbiI6ICJmMjQyMTg1ZjIzMzI4ODUzODJhNDIxYjU3ZDUxNmUwZGIxOTAwMjA1IiwKICAgICAgICAiZmluYWxfcmV2aXNpb24iOiAiZjI0MjE4NWYyMzMyODg1MzgyYTQyMWI1N2Q1MTZlMGRiMTkwMDIwNSIsCiAgICAgICAgInJlc3VsdCI6ICJ1bmNoYW5nZWQiLAogICAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgICAiZGV0YWlscyI6ICJJbnZlbnRlZCBhdmFpbGFibGUgc291cmNlIGJ5dGVzIHJlY2hlY2tlZCBleGFjdGx5OyBubyByZWFsIGFwcHJvdmFsIGNsYWltLiIKICAgICAgfSwKICAgICAgewogICAgICAgICJraW5kIjogImV2aWRlbmNlIiwKICAgICAgICAiaWQiOiAiRUFEUi1DVVJSRU5UIiwKICAgICAgICAiaW5pdGlhbF9yZXZpc2lvbiI6ICJmMjQyMTg1ZjIzMzI4ODUzODJhNDIxYjU3ZDUxNmUwZGIxOTAwMjA1IiwKICAgICAgICAiZmluYWxfcmV2aXNpb24iOiAiZjI0MjE4NWYyMzMyODg1MzgyYTQyMWI1N2Q1MTZlMGRiMTkwMDIwNSIsCiAgICAgICAgInJlc3VsdCI6ICJ1bmNoYW5nZWQiLAogICAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgICAiZGV0YWlscyI6ICJJbnZlbnRlZCBhdmFpbGFibGUgc291cmNlIGJ5dGVzIHJlY2hlY2tlZCBleGFjdGx5OyBubyByZWFsIGFwcHJvdmFsIGNsYWltLiIKICAgICAgfSwKICAgICAgewogICAgICAgICJraW5kIjogImV2aWRlbmNlIiwKICAgICAgICAiaWQiOiAiRUFEUi1BUFBST1ZBTCIsCiAgICAgICAgImluaXRpYWxfcmV2aXNpb24iOiAiZjI0MjE4NWYyMzMyODg1MzgyYTQyMWI1N2Q1MTZlMGRiMTkwMDIwNSIsCiAgICAgICAgImZpbmFsX3JldmlzaW9uIjogImYyNDIxODVmMjMzMjg4NTM4MmE0MjFiNTdkNTE2ZTBkYjE5MDAyMDUiLAogICAgICAgICJyZXN1bHQiOiAidW5jaGFuZ2VkIiwKICAgICAgICAiYXBwcm92YWxfaWRzIjogW10sCiAgICAgICAgImRldGFpbHMiOiAiSW52ZW50ZWQgYXZhaWxhYmxlIHNvdXJjZSBieXRlcyByZWNoZWNrZWQgZXhhY3RseTsgbm8gcmVhbCBhcHByb3ZhbCBjbGFpbS4iCiAgICAgIH0sCiAgICAgIHsKICAgICAgICAia2luZCI6ICJhdXRob3JpdHkiLAogICAgICAgICJpZCI6ICJBQURSIiwKICAgICAgICAiaW5pdGlhbF9yZXZpc2lvbiI6ICJmMjQyMTg1ZjIzMzI4ODUzODJhNDIxYjU3ZDUxNmUwZGIxOTAwMjA1IiwKICAgICAgICAiZmluYWxfcmV2aXNpb24iOiAiZjI0MjE4NWYyMzMyODg1MzgyYTQyMWI1N2Q1MTZlMGRiMTkwMDIwNSIsCiAgICAgICAgInJlc3VsdCI6ICJ1bmNoYW5nZWQiLAogICAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgICAiZGV0YWlscyI6ICJFeGFjdCBpbnZlbnRlZCBlZGl0aW9uLTEgaW50ZXJhY3Rpb24vY29udGVudCByZWNoZWNrZWQ7IGRpc3RpbmN0IGZyb20gcmV2aWV3IGFwcHJvdmFsIEEyLiIKICAgICAgfQogICAgXQogIH0sCiAgInJlcG9zaXRvcnkiOiB7CiAgICAiaWQiOiAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUiLAogICAgInVybCI6ICJodHRwczovL2dpdGh1Yi5jb20vZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUiLAogICAgIm93bmVyIjogImV4YW1wbGUiLAogICAgIm5hbWUiOiAiZ292ZXJuYW5jZS1maXh0dXJlIgogIH0sCiAgInByb2plY3QiOiBudWxsLAogICJzb3VyY2UiOiB7CiAgICAiY29tbWl0IjogImYyNDIxODVmMjMzMjg4NTM4MmE0MjFiNTdkNTE2ZTBkYjE5MDAyMDUiCiAgfSwKICAic2NvcGUiOiB7CiAgICAiaXNzdWVfaWRzIjogWwogICAgICAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUjMTAxIgogICAgXSwKICAgICJleGNsdWRlZF9pZHMiOiBbXSwKICAgICJleHRlcm5hbF9yZWNvcmRzIjogW10sCiAgICAiY29sbGVjdGlvbnMiOiBbCiAgICAgIHsKICAgICAgICAibmFtZSI6ICJpc3N1ZXMiLAogICAgICAgICJvd25lcl9pZCI6ICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMSwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6IG51bGwsCiAgICAgICAgICAgICJyZWNvcmRfaWRzIjogWwogICAgICAgICAgICAgICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDEiCiAgICAgICAgICAgIF0sCiAgICAgICAgICAgICJoYXNfbmV4dF9wYWdlIjogZmFsc2UKICAgICAgICAgIH0KICAgICAgICBdLAogICAgICAgICJjb21wbGV0ZSI6IHRydWUKICAgICAgfSwKICAgICAgewogICAgICAgICJuYW1lIjogInN1Yklzc3VlcyIsCiAgICAgICAgIm93bmVyX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMCwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6IG51bGwsCiAgICAgICAgICAgICJyZWNvcmRfaWRzIjogW10sCiAgICAgICAgICAgICJoYXNfbmV4dF9wYWdlIjogZmFsc2UKICAgICAgICAgIH0KICAgICAgICBdLAogICAgICAgICJjb21wbGV0ZSI6IHRydWUKICAgICAgfSwKICAgICAgewogICAgICAgICJuYW1lIjogImJsb2NrZWRCeSIsCiAgICAgICAgIm93bmVyX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMCwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6IG51bGwsCiAgICAgICAgICAgICJyZWNvcmRfaWRzIjogW10sCiAgICAgICAgICAgICJoYXNfbmV4dF9wYWdlIjogZmFsc2UKICAgICAgICAgIH0KICAgICAgICBdLAogICAgICAgICJjb21wbGV0ZSI6IHRydWUKICAgICAgfSwKICAgICAgewogICAgICAgICJuYW1lIjogImJsb2NraW5nIiwKICAgICAgICAib3duZXJfaWQiOiAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUjMTAxIiwKICAgICAgICAiZXhwZWN0ZWRfdG90YWwiOiAwLAogICAgICAgICJwYWdlcyI6IFsKICAgICAgICAgIHsKICAgICAgICAgICAgImN1cnNvcl9pbiI6IG51bGwsCiAgICAgICAgICAgICJjdXJzb3Jfb3V0IjogbnVsbCwKICAgICAgICAgICAgInJlY29yZF9pZHMiOiBbXSwKICAgICAgICAgICAgImhhc19uZXh0X3BhZ2UiOiBmYWxzZQogICAgICAgICAgfQogICAgICAgIF0sCiAgICAgICAgImNvbXBsZXRlIjogdHJ1ZQogICAgICB9LAogICAgICB7CiAgICAgICAgIm5hbWUiOiAiY2xvc2luZ1BSUmVmZXJlbmNlcyIsCiAgICAgICAgIm93bmVyX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMCwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6IG51bGwsCiAgICAgICAgICAgICJyZWNvcmRfaWRzIjogW10sCiAgICAgICAgICAgICJoYXNfbmV4dF9wYWdlIjogZmFsc2UKICAgICAgICAgIH0KICAgICAgICBdLAogICAgICAgICJjb21wbGV0ZSI6IHRydWUKICAgICAgfSwKICAgICAgewogICAgICAgICJuYW1lIjogImxhYmVscyIsCiAgICAgICAgIm93bmVyX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMSwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6ICJmaXh0dXJlLUwxIiwKICAgICAgICAgICAgInJlY29yZF9pZHMiOiBbCiAgICAgICAgICAgICAgIkwxIgogICAgICAgICAgICBdLAogICAgICAgICAgICAiaGFzX25leHRfcGFnZSI6IGZhbHNlCiAgICAgICAgICB9CiAgICAgICAgXSwKICAgICAgICAiY29tcGxldGUiOiB0cnVlCiAgICAgIH0sCiAgICAgIHsKICAgICAgICAibmFtZSI6ICJhc3NpZ25lZXMiLAogICAgICAgICJvd25lcl9pZCI6ICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDEiLAogICAgICAgICJleHBlY3RlZF90b3RhbCI6IDEsCiAgICAgICAgInBhZ2VzIjogWwogICAgICAgICAgewogICAgICAgICAgICAiY3Vyc29yX2luIjogbnVsbCwKICAgICAgICAgICAgImN1cnNvcl9vdXQiOiBudWxsLAogICAgICAgICAgICAicmVjb3JkX2lkcyI6IFsKICAgICAgICAgICAgICAiZml4dHVyZS1vd25lciIKICAgICAgICAgICAgXSwKICAgICAgICAgICAgImhhc19uZXh0X3BhZ2UiOiBmYWxzZQogICAgICAgICAgfQogICAgICAgIF0sCiAgICAgICAgImNvbXBsZXRlIjogdHJ1ZQogICAgICB9LAogICAgICB7CiAgICAgICAgIm5hbWUiOiAicHVsbFJlcXVlc3RzIiwKICAgICAgICAib3duZXJfaWQiOiAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUiLAogICAgICAgICJleHBlY3RlZF90b3RhbCI6IDEsCiAgICAgICAgInBhZ2VzIjogWwogICAgICAgICAgewogICAgICAgICAgICAiY3Vyc29yX2luIjogbnVsbCwKICAgICAgICAgICAgImN1cnNvcl9vdXQiOiBudWxsLAogICAgICAgICAgICAicmVjb3JkX2lkcyI6IFsKICAgICAgICAgICAgICAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUhMjAxIgogICAgICAgICAgICBdLAogICAgICAgICAgICAiaGFzX25leHRfcGFnZSI6IGZhbHNlCiAgICAgICAgICB9CiAgICAgICAgXSwKICAgICAgICAiY29tcGxldGUiOiB0cnVlCiAgICAgIH0sCiAgICAgIHsKICAgICAgICAibmFtZSI6ICJjbG9zaW5nSXNzdWVzUmVmZXJlbmNlcyIsCiAgICAgICAgIm93bmVyX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlITIwMSIsCiAgICAgICAgImV4cGVjdGVkX3RvdGFsIjogMCwKICAgICAgICAicGFnZXMiOiBbCiAgICAgICAgICB7CiAgICAgICAgICAgICJjdXJzb3JfaW4iOiBudWxsLAogICAgICAgICAgICAiY3Vyc29yX291dCI6IG51bGwsCiAgICAgICAgICAgICJoYXNfbmV4dF9wYWdlIjogZmFsc2UsCiAgICAgICAgICAgICJyZWNvcmRfaWRzIjogW10KICAgICAgICAgIH0KICAgICAgICBdLAogICAgICAgICJjb21wbGV0ZSI6IHRydWUKICAgICAgfQogICAgXSwKICAgICJjb21wbGV0ZSI6IHRydWUKICB9LAogICJpc3N1ZXMiOiBbCiAgICB7CiAgICAgICJpZCI6ICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDEiLAogICAgICAibnVtYmVyIjogMTAxLAogICAgICAidXJsIjogImh0dHBzOi8vZ2l0aHViLmNvbS9leGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZS9pc3N1ZXMvMTAxIiwKICAgICAgInRpdGxlIjogIlByZXNlcnZlIGFuIGV4aXN0aW5nIHZhbGlkIGluc3RhbGxhdGlvbiIsCiAgICAgICJib2R5IjogIiMjIE9iamVjdGl2ZVxuUHJlc2VydmUgYW4gZXhpc3RpbmcgdmFsaWQgaW5zdGFsbGF0aW9uLlxuIyMgQWNjZXB0YW5jZSBDcml0ZXJpYVxuQUMxOiBQcmVzZXJ2ZSB0aGUgZXhpc3RpbmcgdmFsaWQgaW5zdGFsbGF0aW9uLlxuIyMgQmFja3BsYW5lIFJlY29yZFxuQ29kZTogQ0FQMS4xOyBLaW5kOiBvdXRjb21lOyBhdXRob3JpdHkgUzEuXG4jIyBDb3ZlcmFnZSBhbmQgU2F0aXNmYWN0aW9uXG5BQzEgbWFwcyB0byBSMS9TMTsgYWNjZXB0ZWQgZXZhbHVhdGlvbiBFVjEgYXQgZGVsaXZlcnkgQiBpcyBTQVRJU0ZJRUQuXG4iLAogICAgICAic3RhdGUiOiAiT1BFTiIsCiAgICAgICJzdGF0ZV9yZWFzb24iOiAiIiwKICAgICAgImlzc3VlX3R5cGUiOiB7CiAgICAgICAgImlkIjogIlRZUEVfRkVBVFVSRSIsCiAgICAgICAgIm5hbWUiOiAiRmVhdHVyZSIsCiAgICAgICAgImRlc2NyaXB0aW9uIjogIkZpeHR1cmUgbmF0aXZlIGlzc3VlIHR5cGUiLAogICAgICAgICJjb2xvciI6ICJHUkVFTiIKICAgICAgfSwKICAgICAgImxhYmVscyI6IFsKICAgICAgICB7CiAgICAgICAgICAiaWQiOiAiTDEiLAogICAgICAgICAgIm5hbWUiOiAiYmFja3BsYW5lOnJldmlldyIsCiAgICAgICAgICAiZGVzY3JpcHRpb24iOiAiQXdhaXRpbmcgY2xvc2VvdXQiLAogICAgICAgICAgImNvbG9yIjogIjUzMTllNyIKICAgICAgICB9CiAgICAgIF0sCiAgICAgICJhc3NpZ25lZXMiOiBbCiAgICAgICAgImZpeHR1cmUtb3duZXIiCiAgICAgIF0sCiAgICAgICJtaWxlc3RvbmUiOiBudWxsLAogICAgICAidXBkYXRlZF9hdCI6ICIyMDI2LTEwLTAxVDEyOjAwOjAwWiIsCiAgICAgICJwYXJlbnRfaWQiOiBudWxsLAogICAgICAiY2hpbGRfaWRzIjogW10sCiAgICAgICJzdWJfaXNzdWVzX3N1bW1hcnkiOiB7CiAgICAgICAgInRvdGFsIjogMCwKICAgICAgICAiY29tcGxldGVkIjogMCwKICAgICAgICAicGVyY2VudF9jb21wbGV0ZWQiOiAwCiAgICAgIH0sCiAgICAgICJibG9ja2VkX2J5X2lkcyI6IFtdLAogICAgICAiYmxvY2tpbmdfaWRzIjogW10sCiAgICAgICJjbG9zaW5nX3ByX2lkcyI6IFtdLAogICAgICAiYmFja3BsYW5lX3JlY29yZCI6IHsKICAgICAgICAiY29kZSI6ICJDQVAxLjEiLAogICAgICAgICJuYW1lc3BhY2UiOiAiQ0FQMSIsCiAgICAgICAgImtpbmQiOiAib3V0Y29tZSIsCiAgICAgICAgImF1dGhvcml0eV9pZHMiOiBbCiAgICAgICAgICAiUzEiCiAgICAgICAgXQogICAgICB9LAogICAgICAiYWNjZXB0ZWRfZXZhbHVhdGlvbl9pZHMiOiBbCiAgICAgICAgIkVWMSIKICAgICAgXSwKICAgICAgImxpbWl0YXRpb25zIjogW10KICAgIH0KICBdLAogICJwdWxsX3JlcXVlc3RzIjogWwogICAgewogICAgICAiaWQiOiAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUhMjAxIiwKICAgICAgIm51bWJlciI6IDIwMSwKICAgICAgInVybCI6ICJodHRwczovL2dpdGh1Yi5jb20vZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUvcHVsbC8yMDEiLAogICAgICAidGl0bGUiOiAiUHJlc2VydmF0aW9uIGNvbnRyaWJ1dGlvbiIsCiAgICAgICJib2R5IjogIlJlZnMgIzEwMTsgY29udHJpYnV0ZXMgQUMxIGF0IFMxLiIsCiAgICAgICJzdGF0ZSI6ICJNRVJHRUQiLAogICAgICAiYmFzZV9yZWYiOiAibWFpbiIsCiAgICAgICJoZWFkX3JlZiI6ICJmaXh0dXJlLXByZXNlcnZhdGlvbiIsCiAgICAgICJtZXJnZWRfYXQiOiAiMjAyNi0xMC0wMVQxMTowMDowMFoiLAogICAgICAibWVyZ2VfY29tbWl0IjogImIzYjBjNzFmODk3YmQyNjUxODViYWYyY2ZjYzIyMjY5ZmM0NGQ4ZjEiLAogICAgICAicmV2aWV3X3N0YXR1cyI6ICJhY2NlcHRlZCIsCiAgICAgICJjbG9zaW5nX2lzc3VlX2lkcyI6IFtdLAogICAgICAiY2xvc3VyZV9pbnRlbnQiOiAiY29udHJpYnV0aW9uIiwKICAgICAgInVwZGF0ZWRfYXQiOiAiMjAyNi0xMC0wMVQxMjowMDowMFoiLAogICAgICAibGltaXRhdGlvbnMiOiBbXQogICAgfQogIF0sCiAgImF1dGhvcml0aWVzIjogWwogICAgewogICAgICAiaWQiOiAiUzEiLAogICAgICAia2luZCI6ICJzcGVjaWZpY2F0aW9uIiwKICAgICAgImxvY2F0b3IiOiAiZml4dHVyZTpzcGVjL1MxIiwKICAgICAgInJldmlzaW9uIjogImYyNDIxODVmMjMzMjg4NTM4MmE0MjFiNTdkNTE2ZTBkYjE5MDAyMDUiLAogICAgICAiY29udGVudCI6ICJSMTogUHJlc2VydmUgYW4gZXhpc3RpbmcgdmFsaWQgaW5zdGFsbGF0aW9uLiBBQzEgaW1wbGVtZW50cyBSMS4gQURSLTAwMDIgZWRpdGlvbiAxIHJldGFpbnMgcHJvamVjdCBpbnN0YWxsYXRpb24tbWFuaWZlc3QgYXV0aG9yaXR5IGFuZCBwcmVzZXJ2YXRpb24gb2YgdW5yZWxhdGVkIHZhbGlkIGVudHJpZXMgdW5kZXIgUjEvQUMxLiBJbW11dGFibGUgc291cmNlIGYyNDIxODVmMjMzMjg4NTM4MmE0MjFiNTdkNTE2ZTBkYjE5MDAyMDU6QURSLTAwMDItMDAxLXJldGFpbi1wcm9qZWN0LWluc3RhbGxhdGlvbi1hdXRob3JpdHkubWQ7IHJldmlld2VkIGJ5dGVzIEVBRFItUkVWSUVXRUQgU0hBMjU2IDRkNjM3NWM3OTJhZWZlYjdhYThjNjFmMjI0NjBkNWNiYzZiMmRlZGY2Zjg3NTllZDM1NTIwMmI5YTMwMDg1ZGMsIGFkbWluaXN0cmF0aXZlIEN1cnJlbnQgcmVjb3JkIEVBRFItQ1VSUkVOVCwgYWN0dWFsIHN0YWdlZCByZXNwb25zZSBFQURSLUFQUFJPVkFMIGFuZCBhcHByb3ZhbCBhdXRob3JpdHkgQUFEUi4iLAogICAgICAiYXZhaWxhYmlsaXR5IjogImF2YWlsYWJsZSIsCiAgICAgICJhcHByb3ZlciI6IG51bGwsCiAgICAgICJhcHByb3ZlZF9zY29wZSI6IG51bGwsCiAgICAgICJhcHByb3ZhbF9pZHMiOiBbCiAgICAgICAgIkExIiwKICAgICAgICAiQUFEUiIKICAgICAgXSwKICAgICAgImxpbWl0YXRpb25zIjogW10KICAgIH0sCiAgICB7CiAgICAgICJpZCI6ICJBMSIsCiAgICAgICJraW5kIjogImFwcHJvdmFsIiwKICAgICAgImxvY2F0b3IiOiAiZml4dHVyZTphcHByb3ZhbC9BMSIsCiAgICAgICJyZXZpc2lvbiI6ICIyMDI2LTEwLTAxVDEyOjAwOjAwWiIsCiAgICAgICJjb250ZW50IjogIkZpeHR1cmUgYXBwcm92ZXIgYXBwcm92ZWQgUjEgYW5kIEFDMSBhdCBTMS4iLAogICAgICAiYXZhaWxhYmlsaXR5IjogImF2YWlsYWJsZSIsCiAgICAgICJhcHByb3ZlciI6ICJmaXh0dXJlLWFwcHJvdmVyIiwKICAgICAgImFwcHJvdmVkX3Njb3BlIjogIlIxL0FDMSBhdCBTMSIsCiAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgImxpbWl0YXRpb25zIjogW10KICAgIH0sCiAgICB7CiAgICAgICJpZCI6ICJBMiIsCiAgICAgICJraW5kIjogImFwcHJvdmFsIiwKICAgICAgImxvY2F0b3IiOiAiZml4dHVyZTpyZXZpZXcvQTIiLAogICAgICAicmV2aXNpb24iOiAiMjAyNi0xMC0wMVQxMjowMDowMFoiLAogICAgICAiY29udGVudCI6ICJGaXh0dXJlIHJldmlld2VyIGFjY2VwdGVkIEFDMSBhdCBTMSBhbmQgZGVsaXZlcnkgQi4iLAogICAgICAiYXZhaWxhYmlsaXR5IjogImF2YWlsYWJsZSIsCiAgICAgICJhcHByb3ZlciI6ICJmaXh0dXJlLXJldmlld2VyIiwKICAgICAgImFwcHJvdmVkX3Njb3BlIjogIkFDMSBhdCBTMS9CIiwKICAgICAgImFwcHJvdmFsX2lkcyI6IFtdLAogICAgICAibGltaXRhdGlvbnMiOiBbXQogICAgfSwKICAgIHsKICAgICAgImlkIjogIkFBRFIiLAogICAgICAia2luZCI6ICJhcHByb3ZhbCIsCiAgICAgICJsb2NhdG9yIjogImZpeHR1cmU6YXBwcm92YWwvYXBwcm92YWwudHh0IiwKICAgICAgInJldmlzaW9uIjogImYyNDIxODVmMjMzMjg4NTM4MmE0MjFiNTdkNTE2ZTBkYjE5MDAyMDUiLAogICAgICAiY29udGVudCI6IG51bGwsCiAgICAgICJhdmFpbGFiaWxpdHkiOiAidW5hdmFpbGFibGUiLAogICAgICAiYXBwcm92ZXIiOiAiZmljdGlvbmFsIGZpeHR1cmUgb3BlcmF0b3IiLAogICAgICAiYXBwcm92ZWRfc2NvcGUiOiAiQURSLTAwMDIgZWRpdGlvbiAxIHJldGFpbnMgcHJvamVjdCBpbnN0YWxsYXRpb24tbWFuaWZlc3QgYXV0aG9yaXR5IGFuZCBwcmVzZXJ2YXRpb24gb2YgdW5yZWxhdGVkIHZhbGlkIGVudHJpZXMgdW5kZXIgUjEvQUMxLiIsCiAgICAgICJhcHByb3ZhbF9pZHMiOiBbXSwKICAgICAgImxpbWl0YXRpb25zIjogWwogICAgICAgICJDdXJyZW50IGV4YWN0LWVkaXRpb24gYXBwcm92YWwgaW50ZXJhY3Rpb24gdW5hdmFpbGFibGUuIgogICAgICBdCiAgICB9CiAgXSwKICAicmVxdWlyZW1lbnRzIjogWwogICAgewogICAgICAiaWQiOiAiUjFAUzEiLAogICAgICAia2V5IjogIlIxIiwKICAgICAgInRleHQiOiAiUHJlc2VydmUgYW4gZXhpc3RpbmcgdmFsaWQgaW5zdGFsbGF0aW9uLiIsCiAgICAgICJhdXRob3JpdHlfaWQiOiAiUzEiLAogICAgICAiYXV0aG9yaXR5X3JldmlzaW9uIjogImYyNDIxODVmMjMzMjg4NTM4MmE0MjFiNTdkNTE2ZTBkYjE5MDAyMDUiCiAgICB9CiAgXSwKICAiY3JpdGVyaWEiOiBbCiAgICB7CiAgICAgICJpZCI6ICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDE6QUMxIiwKICAgICAgImlzc3VlX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICJrZXkiOiAiQUMxIiwKICAgICAgInRleHQiOiAiUHJlc2VydmUgdGhlIGV4aXN0aW5nIHZhbGlkIGluc3RhbGxhdGlvbi4iLAogICAgICAiYXV0aG9yaXR5X2lkIjogIlMxIiwKICAgICAgImF1dGhvcml0eV9yZXZpc2lvbiI6ICJmMjQyMTg1ZjIzMzI4ODUzODJhNDIxYjU3ZDUxNmUwZGIxOTAwMjA1IiwKICAgICAgImRlbGl2ZXJ5X2NvbW1pdCI6ICJiM2IwYzcxZjg5N2JkMjY1MTg1YmFmMmNmY2MyMjI2OWZjNDRkOGYxIiwKICAgICAgInJlcXVpcmVtZW50X2lkcyI6IFsKICAgICAgICAiUjFAUzEiCiAgICAgIF0KICAgIH0KICBdLAogICJkaXNwb3NpdGlvbnMiOiBbXSwKICAiY292ZXJhZ2UiOiBbCiAgICB7CiAgICAgICJpZCI6ICJDT1YxIiwKICAgICAgImlzc3VlX2lkIjogImV4YW1wbGUvZ292ZXJuYW5jZS1maXh0dXJlIzEwMSIsCiAgICAgICJjcml0ZXJpb25faWQiOiAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUjMTAxOkFDMSIsCiAgICAgICJyZXF1aXJlbWVudF9pZHMiOiBbCiAgICAgICAgIlIxQFMxIgogICAgICBdLAogICAgICAiY29udHJpYnV0aW9uX2lzc3VlX2lkcyI6IFsKICAgICAgICAiZXhhbXBsZS9nb3Zlcm5hbmNlLWZpeHR1cmUjMTAxIgogICAgICBdLAogICAgICAicHJfaWRzIjogWwogICAgICAgICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSEyMDEiCiAgICAgIF0sCiAgICAgICJjb21iaW5lZF9yZXN1bHRfb3duZXIiOiAiZml4dHVyZS1vd25lciIsCiAgICAgICJzY29wZSI6ICJUaGUgc29sZSBmaXh0dXJlIGNyaXRlcmlvbiBpcyBjb3ZlcmVkIGJ5IHByZXNlcnZhdGlvbiBjb250cmlidXRpb24gUFIyMDEuIgogICAgfQogIF0sCiAgImV2YWx1YXRpb25zIjogWwogICAgewogICAgICAiaWQiOiAiRVYxIiwKICAgICAgImNyaXRlcmlvbl9pZCI6ICJleGFtcGxlL2dvdmVybmFuY2UtZml4dHVyZSMxMDE6QUMxIiwKICAgICAgInJlcXVpcmVtZW50X2lkcyI6IFsKICAgICAgICAiUjFAUzEiCiAgICAgIF0sCiAgICAgICJ2ZXJpZmllZF9jb21taXQiOiAiYjNiMGM3MWY4OTdiZDI2NTE4NWJhZjJjZmNjMjIyNjlmYzQ0ZDhmMSIsCiAgICAgICJtZXRob2QiOiAiRml4dHVyZSBwcmVzZXJ2YXRpb24gdmVyaWZpY2F0aW9uOyBBRFIgZWRpdGlvbi9jb250ZW50L2FwcHJvdmFsIGFuZCBsb2NhbCBtYW5pZmVzdCBvd25lcnNoaXAgYWxpZ25tZW50IGNoZWNrZWQgaW4gaW52ZW50ZWQgZml4dHVyZSIsCiAgICAgICJvYnNlcnZlZF9yZXN1bHQiOiAiUEFTUyBzdXBwbGllZCBieSB0aGUgaW52ZW50ZWQgZml4dHVyZS4iLAogICAgICAicmVzdWx0IjogIlNBVElTRklFRCIsCiAgICAgICJvYnNlcnZlZF9hdCI6ICIyMDI2LTEwLTAxVDEyOjAwOjAwWiIsCiAgICAgICJldmlkZW5jZV9pZHMiOiBbCiAgICAgICAgIkUxIiwKICAgICAgICAiUlYxIiwKICAgICAgICAiRUFEUi1SRVZJRVdFRCIsCiAgICAgICAgIkVBRFItQ1VSUkVOVCIsCiAgICAgICAgIkVBRFItQVBQUk9WQUwiCiAgICAgIF0sCiAgICAgICJyZXZpZXdfYXBwcm92YWxfaWRzIjogWwogICAgICAgICJBMiIKICAgICAgXSwKICAgICAgImFwcGxpY2FiaWxpdHkiOiAiY3VycmVudCIsCiAgICAgICJyZW1haW5pbmdfY29udHJpYnV0aW9ucyI6IFtdLAogICAgICAibGltaXRhdGlvbnMiOiBbXQogICAgfQogIF0sCiAgImV2aWRlbmNlIjogWwogICAgewogICAgICAiaWQiOiAiRTEiLAogICAgICAia2luZCI6ICJ2ZXJpZmljYXRpb24iLAogICAgICAibG9jYXRvciI6ICJmaXh0dXJlOnZlcmlmaWNhdGlvbi9FMSIsCiAgICAgICJyZXZpc2lvbiI6ICJiM2IwYzcxZjg5N2JkMjY1MTg1YmFmMmNmY2MyMjI2OWZjNDRkOGYxIiwKICAgICAgInNoYTI1NiI6IG51bGwsCiAgICAgICJhdmFpbGFiaWxpdHkiOiAiYXZhaWxhYmxlIiwKICAgICAgImNvbnRlbnQiOiAiSW52ZW50ZWQgZml4dHVyZSByZXN1bHQ6IEFDMSBwYXNzZWQgcHJlc2VydmF0aW9uIHZlcmlmaWNhdGlvbiBhZ2FpbnN0IFMxIGFuZCBCLiIsCiAgICAgICJ2ZXJpZmllZF9jb21taXQiOiAiYjNiMGM3MWY4OTdiZDI2NTE4NWJhZjJjZmNjMjIyNjlmYzQ0ZDhmMSIsCiAgICAgICJsaW1pdGF0aW9ucyI6IFtdCiAgICB9LAogICAgewogICAgICAiaWQiOiAiUlYxIiwKICAgICAgImtpbmQiOiAicmV2aWV3IiwKICAgICAgImxvY2F0b3IiOiAiZml4dHVyZTpyZXZpZXcvUlYxIiwKICAgICAgInJldmlzaW9uIjogImIzYjBjNzFmODk3YmQyNjUxODViYWYyY2ZjYzIyMjY5ZmM0NGQ4ZjEiLAogICAgICAic2hhMjU2IjogbnVsbCwKICAgICAgImF2YWlsYWJpbGl0eSI6ICJhdmFpbGFibGUiLAogICAgICAiY29udGVudCI6ICJJbnZlbnRlZCBmaXh0dXJlIHJldmlldyBhY2NlcHRlZCBBQzEgYXQgUzEvQi4iLAogICAgICAidmVyaWZpZWRfY29tbWl0IjogImIzYjBjNzFmODk3YmQyNjUxODViYWYyY2ZjYzIyMjY5ZmM0NGQ4ZjEiLAogICAgICAibGltaXRhdGlvbnMiOiBbXQogICAgfSwKICAgIHsKICAgICAgImlkIjogIkVBRFItUkVWSUVXRUQiLAogICAgICAia2luZCI6ICJvdGhlciIsCiAgICAgICJsb2NhdG9yIjogImZpeHR1cmU6YWRyL0FEUi0wMDAyLTAwMS1yZXZpZXdlZC50eHQiLAogICAgICAicmV2aXNpb24iOiAiZjI0MjE4NWYyMzMyODg1MzgyYTQyMWI1N2Q1MTZlMGRiMTkwMDIwNSIsCiAgICAgICJzaGEyNTYiOiAiZWIzODMzNTgwNTA3NGFmM2IzOGJlYjY2ODY4MGI1MzQwMjBhZGI4MGE4Njc2ZGIzZDBlZDg2YmQwZjhiY2ViOSIsCiAgICAgICJhdmFpbGFiaWxpdHkiOiAiYXZhaWxhYmxlIiwKICAgICAgImNvbnRlbnQiOiAiIyBQcm9wb3NlZCBBRFItMDAwMiBlZGl0aW9uIDE6IHJldGFpbiBwcm9qZWN0IGluc3RhbGxhdGlvbiBhdXRob3JpdHlcblxuVGhlIHJlbW90ZSBzZXJ2aWNlIG93bnMgaXRzIGluc3RhbGxhdGlvbiBtYW5pZmVzdCBhbmQgcHJlc2VydmVzIHVucmVsYXRlZCBleGlzdGluZyB2YWxpZCBlbnRyaWVzLiBUaGlzIGNvbnN0cmFpbnMgZml4dHVyZSByZXF1aXJlbWVudCBSMSBhbmQgY3JpdGVyaW9uIEFDMS4gQWx0ZXJuYXRpdmVzOiBwcm9qZWN0IG93bmVyc2hpcCBvciBhIHJlbW90ZSBzZXJ2aWNlIG93bmluZyB3cml0ZXMuIFByb2plY3Qgb3duZXJzaGlwIHByZXNlcnZlcyB0aGUgZXhpc3RpbmcgcHJvZHVjdCBjb250cmFjdC4gTm8gcmVtb3RlIG9wZXJhdGlvbiwgcnVudGltZSwgYXBwcm92YWwgc3RvcmUgb3IgcHVibGljYXRpb24gaXMgaW50cm9kdWNlZC5cbiIsCiAgICAgICJ2ZXJpZmllZF9jb21taXQiOiBudWxsLAogICAgICAibGltaXRhdGlvbnMiOiBbXQogICAgfSwKICAgIHsKICAgICAgImlkIjogIkVBRFItQ1VSUkVOVCIsCiAgICAgICJraW5kIjogIm90aGVyIiwKICAgICAgImxvY2F0b3IiOiAiZml4dHVyZTphZHIvQURSLTAwMDItMDAxLXJldGFpbi1wcm9qZWN0LWluc3RhbGxhdGlvbi1hdXRob3JpdHkubWQiLAogICAgICAicmV2aXNpb24iOiAiZjI0MjE4NWYyMzMyODg1MzgyYTQyMWI1N2Q1MTZlMGRiMTkwMDIwNSIsCiAgICAgICJzaGEyNTYiOiAiMjIxZmM1NmEyODMyNjIyNWMyYmVmNDhjMWNjMWM5M2M4ZmI4NDdjMTFjMmQ5YTlkNTJjMmUzOGJhNWI1ZWM4NyIsCiAgICAgICJhdmFpbGFiaWxpdHkiOiAiYXZhaWxhYmxlIiwKICAgICAgImNvbnRlbnQiOiAiLS0tXG5pZDogQURSLTAwMDJcbnRpdGxlOiBSZXRhaW4gcHJvamVjdCBpbnN0YWxsYXRpb24gYXV0aG9yaXR5XG5yZXZpc2lvbjogMVxuc3RhdGU6IEN1cnJlbnRcbmRlY2lzaW9uX2RhdGU6IDIwMjYtMTEtMTVcbnJldmlzaW9uX2RhdGU6IDIwMjYtMTEtMTVcbmFwcHJvdmVkX2J5OiBmaWN0aW9uYWwgZml4dHVyZSBvcGVyYXRvclxuYXBwcm92ZWRfcmV2aXNpb246IDFcbmFwcHJvdmFsX3JlZjogYXBwcm92YWwudHh0XG4tLS1cblxuIyBQcm9wb3NlZCBBRFItMDAwMiBlZGl0aW9uIDE6IHJldGFpbiBwcm9qZWN0IGluc3RhbGxhdGlvbiBhdXRob3JpdHlcblxuVGhlIHJlbW90ZSBzZXJ2aWNlIG93bnMgaXRzIGluc3RhbGxhdGlvbiBtYW5pZmVzdCBhbmQgcHJlc2VydmVzIHVucmVsYXRlZCBleGlzdGluZyB2YWxpZCBlbnRyaWVzLiBUaGlzIGNvbnN0cmFpbnMgZml4dHVyZSByZXF1aXJlbWVudCBSMSBhbmQgY3JpdGVyaW9uIEFDMS4gQWx0ZXJuYXRpdmVzOiBwcm9qZWN0IG93bmVyc2hpcCBvciBhIHJlbW90ZSBzZXJ2aWNlIG93bmluZyB3cml0ZXMuIFByb2plY3Qgb3duZXJzaGlwIHByZXNlcnZlcyB0aGUgZXhpc3RpbmcgcHJvZHVjdCBjb250cmFjdC4gTm8gcmVtb3RlIG9wZXJhdGlvbiwgcnVudGltZSwgYXBwcm92YWwgc3RvcmUgb3IgcHVibGljYXRpb24gaXMgaW50cm9kdWNlZC5cblxuQWRtaW5pc3RyYXRpdmUgYXBwcm92YWwgY2FwdHVyZSBvbmx5OyBkZWNpc2lvbiB1bmNoYW5nZWQuIE9yaWdpbmFsIHJldmlld2VkIHByb3Bvc2FsIGlzIEFEUi0wMDAyLTAwMS1yZXZpZXdlZC50eHQgYXQgU0hBMjU2IDRkNjM3NWM3OTJhZWZlYjdhYThjNjFmMjI0NjBkNWNiYzZiMmRlZGY2Zjg3NTllZDM1NTIwMmI5YTMwMDg1ZGMuIEZpY3Rpb25hbCBpbnB1dCwgbm90IGFjdHVhbCBwdWJsaXNoZXIgYXBwcm92YWwuXG4iLAogICAgICAidmVyaWZpZWRfY29tbWl0IjogbnVsbCwKICAgICAgImxpbWl0YXRpb25zIjogW10KICAgIH0sCiAgICB7CiAgICAgICJpZCI6ICJFQURSLUFQUFJPVkFMIiwKICAgICAgImtpbmQiOiAiYXBwcm92YWwiLAogICAgICAibG9jYXRvciI6ICJmaXh0dXJlOmFkci9hcHByb3ZhbC50eHQiLAogICAgICAicmV2aXNpb24iOiAiZjI0MjE4NWYyMzMyODg1MzgyYTQyMWI1N2Q1MTZlMGRiMTkwMDIwNSIsCiAgICAgICJzaGEyNTYiOiBudWxsLAogICAgICAiYXZhaWxhYmlsaXR5IjogInVuYXZhaWxhYmxlIiwKICAgICAgImNvbnRlbnQiOiBudWxsLAogICAgICAidmVyaWZpZWRfY29tbWl0IjogbnVsbCwKICAgICAgImxpbWl0YXRpb25zIjogWwogICAgICAgICJDdXJyZW50IHJlcXVpcmVkIEFEUi0wMDAyIGVkaXRpb24tMSBpbnRlcmFjdGlvbiBpcyB1bmF2YWlsYWJsZTsgcHJpb3IgcGFpciByZWNvcmRzIGFub3RoZXIgZGVjaXNpb24uIgogICAgICBdCiAgICB9CiAgXSwKICAibGltaXRhdGlvbnMiOiBbXQp9Cg=="
    }
  ],
  "limitations": [
    "AADR and EADR-APPROVAL unavailable/null for new ADR-0002 edition1 (remote-service ownership). Current metadata cannot approve it. S1/current administrative record cite old reviewed hash 4d6375... while actual ADR-0002 bytes hash eb38335805074af3b38beb668680b534020adb80a8676db3d0ed86bd0f8bceb9. No matching immutable ADR-0002 source object supplied.",
    "Diagnostic only. Supplied prior-receipt.json is a hash assertion, not full transaction receipt: root/index/blob/mode/expected-HEAD ownership fields absent. No fixture-local acceptance history supplied here. No commit/publication authorized."
  ]
}

~~~
